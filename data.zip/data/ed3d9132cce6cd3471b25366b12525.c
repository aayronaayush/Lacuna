
// Copyright 2012 Google Inc. All rights reserved.
(function(w,g){w[g]=w[g]||{};w[g].e=function(s){return eval(s);};})(window,'google_tag_manager');(function(){

var data = {
"resource": {
  "version":"132",
  
  "macros":[{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"false",
      "vtp_name":"ga_enabled"
    },{
      "function":"__e"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"userId"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"primaryCategory"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"contentType"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"author"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"displayType"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"edition"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"jobPosition"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"industry"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"purchaseIntent"
    },{
      "function":"__k",
      "vtp_decodeCookie":false,
      "vtp_name":"firstSessionDate"
    },{
      "function":"__k",
      "vtp_decodeCookie":false,
      "vtp_name":"lastSessionDate"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"daysSinceLastSession"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"sessionNumber"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"environment"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"property"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"propertyCountry"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"audience"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"insiderSignedIn"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"adBlockStatus"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"platform"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"contentStrategy"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"categoryIdPrimary"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"primaryCategoryAll"
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var a=",["escape",["macro",24],8,16],",b=a.split(\", \").filter(function(a){return\"\"!==a});a=b.filter(function(a,c){return b.indexOf(a)==c});return a.join(\", \")})();"]
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"categoryIdList"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"productVendor"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"productManufacturer"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"productName"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"productId"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"tags"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"articleId"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"source"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"articleHasVideo"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"videoPlayerName"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"videoPlayerId"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"videoChannel"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"videoTitle"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"videoId"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"videoAutoplay"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"pageNumber"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"datePublished"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"dateUpdated"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"daysSincePublished"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"daysSinceUpdated"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"isInsiderContent"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"isBlog"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"blogName"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"isICN"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"adModules"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"otherModules"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"hasRegCookie"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"productLinkPosition"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"jobFunction"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"oneRegPlacementID"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"goldenTaxonomyIdPrimary"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"goldenTaxonomyIdAll"
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var a=",["escape",["macro",57],8,16],",b=a.split(\", \").filter(function(a){return\"\"!==a});a=b.filter(function(a,c){return b.indexOf(a)==c});return a.join(\", \")})();"]
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"contentCollection"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"sponsorName"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"videoLength"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"ip_company_name"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"articleLocale"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"false",
      "vtp_name":"brandpost"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"podcastSponsored"
    },{
      "function":"__u",
      "vtp_component":"QUERY",
      "vtp_queryKey":"utm_date",
      "vtp_enableMultiQueryKeys":false,
      "vtp_enableIgnoreEmptyQueryParam":false
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"youtubeId"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"gaTrackingId"
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){try{var c=ga.getAll(),d;var a=0;for(d=c.length;a\u003Cd;a+=1)if(c[a].get(\"trackingId\")===",["escape",["macro",68],8,16],")return c[a].get(\"clientId\")}catch(f){a=\"_ga\";c=a+\"\\x3d\";d=document.cookie.split(\";\");for(a=0;a\u003Cd.length;a++){for(var b=d[a],e;\" \"==b.charAt(0);)b=b.substring(1,b.length);0==b.indexOf(c)\u0026\u0026(e=b.substring(c.length,b.length))}pieces=e.split(\".\");return(cid=pieces[pieces.length-2]+\".\"+pieces[pieces.length-1])?cid:e=ga.getAll()[0].get(\"clientId\")}return\"false\"})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){switch(",["escape",["macro",16],8,16],"){case \"computerworld\":case \"cio\":case \"csoonline\":case \"infoworld\":case \"network world\":case \"pcworld\":case \"macworld\":case \"techhive\":case \"greenbot\":case \"techconnect\":case \"insiderpro\":return ",["escape",["macro",69],8,16],"}})();"]
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"BCUID"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"BCEngagementScore"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"BCSegments"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"mapperDomain"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"mapperTal"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"mapperCompany"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"de_normalized_company_name"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"false",
      "vtp_name":"insiderProSignedIn"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"dbAnnualSales"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"dbCompanyName"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"dbGlobalUltimate"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"dbDuns"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"dbDomain"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"dbITExpense"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"dbTechOfficeDemand"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"dbTelecomSpend"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"dbRole"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"dbLocation"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"dbEmployee"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"dbNaics"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"dbDunsParent"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"dbDomesticUltimate"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"dbEmployeesUltimate"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"dbCustomAttributes"
    },{
      "function":"__gas",
      "vtp_cookieDomain":"auto",
      "vtp_doubleClick":false,
      "vtp_setTrackerName":false,
      "vtp_useDebugVersion":false,
      "vtp_fieldsToSet":["list",["map","fieldName","useAmpClientId","value","true"],["map","fieldName","userId","value",["macro",2]]],
      "vtp_useHashAutoLink":false,
      "vtp_contentGroup":["list",["map","index","1","group",["macro",3]],["map","index","2","group",["macro",4]],["map","index","3","group",["macro",5]],["map","index","4","group",["macro",6]],["map","index","5","group",["macro",7]]],
      "vtp_decorateFormsAutoLink":false,
      "vtp_enableLinkId":true,
      "vtp_dimension":["list",["map","index","14","dimension",["macro",2]],["map","index","2","dimension",["macro",8]],["map","index","3","dimension",["macro",9]],["map","index","4","dimension",["macro",10]],["map","index","5","dimension",["macro",11]],["map","index","6","dimension",["macro",12]],["map","index","7","dimension",["macro",13]],["map","index","8","dimension",["macro",14]],["map","index","9","dimension",["macro",15]],["map","index","10","dimension",["macro",16]],["map","index","11","dimension",["macro",17]],["map","index","12","dimension",["macro",18]],["map","index","13","dimension",["macro",19]],["map","index","1","dimension",["macro",20]],["map","index","15","dimension",["macro",21]],["map","index","16","dimension",["macro",22]],["map","index","17","dimension",["macro",3]],["map","index","18","dimension",["macro",23]],["map","index","19","dimension",["macro",25]],["map","index","20","dimension",["macro",26]],["map","index","21","dimension",["macro",27]],["map","index","22","dimension",["macro",28]],["map","index","23","dimension",["macro",29]],["map","index","24","dimension",["macro",30]],["map","index","25","dimension",["macro",31]],["map","index","26","dimension",["macro",4]],["map","index","27","dimension",["macro",32]],["map","index","28","dimension",["macro",6]],["map","index","29","dimension",["macro",5]],["map","index","30","dimension",["macro",33]],["map","index","31","dimension",["macro",34]],["map","index","32","dimension",["macro",35]],["map","index","33","dimension",["macro",36]],["map","index","34","dimension",["macro",37]],["map","index","35","dimension",["macro",38]],["map","index","36","dimension",["macro",39]],["map","index","37","dimension",["macro",40]],["map","index","38","dimension",["macro",41]],["map","index","39","dimension",["macro",42]],["map","index","40","dimension",["macro",43]],["map","index","41","dimension",["macro",44]],["map","index","42","dimension",["macro",45]],["map","index","43","dimension",["macro",46]],["map","index","44","dimension",["macro",47]],["map","index","45","dimension",["macro",48]],["map","index","46","dimension",["macro",49]],["map","index","47","dimension",["macro",50]],["map","index","48","dimension",["macro",51]],["map","index","49","dimension",["macro",52]],["map","index","50","dimension",["macro",53]],["map","index","51","dimension",["macro",54]],["map","index","52","dimension",["macro",55]],["map","index","53","dimension",["macro",56]],["map","index","54","dimension",["macro",58]],["map","index","55","dimension",["macro",59]],["map","index","56","dimension",["macro",60]],["map","index","57","dimension",["macro",61]],["map","index","61","dimension",["macro",62]],["map","index","79","dimension",["macro",7]],["map","index","80","dimension",["macro",63]],["map","index","81","dimension",["macro",64]],["map","index","82","dimension",["macro",65]],["map","index","83","dimension",["macro",66]],["map","index","84","dimension",["macro",67]],["map","index","70","dimension",["macro",70]],["map","index","58","dimension",["macro",71]],["map","index","59","dimension",["macro",72]],["map","index","60","dimension",["macro",73]],["map","index","100","dimension",["macro",74]],["map","index","101","dimension",["macro",75]],["map","index","102","dimension",["macro",76]],["map","index","103","dimension",["macro",77]],["map","index","104","dimension",["macro",78]],["map","index","118","dimension",["macro",79]],["map","index","105","dimension",["macro",80]],["map","index","106","dimension",["macro",81]],["map","index","107","dimension",["macro",82]],["map","index","108","dimension",["macro",83]],["map","index","109","dimension",["macro",84]],["map","index","110","dimension",["macro",85]],["map","index","111","dimension",["macro",86]],["map","index","112","dimension",["macro",87]],["map","index","113","dimension",["macro",88]],["map","index","114","dimension",["macro",89]],["map","index","115","dimension",["macro",90]],["map","index","116","dimension",["macro",91]],["map","index","117","dimension",["macro",92]],["map","index","119","dimension",["macro",93]],["map","index","120","dimension",["macro",94]]],
      "vtp_enableEcommerce":false,
      "vtp_trackingId":["macro",68],
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableGA4Schema":false
    },{
      "function":"__e"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"eventAction"
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){return\"videoEvent\"==",["escape",["macro",96],8,16],"\u0026\u0026\"Autoplay\"==",["escape",["macro",97],8,16],"||\"videoEvent\"==",["escape",["macro",96],8,16],"\u0026\u0026\"Ad Start\"==",["escape",["macro",97],8,16],"||\"moduleImpression\"==",["escape",["macro",96],8,16],"?!0:!1})();"]
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"eventCategory"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"eventLabel"
    },{
      "function":"__aev",
      "vtp_varType":"TEXT"
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){return\"socialLink\"==",["escape",["macro",96],8,16],"?",["escape",["macro",97],8,16],"+\" \"+",["escape",["macro",101],8,16],":",["escape",["macro",97],8,16],"})();"]
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"articleTitle"
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){return\"affiliateLink\"==",["escape",["macro",96],8,16],"?",["escape",["macro",27],8,16],"+\" | \"+",["escape",["macro",29],8,16],":\"socialLink\"==",["escape",["macro",96],8,16],"?",["escape",["macro",103],8,16],"?",["escape",["macro",103],8,16],":",["escape",["macro",48],8,16],"+\" index\":",["escape",["macro",100],8,16],"})();"]
    },{
      "function":"__u",
      "vtp_component":"PATH",
      "vtp_enableMultiQueryKeys":false,
      "vtp_enableIgnoreEmptyQueryParam":false
    },{
      "function":"__v",
      "vtp_name":"gtm.triggers",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":""
    },{
      "function":"__v",
      "vtp_name":"gtm.videoStatus",
      "vtp_dataLayerVersion":1
    },{
      "function":"__v",
      "vtp_name":"gtm.videoPercent",
      "vtp_dataLayerVersion":1
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var a=",["escape",["macro",107],8,16],";switch(a){case \"start\":return\"Play\";case \"pause\":return\"Pause\";case \"seek\":return\"Seek\";case \"progress\":return ",["escape",["macro",108],8,16],"+\"%\"}})();"]
    },{
      "function":"__v",
      "vtp_name":"gtm.videoTitle",
      "vtp_dataLayerVersion":1
    },{
      "function":"__v",
      "vtp_name":"gtm.videoUrl",
      "vtp_dataLayerVersion":1
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"nonIdleTimeElapsed"
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){return ",["escape",["macro",112],8,16],"\/1E3})();"]
    },{
      "function":"__v",
      "vtp_name":"gtm.elementUrl",
      "vtp_dataLayerVersion":1
    },{
      "function":"__v",
      "vtp_name":"gtm.element",
      "vtp_dataLayerVersion":1
    },{
      "function":"__smm",
      "vtp_setDefaultValue":true,
      "vtp_input":["macro",16],
      "vtp_defaultValue":"omit",
      "vtp_map":["list",["map","key","cio","value","cio"],["map","key","computerworld","value","cw"],["map","key","cso online","value","cso"],["map","key","greenbot","value","gb"],["map","key","infoworld","value","ifw"],["map","key","itnews","value","itn"],["map","key","itworld","value","itw"],["map","key","javaworld","value","jw"],["map","key","macworld","value","mw"],["map","key","network world","value","nww"],["map","key","pcworld","value","pcw"],["map","key","techconnect","value","tc"],["map","key","techhive","value","th"],["map","key","insiderpro","value","omit"]]
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"suppressMonetization"
    },{
      "function":"__u",
      "vtp_component":"URL",
      "vtp_enableMultiQueryKeys":false,
      "vtp_enableIgnoreEmptyQueryParam":false
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"scrollEventCategory"
    },{
      "function":"__u",
      "vtp_component":"HOST",
      "vtp_enableMultiQueryKeys":false,
      "vtp_enableIgnoreEmptyQueryParam":false
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"eventNonInteraction"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"scrollEventAction"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"scrollEventLabel"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"kickfire-api-event-message"
    },{
      "function":"__c",
      "vtp_value":["macro",68]
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"kickfire-api-return.name"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"kickfire-api-return.country"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"kickfire-api-return.employees"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"kickfire-api-return.revenue"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"kickfire-api-return.WatchList"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"kickfire-api-return.website"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"kickfire-api-return.city"
    },{
      "function":"__j",
      "convert_undefined_to":"Before Tracking Engaged",
      "vtp_name":"floatingPlayerStatus.label"
    },{
      "function":"__j",
      "convert_undefined_to":"N\/A (tracking not engaged)",
      "vtp_name":"floatingPlayerStatus.time"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"false",
      "vtp_name":"facebookConsent"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"ccpaOptedOut"
    },{
      "function":"__j",
      "vtp_name":"isEU"
    },{
      "function":"__k",
      "vtp_decodeCookie":false,
      "vtp_name":"currentSessionDate"
    },{
      "function":"__k",
      "vtp_decodeCookie":false,
      "vtp_name":"inSession"
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){return function(d,e,f,b,c){if(d\u0026\u0026e){b=b?\"; path\\x3d\"+b:\"\";c=c?\"; domain\\x3d\"+c:\"\";var a=\"\";f\u0026\u0026(a=new Date,a.setTime(a.getTime()+f),a=\"; expires\\x3d\"+a.toUTCString());document.cookie=d+\"\\x3d\"+e+a+b+c}}})();"]
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"false",
      "vtp_name":"geolocEnabled"
    },{
      "function":"__smm",
      "vtp_setDefaultValue":true,
      "vtp_input":["macro",16],
      "vtp_defaultValue":"000",
      "vtp_map":["list",["map","key","cio","value","012"],["map","key","computerworld","value","011"],["map","key","cso online","value","013"],["map","key","greenbot","value","005"],["map","key","infoworld","value","014"],["map","key","itnews","value","022"],["map","key","itworld","value","021"],["map","key","javaworld","value","016"],["map","key","macworld","value","002"],["map","key","network world","value","015"],["map","key","pcworld","value","001"],["map","key","techconnect","value","004"],["map","key","techhive","value","003"],["map","key","thefullnerd","value","007"],["map","key","idg.tv","value","023"]]
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"skimlinksId"
    },{
      "function":"__smm",
      "vtp_setDefaultValue":true,
      "vtp_input":["macro",16],
      "vtp_defaultValue":"omit",
      "vtp_map":["list",["map","key","pcworld","value","4e5961ed-0324-48db-be9c-4ac254530014"]]
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"suppressForHoliday"
    },{
      "function":"__k",
      "vtp_decodeCookie":false,
      "vtp_name":"cntxSeen"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"false",
      "vtp_name":"twitterConsent"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"false",
      "vtp_name":"linkedinConsent"
    },{
      "function":"__smm",
      "vtp_setDefaultValue":false,
      "vtp_input":["macro",18],
      "vtp_map":["list",["map","key","enterprise","value","8yHZorDV"],["map","key","consumer","value","kAvvfxjt"]]
    },{
      "function":"__smm",
      "vtp_setDefaultValue":true,
      "vtp_input":["macro",16],
      "vtp_defaultValue":"omit",
      "vtp_map":["list",["map","key","cio","value","cio.com"],["map","key","computerworld","value","computerworld.com"],["map","key","cso online","value","csoonline.com"],["map","key","infoworld","value","infoworld.com"],["map","key","network world","value","networkworld.com"],["map","key","macworld","value","macworld.com"]]
    },{
      "function":"__smm",
      "vtp_setDefaultValue":false,
      "vtp_input":["macro",18],
      "vtp_map":["list",["map","key","enterprise","value","xAPwXviG"],["map","key","consumer","value","JAlPV8CF"]]
    },{
      "function":"__smm",
      "vtp_setDefaultValue":false,
      "vtp_input":["macro",18],
      "vtp_map":["list",["map","key","enterprise","value","LxK3nuOJ"],["map","key","consumer","value","fQeHP23f"]]
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"false",
      "vtp_name":"triblioConsent"
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){return 0==consent.isEU?!0:consent.purposes.standard.includes(\"1\")?!0:!1})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){return 0==consent.isEU?!0:consent.purposes.standard.includes(\"3\")?!0:!1})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){return 0==consent.isEU?!0:consent.purposes.standard.includes(\"5\")?!0:!1})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var b=!1;1!=consent.isEU\u0026\u0026__uspapi(\"getUSPData\",1,function(a,c){if(c)try{var d=a.uspString;a=[];a=d.split(\"\");b=\"undefined\"!==typeof a[2]\u0026\u0026\"Y\"===a[2]?!0:!1}catch(e){b=!1}else b=!1});return b})();"]
    },{
      "function":"__t"
    },{
      "function":"__smm",
      "vtp_setDefaultValue":false,
      "vtp_input":["macro",18],
      "vtp_map":["list",["map","key","enterprise","value","B2B"],["map","key","consumer","value","B2C"]]
    },{
      "function":"__k",
      "vtp_decodeCookie":false,
      "vtp_name":"jwpSeen"
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){return 0==consent.isEU?!0:consent.purposes.standard.includes(\"2\")?!0:!1})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){return 0==consent.isEU?!0:consent.purposes.standard.includes(\"4\")?!0:!1})();"]
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"false",
      "vtp_name":"dnbConsent"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"false",
      "vtp_name":"redditConsent"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"primaryCategoryList"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"goldenTaxonomyIdList"
    },{
      "function":"__c",
      "vtp_value":"7356d61f9189e8d0"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"kickfire-api-return.category"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"kickfire-api-return.category2"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"kickfire-api-return.confidence"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"kickfire-api-return.isISP"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"kickfire-api-return.naicsGroup"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"kickfire-api-return.region"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"kickfire-api-return.sicGroup"
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){return 0==consent.isEU?!0:consent.purposes.custom.includes(\"Social Media Consents\")?!0:!1})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){return null==document.getElementById(\"bottomRightPlayer\")?!1:!0})();"]
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"dbCountry"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"dbDunsUltimate"
    },{
      "function":"__e"
    },{
      "function":"__f",
      "vtp_component":"URL"
    },{
      "function":"__v",
      "vtp_name":"gtm.elementClasses",
      "vtp_dataLayerVersion":1
    }],
  "tags":[{
      "function":"__html",
      "priority":100,
      "metadata":["map"],
      "once_per_load":true,
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\" async defer data-gtmsrc=\"\/\/api3847.d41.co\/sync\/\"\u003E\u003C\/script\u003E\n\u003Cscript type=\"text\/gtmscript\" data-gtmsrc=\"\/\/cdn-0.d41.co\/tags\/dnb_coretag_v4.min.js\"\u003E\u003C\/script\u003E\n\u003Cscript type=\"text\/gtmscript\"\u003Ednbvid.getData(\"api3847\",\"json\",\"T\",function(a){var c=a.salesAnnualNum,d=a.companyName,e=a.ultimateName+\"|\"+a.ultimateDuns,f=a.duns,g=a.domain,h=a.itExpense,k=a.techOfficeDemand,l=a.telecomSpend,m=a.jobFunction+\"|\"+a.jobSeniority,n=a.companyCity+\"|\"+a.companyState+\"|\"+a.companyZip5+\"|\"+a.companyCountry,p=a.employeesAtLocation+\"|\"+a.employeesAtLocationNum,q=a.industryNaics+\"|\"+a.naicsCodes,r=a.parentName+\"|\"+a.parentDuns,t=a.domesticUltimateName+\"|\"+a.domesticUltimateDuns,u=a.employeesInAllLocations+\n\"|\"+a.employeesInAllLocationsNum;try{var b=a.customAttributes.dataPoint1+\"|\"+a.customAttributes.dataPoint2+\"|\"+a.customAttributes.dataPoint3+\"|\"+a.customAttributes.dataPoint4+\"|\"+a.customAttributes.dataPoint5+\"|\"+a.customAttributes.dataPoint6+\"|\"+a.customAttributes.dataPoint7+\"|\"+a.customAttributes.dataPoint8+\"|\"+a.customAttributes.dataPoint9+\"|\"+a.customAttributes.dataPoint10}catch(v){console.log(v),b=\"undefined|undefined|undefined|undefined|undefined|undefined|undefined|undefined|undefined|undefined\"}dataLayer.push({event:\"vicomplete\",\ndbAnnualSales:c,dbCompanyName:d,dbGlobalUltimate:e,dbDuns:f,dbDomain:g,dbITExpense:h,dbTechOfficeDemand:k,dbTelecomSpend:l,dbRole:m,dbLocation:n,dbEmployee:p,dbNaics:q,dbDunsParent:r,dbDomesticUltimate:t,dbEmployeesUltimate:u,dbCustomAttributes:b})});\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":218
    },{
      "function":"__html",
      "priority":4,
      "metadata":["map"],
      "once_per_load":true,
      "vtp_html":"\n\u003Cscript\u003E!function(d,e,f,a,b,c){d.twq||(a=d.twq=function(){a.exe?a.exe.apply(a,arguments):a.queue.push(arguments)},a.version=\"1.1\",a.queue=[],b=e.createElement(f),b.async=!0,b.src=\"\/\/static.ads-twitter.com\/uwt.js\",c=e.getElementsByTagName(f)[0],c.parentNode.insertBefore(b,c))}(window,document,\"script\");twq(\"init\",\"o1hbs\");twq(\"track\",\"PageView\");\u003C\/script\u003E\n",
      "vtp_supportDocumentWrite":true,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "vtp_usePostscribe":true,
      "tag_id":29
    },{
      "function":"__html",
      "priority":4,
      "metadata":["map"],
      "once_per_load":true,
      "vtp_html":"\u003Cscript type=\"text\/javascript\"\u003E_linkedin_partner_id=\"929234\";window._linkedin_data_partner_ids=window._linkedin_data_partner_ids||[];window._linkedin_data_partner_ids.push(_linkedin_partner_id);(function(){var b=document.getElementsByTagName(\"script\")[0],a=document.createElement(\"script\");a.type=\"text\/javascript\";a.async=!0;a.src=\"https:\/\/snap.licdn.com\/li.lms-analytics\/insight.min.js\";b.parentNode.insertBefore(a,b)})();\u003C\/script\u003E\n\u003Cnoscript\u003E\n\u003Cimg height=\"1\" width=\"1\" style=\"display:none;\" alt=\"\" src=\"https:\/\/dc.ads.linkedin.com\/collect\/?pid=929234\u0026amp;fmt=gif\"\u003E\n\u003C\/noscript\u003E",
      "vtp_supportDocumentWrite":true,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "vtp_usePostscribe":true,
      "tag_id":30
    },{
      "function":"__html",
      "priority":3,
      "metadata":["map"],
      "once_per_load":true,
      "vtp_html":"\n\u003Cscript\u003E!function(b,e,f,g,a,c,d){b.fbq||(a=b.fbq=function(){a.callMethod?a.callMethod.apply(a,arguments):a.queue.push(arguments)},b._fbq||(b._fbq=a),a.push=a,a.loaded=!0,a.version=\"2.0\",a.queue=[],c=e.createElement(f),c.async=!0,c.src=g,d=e.getElementsByTagName(f)[0],d.parentNode.insertBefore(c,d))}(window,document,\"script\",\"https:\/\/connect.facebook.net\/en_US\/fbevents.js\");fbq(\"init\",\"528995260596026\");fbq(\"track\",\"PageView\");\u003C\/script\u003E\n\u003Cnoscript\u003E\u003Cimg height=\"1\" width=\"1\" style=\"display:none\" src=\"https:\/\/www.facebook.com\/tr?id=528995260596026\u0026amp;ev=PageView\u0026amp;noscript=1\"\u003E\u003C\/noscript\u003E\n\n\n\n\u003Cscript\u003Efbq(\"track\",\"ViewContent\");\u003C\/script\u003E",
      "vtp_supportDocumentWrite":true,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "vtp_usePostscribe":true,
      "tag_id":2
    },{
      "function":"__html",
      "priority":3,
      "metadata":["map"],
      "once_per_load":true,
      "vtp_html":"\n\u003Cscript\u003E!function(b,e,f,g,a,c,d){b.fbq||(a=b.fbq=function(){a.callMethod?a.callMethod.apply(a,arguments):a.queue.push(arguments)},b._fbq||(b._fbq=a),a.push=a,a.loaded=!0,a.version=\"2.0\",a.queue=[],c=e.createElement(f),c.async=!0,c.src=g,d=e.getElementsByTagName(f)[0],d.parentNode.insertBefore(c,d))}(window,document,\"script\",\"https:\/\/connect.facebook.net\/en_US\/fbevents.js\");fbq(\"init\",\"783301121827721\");fbq(\"track\",\"PageView\");\u003C\/script\u003E\n\u003Cnoscript\u003E\u003Cimg height=\"1\" width=\"1\" style=\"display:none\" src=\"https:\/\/www.facebook.com\/tr?id=528995260596026\u0026amp;ev=PageView\u0026amp;noscript=1\"\u003E\u003C\/noscript\u003E\n\n\n\n\u003Cscript\u003Efbq(\"track\",\"ViewContent\");\u003C\/script\u003E",
      "vtp_supportDocumentWrite":true,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "vtp_usePostscribe":true,
      "tag_id":32
    },{
      "function":"__html",
      "priority":3,
      "metadata":["map"],
      "once_per_load":true,
      "vtp_html":"\n\u003Cscript type=\"text\/gtmscript\"\u003E!function(a,b){if(!a.rdt){var c=a.rdt=function(){c.sendEvent?c.sendEvent.apply(c,arguments):c.callQueue.push(arguments)};c.callQueue=[];a=b.createElement(\"script\");a.src=\"https:\/\/www.redditstatic.com\/ads\/pixel.js\";a.async=!0;b=b.getElementsByTagName(\"script\")[0];b.parentNode.insertBefore(a,b)}}(window,document);rdt(\"init\",\"t2_4bkq4t2o\");rdt(\"track\",\"PageVisit\");\u003C\/script\u003E\n\n",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":275
    },{
      "function":"__html",
      "priority":3,
      "metadata":["map"],
      "consent":["list"],
      "once_per_event":true,
      "vtp_html":["template","\u003Cscript type=\"text\/gtmscript\"\u003Evar scrName=\"",["escape",["macro",16],7],"\";if(\"",["escape",["macro",16],7],"\"===\"macworld\"||\"",["escape",["macro",16],7],"\"===\"techhive\")scrName=\"",["escape",["macro",16],7],"\"+\"us\";var scrEm=document.createElement(\"script\");scrEm.setAttribute(\"id\",\"funnel-relay-installer\");scrEm.setAttribute(\"data-customer-id\",\"idg_28d2b_\"+scrName);scrEm.setAttribute(\"data-property-id\",\"PROPERTY_ID\");scrEm.setAttribute(\"data-autorun\",\"true\");scrEm.setAttribute(\"async\",\"true\");\nscrEm.setAttribute(\"src\",\"https:\/\/cdn-magiclinks.trackonomics.net\/client\/static\/v2\/idg_28d2b_\"+scrName+\".js\");document.head.appendChild(scrEm);\u003C\/script\u003E"],
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":284
    },{
      "function":"__html",
      "priority":1,
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":["template","\u003Cscript\u003E(function(){var a=\"https:\/\/apple.sjv.io\/c\/321564\/435031\/7613\",b='[href^\\x3d\"https:\/\/apple.com\"],[href*\\x3d\"store\"],[href*\\x3d\"www\"],[href^\\x3d\"http:\/\/apple.com\"]',c=\"(http(s)?:\/\/((www|store)(.))?apple.com)(\/(uk|au|ca|ie|nl|se|de))?\",g=new RegExp(c+\"(\/.*)\",\"i\"),h=\/(\\\/newsroom)|(aos.prf.hn)|(\\\/swift\\\/playgrounds)|(apple.sjv.)\/i;$('a[href*\\x3d\"apple.com\"]').filter(b).each(function(b,c){var d=$(this).attr(\"href\");if(g.test(d)\u0026\u0026!h.test(d)){var e=d.replace(g,\"$8\"),f=a+\"?subid1\\x3d\"+generateSubtag(this)+\n\"\\x26u\\x3dhttps:\/\/www.apple.com\";0\u003C=d.indexOf(\"store.\")\u0026\u0026(f+=\"\/shop\");0\u003C=e.indexOf(\"us-hed\")\u0026\u0026(e=e.replace(\"\/us-hed\",\"\"));f+=e;$(this).attr(\"href\",f)}})})();function generateSubtag(a){var b=\"US-\"+",["escape",["macro",142],8,16],"+\"-\"+",["escape",["macro",32],8,16],"+\"-\",c=$(a).attr(\"data-vars-link-position-id\");a=$(a).attr(\"data-product-id\");b+=c?c+\"-\":\"000-\";b+=a?a+\"-\":\"000000-\";return b+=\"web\"};\u003C\/script\u003E"],
      "vtp_supportDocumentWrite":true,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "vtp_usePostscribe":true,
      "tag_id":20
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_overrideGaSettings":false,
      "vtp_trackType":"TRACK_PAGEVIEW",
      "vtp_gaSettings":["macro",95],
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_enableGA4Schema":false,
      "tag_id":5
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":["macro",98],
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":["macro",99],
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",95],
      "vtp_eventAction":["macro",97],
      "vtp_eventLabel":["macro",100],
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "vtp_enableGA4Schema":false,
      "tag_id":6
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":["macro",99],
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",95],
      "vtp_eventAction":["macro",102],
      "vtp_eventLabel":["macro",104],
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "vtp_enableGA4Schema":false,
      "tag_id":7
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":["macro",99],
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",95],
      "vtp_eventAction":["macro",97],
      "vtp_eventLabel":["macro",100],
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "vtp_enableGA4Schema":false,
      "tag_id":11
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":"YouTube Video",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",95],
      "vtp_eventAction":["macro",109],
      "vtp_eventLabel":["template",["macro",110]," - ",["macro",111]],
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "vtp_enableGA4Schema":false,
      "tag_id":13
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":true,
      "vtp_overrideGaSettings":true,
      "vtp_fieldsToSet":["list",["map","fieldName","transport","value","beacon"]],
      "vtp_eventCategory":"Engaged time",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_metric":["list",["map","index","1","metric",["macro",113]]],
      "vtp_eventAction":["macro",105],
      "vtp_eventLabel":["macro",113],
      "vtp_trackingId":["macro",68],
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "vtp_enableGA4Schema":false,
      "tag_id":14
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":["macro",99],
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",95],
      "vtp_eventAction":["macro",97],
      "vtp_eventLabel":["macro",100],
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "vtp_enableGA4Schema":false,
      "tag_id":15
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":"Outbound Link",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",95],
      "vtp_eventAction":["template",["macro",101]," - ",["macro",114]],
      "vtp_eventLabel":["macro",103],
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "vtp_enableGA4Schema":false,
      "tag_id":16
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":["macro",99],
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",95],
      "vtp_eventAction":["macro",97],
      "vtp_eventLabel":["macro",100],
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "vtp_enableGA4Schema":false,
      "tag_id":17
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":["macro",98],
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":["macro",99],
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",95],
      "vtp_eventAction":["macro",97],
      "vtp_eventLabel":["macro",100],
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "vtp_enableGA4Schema":false,
      "tag_id":18
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_overrideGaSettings":false,
      "vtp_trackType":"TRACK_PAGEVIEW",
      "vtp_gaSettings":["macro",95],
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_enableGA4Schema":false,
      "tag_id":19
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":21
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":22
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":["macro",99],
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",95],
      "vtp_eventAction":["macro",97],
      "vtp_eventLabel":["template",["macro",7]," | ",["macro",97]," | ",["macro",118]],
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "vtp_enableGA4Schema":false,
      "tag_id":26
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":"PDF",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",95],
      "vtp_eventAction":"Download",
      "vtp_eventLabel":["macro",114],
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "vtp_enableGA4Schema":false,
      "tag_id":27
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":["macro",121],
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":["macro",119],
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",95],
      "vtp_eventAction":["macro",122],
      "vtp_eventLabel":["macro",123],
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "vtp_enableGA4Schema":false,
      "tag_id":28
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":true,
      "vtp_overrideGaSettings":true,
      "vtp_eventCategory":"KickFire API",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_eventAction":"error",
      "vtp_eventLabel":["macro",124],
      "vtp_trackingId":["macro",125],
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "vtp_enableGA4Schema":false,
      "tag_id":34
    },{
      "function":"__ua",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_nonInteraction":true,
      "vtp_overrideGaSettings":true,
      "vtp_eventCategory":"KickFire API",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",95],
      "vtp_eventAction":"success",
      "vtp_dimension":["list",["map","index","68","dimension",["macro",126]],["map","index","71","dimension",["macro",127]],["map","index","72","dimension",["macro",128]],["map","index","69","dimension",["macro",129]],["map","index","73","dimension",["macro",130]],["map","index","74","dimension",["macro",131]],["map","index","85","dimension",["macro",132]]],
      "vtp_trackingId":["macro",125],
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "vtp_enableGA4Schema":false,
      "tag_id":35
    },{
      "function":"__paused",
      "vtp_originalTagType":"ua",
      "tag_id":36
    },{
      "function":"__ua",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":"Top Deals Module",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",95],
      "vtp_eventAction":["template",["macro",101]," - ",["macro",114]],
      "vtp_eventLabel":["macro",118],
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "vtp_enableGA4Schema":false,
      "tag_id":37
    },{
      "function":"__ua",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":"Bottom Deals Module",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",95],
      "vtp_eventAction":["template",["macro",101]," - ",["macro",114]],
      "vtp_eventLabel":["macro",118],
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "vtp_enableGA4Schema":false,
      "tag_id":38
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":39
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":40
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":49
    },{
      "function":"__ua",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_nonInteraction":true,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":"Video",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",95],
      "vtp_eventAction":["template","Floating Player Close - ",["macro",133]],
      "vtp_eventLabel":["macro",134],
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "vtp_enableGA4Schema":false,
      "tag_id":203
    },{
      "function":"__ua",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_nonInteraction":true,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":"InsiderPro",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",95],
      "vtp_eventAction":"Logged-in Page View",
      "vtp_eventLabel":["macro",100],
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "vtp_enableGA4Schema":false,
      "tag_id":205
    },{
      "function":"__ua",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_nonInteraction":true,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":"Dun and Bradstreet",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",95],
      "vtp_eventAction":"Visitor Intelligence Event",
      "vtp_eventLabel":["macro",118],
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "vtp_enableGA4Schema":false,
      "tag_id":235
    },{
      "function":"__ua",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":"Forms",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",95],
      "vtp_eventAction":["macro",101],
      "vtp_eventLabel":"Demand Gen",
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "vtp_enableGA4Schema":false,
      "tag_id":240
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":245
    },{
      "function":"__ua",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":"Forms",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",95],
      "vtp_eventAction":"submit",
      "vtp_eventLabel":"newsletters",
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "vtp_enableGA4Schema":false,
      "tag_id":253
    },{
      "function":"__zone",
      "once_per_event":true,
      "vtp_childContainers":["list",["map","publicId","GTM-NCMJGX","nickname",""]],
      "vtp_boundaries":["list",["zb","_eq",["macro",16],"cio",false,false]],
      "vtp_enableTypeRestrictions":false,
      "tag_id":307
    },{
      "function":"__zone",
      "once_per_event":true,
      "vtp_childContainers":["list",["map","publicId","GTM-WBVXW9","nickname",""]],
      "vtp_boundaries":["list",["zb","_eq",["macro",16],"computerworld",false,false]],
      "vtp_enableTypeRestrictions":false,
      "tag_id":308
    },{
      "function":"__zone",
      "once_per_event":true,
      "vtp_childContainers":["list",["map","publicId","GTM-5WC9SK","nickname",""]],
      "vtp_boundaries":["list",["zb","_eq",["macro",16],"cso online",false,false]],
      "vtp_enableTypeRestrictions":false,
      "tag_id":309
    },{
      "function":"__zone",
      "once_per_event":true,
      "vtp_childContainers":["list",["map","publicId","GTM-PMNRQM7","nickname",""]],
      "vtp_boundaries":["list",["zb","_eq",["macro",16],"gamestar",false,false]],
      "vtp_enableTypeRestrictions":false,
      "tag_id":310
    },{
      "function":"__zone",
      "once_per_event":true,
      "vtp_childContainers":["list",["map","publicId","GTM-TM76KR","nickname",""]],
      "vtp_boundaries":["list",["zb","_eq",["macro",16],"greenbot",false,false]],
      "vtp_enableTypeRestrictions":false,
      "tag_id":311
    },{
      "function":"__zone",
      "once_per_event":true,
      "vtp_childContainers":["list",["map","publicId","GTM-WD3CHM","nickname",""]],
      "vtp_boundaries":["list",["zb","_eq",["macro",16],"idg.tv",false,false]],
      "vtp_enableTypeRestrictions":false,
      "tag_id":312
    },{
      "function":"__zone",
      "once_per_event":true,
      "vtp_childContainers":["list",["map","publicId","GTM-5C7C8C","nickname",""]],
      "vtp_boundaries":["list",["zb","_eq",["macro",16],"infoworld",false,false]],
      "vtp_enableTypeRestrictions":false,
      "tag_id":313
    },{
      "function":"__zone",
      "once_per_event":true,
      "vtp_childContainers":["list",["map","publicId","GTM-TLL87H","nickname",""]],
      "vtp_boundaries":["list",["zb","_eq",["macro",16],"itnews",false,false]],
      "vtp_enableTypeRestrictions":false,
      "tag_id":314
    },{
      "function":"__zone",
      "once_per_event":true,
      "vtp_childContainers":["list",["map","publicId","GTM-TP6NS4","nickname",""]],
      "vtp_boundaries":["list",["zb","_eq",["macro",16],"itworld",false,false]],
      "vtp_enableTypeRestrictions":false,
      "tag_id":315
    },{
      "function":"__zone",
      "once_per_event":true,
      "vtp_childContainers":["list",["map","publicId","GTM-MMJKZ9","nickname","www.javaworld.com"]],
      "vtp_boundaries":["list",["zb","_eq",["macro",16],"javaworld",false,false]],
      "vtp_enableTypeRestrictions":false,
      "tag_id":316
    },{
      "function":"__zone",
      "once_per_event":true,
      "vtp_childContainers":["list",["map","publicId","GTM-WHLJC4","nickname","www.macworld.com"]],
      "vtp_boundaries":["list",["zb","_eq",["macro",16],"macworld",false,false]],
      "vtp_enableTypeRestrictions":false,
      "tag_id":317
    },{
      "function":"__zone",
      "once_per_event":true,
      "vtp_childContainers":["list",["map","publicId","GTM-P3S27S","nickname","www.networkworld.com"]],
      "vtp_boundaries":["list",["zb","_eq",["macro",16],"network world",false,false]],
      "vtp_enableTypeRestrictions":false,
      "tag_id":318
    },{
      "function":"__zone",
      "once_per_event":true,
      "vtp_childContainers":["list",["map","publicId","GTM-K7239P","nickname","www.pcworld.com"]],
      "vtp_boundaries":["list",["zb","_eq",["macro",16],"pcworld",false,false]],
      "vtp_enableTypeRestrictions":false,
      "tag_id":319
    },{
      "function":"__zone",
      "once_per_event":true,
      "vtp_childContainers":["list",["map","publicId","GTM-N9NGSK","nickname","www.techconnect.com"]],
      "vtp_boundaries":["list",["zb","_eq",["macro",16],"techconnect",false,false]],
      "vtp_enableTypeRestrictions":false,
      "tag_id":320
    },{
      "function":"__zone",
      "once_per_event":true,
      "vtp_childContainers":["list",["map","publicId","GTM-NZGV5J","nickname","www.techhive.com"]],
      "vtp_boundaries":["list",["zb","_eq",["macro",16],"techhive",false,false]],
      "vtp_enableTypeRestrictions":false,
      "tag_id":321
    },{
      "function":"__zone",
      "once_per_event":true,
      "vtp_childContainers":["list",["map","publicId","GTM-MFS6364","nickname","www.thefullnerd.com"]],
      "vtp_boundaries":["list",["zb","_eq",["macro",16],"thefullnerd",false,false]],
      "vtp_enableTypeRestrictions":false,
      "tag_id":322
    },{
      "function":"__zone",
      "once_per_event":true,
      "vtp_childContainers":["list",["map","publicId","GTM-WK5GFSL","nickname","IDG Connect"]],
      "vtp_boundaries":["list",["zb","_eq",["macro",16],"idg connect",false,false]],
      "vtp_enableTypeRestrictions":false,
      "tag_id":323
    },{
      "function":"__ytl",
      "vtp_progressThresholdsPercent":"25, 50, 75, 100",
      "vtp_captureComplete":false,
      "vtp_captureStart":true,
      "vtp_fixMissingApi":true,
      "vtp_radioButtonGroup1":"PERCENTAGE",
      "vtp_capturePause":true,
      "vtp_captureProgress":true,
      "vtp_uniqueTriggerId":"11064220_16",
      "vtp_enableTriggerStartOption":true,
      "tag_id":324
    },{
      "function":"__lcl",
      "vtp_waitForTags":true,
      "vtp_checkValidation":true,
      "vtp_waitForTagsTimeout":"2000",
      "vtp_uniqueTriggerId":"11064220_19",
      "tag_id":325
    },{
      "function":"__lcl",
      "vtp_waitForTags":false,
      "vtp_checkValidation":false,
      "vtp_waitForTagsTimeout":"2000",
      "vtp_uniqueTriggerId":"11064220_37",
      "tag_id":326
    },{
      "function":"__lcl",
      "vtp_waitForTags":false,
      "vtp_checkValidation":false,
      "vtp_waitForTagsTimeout":"2000",
      "vtp_uniqueTriggerId":"11064220_105",
      "tag_id":327
    },{
      "function":"__lcl",
      "vtp_waitForTags":false,
      "vtp_checkValidation":false,
      "vtp_waitForTagsTimeout":"2000",
      "vtp_uniqueTriggerId":"11064220_106",
      "tag_id":328
    },{
      "function":"__evl",
      "vtp_elementId":"bottomRightPlayer",
      "vtp_useOnScreenDuration":false,
      "vtp_useDomChangeListener":true,
      "vtp_firingFrequency":"MANY_PER_ELEMENT",
      "vtp_selectorType":"ID",
      "vtp_onScreenRatio":"25",
      "vtp_uniqueTriggerId":"11064220_192",
      "tag_id":329
    },{
      "function":"__cl",
      "tag_id":330
    },{
      "function":"__cl",
      "tag_id":331
    },{
      "function":"__html",
      "once_per_event":true,
      "vtp_html":"\n\n\u003Cscript type=\"text\/gtmscript\"\u003E(function(){var d=(new Date).getTime(),a=0,h=0,b=!0,g=!1,k=function(){h=(new Date).getTime();a+=h-d;b=!0},e=function(a){b\u0026\u0026(b=!1,d=(new Date).getTime(),g=!1);window.clearTimeout(l);l=window.setTimeout(k,5E3)},c=function(a,b){window.addEventListener?window.addEventListener(a,b):window.attachEvent\u0026\u0026window.attachEvent(\"on\"+a,b)},f=function(c){b||(a+=(new Date).getTime()-d);!g\u0026\u00260\u003Ca\u0026\u002636E5\u003Ea\u0026\u0026window.dataLayer.push({event:\"nonIdle\",nonIdleTimeElapsed:a});b\u0026\u0026(g=!0);c\u0026\u0026\"beforeunload\"===c.type\u0026\u0026window.removeEventListener(\"beforeunload\",\nf);a=0;d=(new Date).getTime();window.setTimeout(f,15E3)};c(\"mousedown\",e);c(\"keydown\",e);c(\"scroll\",e);c(\"mousemove\",e);c(\"beforeunload\",f);var l=window.setTimeout(k,5E3);window.setTimeout(f,15E3)})();\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":1
    },{
      "function":"__html",
      "once_per_event":true,
      "vtp_html":["template","\u003Cscript type=\"text\/gtmscript\"\u003Evar firstSessionDate=",["escape",["macro",11],8,16],",lastSessionDate=",["escape",["macro",12],8,16],",currentSessionDate=",["escape",["macro",138],8,16],",sessionNumber=",["escape",["macro",14],8,16],"||1,inSession=",["escape",["macro",139],8,16],",daysSinceLastSession=0,currentTime=new Date,longExpiry=15768E8;\nif(\"undefined\"===typeof firstSessionDate)",["escape",["macro",140],8,16],"(\"inSession\",!0,18E5,\"\/\"),lastSessionDate=firstSessionDate=currentSessionDate=currentTime.toUTCString(),",["escape",["macro",140],8,16],"(\"firstSessionDate\",firstSessionDate,longExpiry,\"\/\"),",["escape",["macro",140],8,16],"(\"currentSessionDate\",currentSessionDate,longExpiry,\"\/\"),",["escape",["macro",140],8,16],"(\"sessionNumber\",sessionNumber,longExpiry,\"\/\"),",["escape",["macro",140],8,16],"(\"lastSessionDate\",lastSessionDate,longExpiry,\"\/\");else if(\"undefined\"===typeof inSession\u0026\u0026(",["escape",["macro",140],8,16],"(\"inSession\",\n!0,18E5,\"\/\"),sessionNumber=+sessionNumber+1,",["escape",["macro",140],8,16],"(\"sessionNumber\",sessionNumber,longExpiry,\"\/\"),lastSessionDate=currentSessionDate,",["escape",["macro",140],8,16],"(\"lastSessionDate\",lastSessionDate,longExpiry,\"\/\"),currentSessionDate=currentTime.toUTCString(),",["escape",["macro",140],8,16],"(\"currentSessionDate\",currentSessionDate,longExpiry,\"\/\")),\"undefined\"!=typeof lastSessionDate){var lastSessionMS=(new Date(lastSessionDate)).getTime();daysSinceLastSession=Math.round((currentTime.getTime()-lastSessionMS)\/\n864E5)}dataLayer.push({event:\"Session Vars Set\",daysSinceLastSession:daysSinceLastSession,firstSessionDate:firstSessionDate,lastSessionDate:lastSessionDate,sessionNumber:sessionNumber});\u003C\/script\u003E"],
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":8
    },{
      "function":"__html",
      "once_per_event":true,
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\"\u003E\/*\n @preserve\n jquery.scrolldepth.js | v1.0\n Copyright (c) 2016 Rob Flaherty (@robflaherty)\n Licensed under the MIT and GPL licenses.\n*\/\n(function(a){\"function\"===typeof define\u0026\u0026define.amd?define([\"jquery\"],a):\"object\"===typeof module\u0026\u0026module.exports?module.exports=a(require(\"jquery\")):a(jQuery)})(function(a){var p={minHeight:0,percentage:!0,pixelDepth:!0,nonInteraction:!0,gtmOverride:!1,trackerName:!1,dataLayer:\"dataLayer\"},f=a(window),g=[],h=0,m;a.scrollDepth=function(b){function q(c,a,e,v){if(m\u0026\u0026b.pixelDepth\u0026\u00262\u003Carguments.length\u0026\u0026e\u003Eh){h=e;var d=!0;\"undefined\"!==typeof a\u0026\u0026\"25%\"!==a\u0026\u0026(d=!1);m({event:\"ScrollDistance\",scrollEventCategory:\"Scroll Depth\",\nscrollEventAction:a,scrollEventLabel:(250*Math.floor(e\/250)).toString()+\"px\",eventValue:1,eventNonInteraction:d})}}function r(c,d,e){a.each(c,function(c,b){-1===a.inArray(c,g)\u0026\u0026d\u003E=b\u0026\u0026(q(\"Percentage\",c,d,e),g.push(c))})}function t(c,a){var b,d,f,k=null,l=0,g=function(){l=new Date;k=null;f=c.apply(b,d)};return function(){var e=new Date;l||(l=e);var h=a-(e-l);b=this;d=arguments;0\u003E=h?(clearTimeout(k),k=null,l=e,f=c.apply(b,d)):k||(k=setTimeout(g,h));return f}}function n(){f.on(\"scroll.scrollDepth\",t(function(){var c=\na(document).height(),d=window.innerHeight?window.innerHeight:f.height();d=f.scrollTop()+d;c={\"25%\":parseInt(.25*c,10),\"50%\":parseInt(.5*c,10),\"75%\":parseInt(.75*c,10),\"100%\":c-5};var e=+new Date-u;g.length\u003E=(b.percentage?4:0)?f.off(\"scroll.scrollDepth\"):b.percentage\u0026\u0026r(c,d,e)},500))}var u=+new Date;b=a.extend({},p,b);a(document).height()\u003Cb.minHeight||(a.scrollDepth.reset=function(){g=[];h=0;f.off(\"scroll.scrollDepth\");n()},n(),\"undefined\"===typeof window[b.dataLayer]||\"function\"!==typeof window[b.dataLayer].push||\nb.gtmOverride||(m=function(a){window[b.dataLayer].push(a)}))};return a.scrollDepth});\u003C\/script\u003E\n\u003Cscript type=\"text\/gtmscript\"\u003EjQuery(function(){jQuery.scrollDepth()});window.addEventListener(\"beforeunload\",function(a){dataLayer.push({event:\"pushOnUnload\"})});\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":9
    },{
      "function":"__html",
      "once_per_event":true,
      "vtp_html":"\n\u003Cscript data-gtmsrc=\"https:\/\/w.soundcloud.com\/player\/api.js\" type=\"text\/gtmscript\"\u003E\u003C\/script\u003E\n\n\u003Cscript type=\"text\/gtmscript\"\u003E(function(){try{var q=function(l){var a,c,b,m,n,e,f,h=\"SoundCloud\",d=SC.Widget(l),g=0;d.bind(SC.Widget.Events.READY,function(){d.bind(SC.Widget.Events.PLAY,function(){1E3\u003CDate.now()-g\u0026\u0026d.getCurrentSound(function(c){f=c.title;a=\"Play\";k(h,a,f);g=Date.now()})});d.bind(SC.Widget.Events.PAUSE,function(b){c=Math.round(100*b.relativePosition);100!==c\u0026\u0026(a=\"Pause\",k(h,a,f))});d.bind(SC.Widget.Events.PLAY_PROGRESS,function(d){e=!1;c=Math.round(100*d.relativePosition);25!==c||b||(a=\"25%\",e=b=!0);50!==c||m||\n(a=\"50%\",e=m=!0);75!==c||n||(a=\"75%\",e=n=!0);e\u0026\u0026k(h,a,f)});d.bind(SC.Widget.Events.FINISH,function(){a=\"100%\";b=m=n=!1;k(h,a,f)})})},k=function(b,a,c){window.dataLayer.push({event:\"scEvent\",eventCategory:b,eventAction:a,eventLabel:c})},g,p=document.querySelectorAll('iframe[src*\\x3d\"soundcloud.com\"]');var b=0;for(g=p.length;b\u003Cg;b+=1)q(p[b])}catch(l){console.log(\"Error with SoundCloud API: \"+l.message)}})();\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":12
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":["template","\u003Cscript type=\"text\/javascript\" src=\"\/\/s.skimresources.com\/js\/",["escape",["macro",143],3],".skimlinks.js\"\u003E\u003C\/script\u003E"],
      "vtp_supportDocumentWrite":true,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "vtp_usePostscribe":true,
      "tag_id":23
    },{
      "function":"__html",
      "metadata":["map"],
      "consent":["list"],
      "once_per_event":true,
      "vtp_html":"\u003Cstyle type=\"text\/css\"\u003E\n  .cnx-main-container {\n    margin-bottom: 28px;\n    margin-top: 28px;\n    max-width: 620px;\n  }\n\u003C\/style\u003E\n\n\u003Cscript\u003E(function(){var a=document.createElement(\"script\");a.innerHTML=\"!function(n){if(!window.cnx){window.cnx\\x3d{},window.cnx.cmd\\x3d[];var t\\x3dn.createElement('iframe');t.display\\x3d'none',t.onload\\x3dfunction(){var n\\x3dt.contentWindow.document,c\\x3dn.createElement('script');c.src\\x3d'\/\/cd.connatix.com\/connatix.player.js',c.setAttribute('async','1'),c.setAttribute('type','text\/javascript'),n.body.appendChild(c)},n.head.appendChild(t)}}(document);\";var b=document.getElementsByTagName(\"script\")[0];b.parentNode.insertBefore(a,\nb)})();\u003C\/script\u003E\n\n\u003Cscript\u003E(function(){var a=document.createElement(\"script\");a.id=\"88990b565df74130866df3c5af8a7768\";a.innerHTML=\"cnx.cmd.push(function() {    cnx({ playerId: '9e434f42-aee5-4c3f-a75f-38ccb7eee878' }).render('88990b565df74130866df3c5af8a7768');  });\";var b=document.getElementsByTagName(\"script\")[1];b.parentNode.insertBefore(a,b)})();\u003C\/script\u003E",
      "vtp_supportDocumentWrite":true,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "vtp_usePostscribe":true,
      "tag_id":24
    },{
      "function":"__html",
      "metadata":["map"],
      "consent":["list"],
      "once_per_load":true,
      "vtp_html":["template","\u003Cscript type=\"text\/gtmscript\"\u003E$(document).ready(function(){var a=",["escape",["macro",146],8,16],";\"undefined\"===typeof a\u0026\u0026dataLayer.push({event:\"cntxReady\"})});\u003C\/script\u003E"],
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":25
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":["template","\u003Cscript type=\"text\/gtmscript\"\u003Evar cookieName=\"kickfireWatchlist\",cookieValue=\"",["escape",["macro",130],7],"\",expires=new Date;expires.setTime(expires.getTime()+6E4*kickfireGTM.session_timeout);document.cookie=cookieName+\"\\x3d\"+cookieValue+\"; expires\\x3d\"+expires.toUTCString()+\"; path\\x3d\/; domain\\x3d.\"+location.hostname.replace(\/^www\\.\/i,\"\");\u003C\/script\u003E"],
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":42
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":["template","\u003Cdiv class=\"brVideoContainer\" itemscope itemtype=\"http:\/\/schema.org\/VideoObject\"\u003E\n\t\u003Cdiv class=\"outer-wrapper\"\u003E\n      \u003Cimg onclick=\"jwplayer(\u0026#39;bottomRightPlayer\u0026#39;).remove(); this.style.display = \u0026#39;none\u0026#39;;\" id=\"jw-standalone-close-button\" src=\"data:image\/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAUCAYAAACNiR0NAAAABGdBTUEAALGPC\/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAACXBIWXMAAA3XAAAN1wFCKJt4AAABWWlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iWE1QIENvcmUgNS40LjAiPgogICA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogICAgICA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIgogICAgICAgICAgICB4bWxuczp0aWZmPSJodHRwOi8vbnMuYWRvYmUuY29tL3RpZmYvMS4wLyI+CiAgICAgICAgIDx0aWZmOk9yaWVudGF0aW9uPjE8L3RpZmY6T3JpZW50YXRpb24+CiAgICAgIDwvcmRmOkRlc2NyaXB0aW9uPgogICA8L3JkZjpSREY+CjwveDp4bXBtZXRhPgpMwidZAAABOklEQVQ4Ea2V3U7DMAxGV8QN3OyBB+oDdK\/L75DKOV0cmdC0EizSp7iJfWwvbXaY5\/mIJnUoA\/s+7N6cfSKe+XgoD1\/ML+gpANhdaN4zBr2iC5ruCuCT+RGdWHx2bRgGk\/yCuuaePsX3hPmALq4tww1kFscbWqBuYldoYxujr8O5dpeh2eEHlIAMbmHVt62g77ikvbZZKmLqdLOTfSwsk49o96eJltuWItDTt3Kl7XCvtoldYyP5GnTEMQDv2MrhWq56HRZknKsDtlV9oBjam5XFexi8285kz9WNPP+95QaWXx+h7aF0X\/61w8gwA\/MBjDzH6a9DcchttrB6APHj4t\/1yazlQ2fh\/5+emQF5BXVhqbqtbq6XAyAv1zjN3S8A3wyNu5DlhTFZ3Rl59+3CNio1VsZZ4E3\/Ar4BuSbVUBIuWisAAAAASUVORK5CYII=\"\u003E\n      \u003Cdiv id=\"bottomRightPlayer\"\u003E\u003C\/div\u003E\n\t\u003C\/div\u003E\n\u003C\/div\u003E\n\n\u003Cstyle\u003E\n@media only screen and (max-width: 929px) {\n\t.brVideoContainer {\n    \twidth: 100%;\n  \t\theight: auto;\n  \t\tdisplay: inline-block;\n        position: relative;\n  \t\tborder: none;\n  \t\toverflow: hidden;\n  \t\tz-index: 10000;\n\t}\n  \t#bottomRightPlayer {\n      \tmargin-bottom: 10px;\n    }\n    .margin-col .brVideoContainer,\n  \t.main-col .brVideoContainer {\n      \tmargin-top: 20px;\n  \t}\n}\n@media only screen and (min-width: 930px) {\n\t.brVideoContainer {\n  \t\tbottom: 5px;\n  \t\tright: 5px;\n  \t\twidth: 401px;\n  \t\theight: 225px;\n      \tposition: fixed;\n        border: none;\n      \toverflow: hidden;\n  \t\tz-index: 10000;\n\t}\n}\n\n.brVideoContainer .outer-wrapper {\n\tmargin: 0 auto;\n    max-width: 600px;\n  \ttop: 0px;\n  \tleft: 0px;\n  \twidth: 100%;\n  \theight: 100%;\n  \tborder: none;\n  \toverflow: hidden;\n  \tposition: relative;\n}\n\n#jw-standalone-close-button {\n  position: absolute;\n  top: 5%;\n  right: 3%;\n  display: inline;\n  z-index: 999999;\n  height: 20px;\n  width: 20px;\n}\n\u003C\/style\u003E\n\n\u003Cscript type=\"text\/gtmscript\"\u003E$(function(){0\u003C$(\"#drr-container\").length\u0026\u0026$(\"article .bodee #drr-container p:nth-of-type(4)\").after($(\".brVideoContainer\"));0\u003C$(\".main-col\").length\u0026\u0026$(\".main-col \\x3e div:nth-of-type(6)\").after($(\".brVideoContainer\"));0\u003C$(\".landing-listing\").length\u0026\u0026$(\".landing-listing \\x3e div:nth-of-type(6)\").after($(\".brVideoContainer\"));0\u003C$(\"body#search .search-results\").length\u0026\u0026$(\".search-results \\x3e div.river-well:nth-of-type(6)\").after($(\".brVideoContainer\"));0\u003C$(\".gsc-result\").length\u0026\u0026$(\".gsc-expansionArea \\x3e div.gsc-result:nth-of-type(6)\").after($(\".brVideoContainer\"))});\u003C\/script\u003E\n\n\u003Cscript data-gtmsrc=\"https:\/\/cdn.jwplayer.com\/libraries\/",["escape",["macro",149],3],".js\" type=\"text\/gtmscript\"\u003E\u003C\/script\u003E\n\u003Cscript type=\"text\/gtmscript\"\u003Econsent.ads.queue.push(function(){var b={dlm:googletag.pubads().getTargeting(\"dlm\"),fr:googletag.pubads().getTargeting(\"fr\"),grm:googletag.pubads().getTargeting(\"grm\"),vw:googletag.pubads().getTargeting(\"vw\"),URL:IDG.GPT.targets.URL,articleId:IDG.GPT.targets.articleId,blogId:IDG.GPT.targets.blogId,categoryIds:IDG.GPT.targets.categoryIds,categorySlugs:IDG.GPT.targets.categorySlugs,channel:IDG.GPT.targets.channel,env:IDG.GPT.targets.env,goldenIds:IDG.GPT.targets.goldenIds,pagetype:adLayer.itemType,\npermutive:localStorage.getItem(\"_pdfps\"),playertype:\"bottomRightPlayer\",pos:\"bottom_right\",positiondata:buildPositionData(\"bottom_right\"),sponsored:IDG.GPT.targets.sponsored,zone:IDG.GPT.targets.zone},c=\"https:\/\/pubads.g.doubleclick.net\/gampad\/ads?sz\\x3d640x480\\x26iu\\x3d\"+IDG.GPT.unitName+\"\\x26ciu_szs\\x3d300x250,728x90\\x26impl\\x3ds\\x26gdfp_req\\x3d1\\x26env\\x3dvp\\x26output\\x3dvast\\x26unviewed_position_start\\x3d1\\x26description_url\\x3dhttp%3A%2F%2Fwww.",["escape",["macro",150],7],"\\x26url\\x3d[referrer_url]\\x26correlator\\x3d[timestamp]\",\nd=[{tag:c,offset:\"pre\",custParams:b}];if(\"macworld\"==",["escape",["macro",16],8,16],")for(var a=30;1200\u003E=a;a+=30)d.push({tag:c,offset:a,custParams:b});jwplayer(\"bottomRightPlayer\").setup({playlist:\"https:\/\/cdn.jwplayer.com\/v2\/playlists\/",["escape",["macro",151],7],"?search\\x3d__CONTEXTUAL__\",advertising:{client:\"googima\",adscheduleid:\"",["escape",["macro",152],7],"\",schedule:d}})});\u003C\/script\u003E"],
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":45
    },{
      "function":"__html",
      "metadata":["map"],
      "consent":["list"],
      "once_per_load":true,
      "vtp_html":["template","\u003Cscript type=\"text\/gtmscript\"\u003E(function(a,b,c,d){a=b.createElement(c);b=b.getElementsByTagName(c)[0];a.async=1;a.src=d;a.setAttribute(\"data-cfasync\",\"false\");b.parentNode.insertBefore(a,b)})(window,document,\"script\",\"https:\/\/intent.",["escape",["macro",150],7],"\/analytics.js\");\u003C\/script\u003E"],
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":46
    },{
      "function":"__html",
      "metadata":["map"],
      "consent":["list"],
      "once_per_event":true,
      "vtp_html":"\n\u003Cscript type=\"text\/gtmscript\"\u003E(function(){var a=document.createElement(\"script\");a.async=!0;a.type=\"text\/javascript\";a.src=\"https:\/\/s.ntv.io\/js\/nativoIQ.js\";a.className=\"ntv-site-analytics\";a.setAttribute(\"ntv-brand-id\",\"184\");var b=document.getElementsByTagName(\"script\")[0];b.parentNode.insertBefore(a,b)})();\u003C\/script\u003E\n\n\u003Cstyle\u003E\n@media only screen and (min-width: 60.625em){\n  article.blog .cat-social.sponsored {\n      margin-right: auto;\n      margin-left: auto;\n  }\n}\n\u003C\/style\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":50
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\"\u003Evar floatingPlayerStatus={};jwplayer(\"bottomRightPlayer\").on(\"adTime\",function(a){0==jwplayer(\"bottomRightPlayer\").getCurrentTime()?floatingPlayerStatus.label=\"Preroll\":floatingPlayerStatus.label=\"Midroll\";floatingPlayerStatus.time=Math.round(a.position)});jwplayer(\"bottomRightPlayer\").on(\"time\",function(a){floatingPlayerStatus.label=\"Video Content\";floatingPlayerStatus.time=Math.round(jwplayer(\"bottomRightPlayer\").getCurrentTime())});\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":211
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cscript data-gtmsrc=\"https:\/\/www.knotch-cdn.com\/unit\/latest\/knotch.min.js\" async type=\"text\/gtmscript\"\u003E\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":247
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cdiv class=\"knotch_cf6b6fb2-b9c4-425c-8f51-1df0fa8fb11c\"\u003E\u003C\/div\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":260
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":"\u003Cdiv class=\"knotch_f4844125-e06a-4a7a-bcdd-38e10773bb38\"\u003E\u003C\/div\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":262
    },{
      "function":"__html",
      "metadata":["map"],
      "consent":["list"],
      "once_per_event":true,
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\"\u003E$(document).ready(function(){if(-1\u003Cwindow.location.href.indexOf(\"Hewlett%2BPackard%2BEnterprise%2B%2528HPE%2529\")){var a=window.location.href;a=a.replace(\"Hewlett%2BPackard%2BEnterprise%2B%2528HPE%2529\",\"Hewlett%2BPackard%2BEnterprise%2B%28HPE%29\");window.location.replace(a)}});\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":306
    }],
  "predicates":[{
      "function":"_eq",
      "arg0":["macro",0],
      "arg1":"true"
    },{
      "function":"_eq",
      "arg0":["macro",1],
      "arg1":"gtm.dom"
    },{
      "function":"_re",
      "arg0":["macro",1],
      "arg1":"^(moduleImpression|moduleClick|optimizeEvent|formSubmit)$"
    },{
      "function":"_re",
      "arg0":["macro",1],
      "arg1":"(externalLink|affiliateLink|socialLink|socialShare)"
    },{
      "function":"_eq",
      "arg0":["macro",1],
      "arg1":"scEvent"
    },{
      "function":"_cn",
      "arg0":["macro",105],
      "arg1":"\/article\/"
    },{
      "function":"_eq",
      "arg0":["macro",1],
      "arg1":"gtm.video"
    },{
      "function":"_re",
      "arg0":["macro",106],
      "arg1":"(^$|((^|,)11064220_16($|,)))"
    },{
      "function":"_eq",
      "arg0":["macro",1],
      "arg1":"nonIdle"
    },{
      "function":"_eq",
      "arg0":["macro",1],
      "arg1":"editBodyLink"
    },{
      "function":"_re",
      "arg0":["macro",114],
      "arg1":"cio.com|csoonline.com|computerworld.com|itnews.com|itworld.com|infoworld.com|networkworld.com|javaworld.com|techconnect.com|techhive.com|macworld.com|pcworld.com|greenbot.com"
    },{
      "function":"_css",
      "arg0":["macro",115],
      "arg1":"#drr-container a"
    },{
      "function":"_eq",
      "arg0":["macro",1],
      "arg1":"gtm.linkClick"
    },{
      "function":"_re",
      "arg0":["macro",106],
      "arg1":"(^$|((^|,)11064220_19($|,)))"
    },{
      "function":"_eq",
      "arg0":["macro",1],
      "arg1":"promoModuleLink"
    },{
      "function":"_eq",
      "arg0":["macro",1],
      "arg1":"videoEvent"
    },{
      "function":"_eq",
      "arg0":["macro",1],
      "arg1":"slidePage"
    },{
      "function":"_eq",
      "arg0":["macro",1],
      "arg1":"Video Refresh"
    },{
      "function":"_eq",
      "arg0":["macro",7],
      "arg1":"us"
    },{
      "function":"_eq",
      "arg0":["macro",116],
      "arg1":"omit"
    },{
      "function":"_eq",
      "arg0":["macro",1],
      "arg1":"gtm.js"
    },{
      "function":"_eq",
      "arg0":["macro",64],
      "arg1":"true"
    },{
      "function":"_cn",
      "arg0":["macro",6],
      "arg1":"Error"
    },{
      "function":"_eq",
      "arg0":["macro",117],
      "arg1":"true"
    },{
      "function":"_re",
      "arg0":["macro",57],
      "arg1":"[\\D|\\s]1102[\\D|\\s]|^1102\\D|\\D1102$|[\\D|\\s]84[\\D|\\s]|^84\\D|\\D84$|[\\D|\\s]222[\\D|\\s]|^222\\D|\\D222$|[\\D|\\s]478[\\D|\\s]|^478\\D|\\D478$|[\\D|\\s]480[\\D|\\s]|^480\\D|\\D480$|[\\D|\\s]625[\\D|\\s]|^625\\D|\\D625$|[\\D|\\s]78[\\D|\\s]|^78\\D|\\D78$|[\\D|\\s]91[\\D|\\s]|^91\\D|\\D91$|[\\D|\\s]20[\\D|\\s]|^20\\D|\\D20$|[\\D|\\s]44[\\D|\\s]|^44\\D|\\D44$|[\\D|\\s]169[\\D|\\s]|^169\\D|\\D169$|[\\D|\\s]527[\\D|\\s]|^527\\D|\\D527$|[\\D|\\s]530[\\D|\\s]|^530\\D|\\D530$|[\\D|\\s]472[\\D|\\s]|^472\\D|\\D472$|[\\D|\\s]765[\\D|\\s]|^765\\D|\\D765$|[\\D|\\s]626[\\D|\\s]|^626\\D|\\D626$|[\\D|\\s]676[\\D|\\s]|^676\\D|\\D676$|[\\D|\\s]510[\\D|\\s]|^510\\D|\\D510$|[\\D|\\s]910[\\D|\\s]|^910\\D|\\D910$|[\\D|\\s]266[\\D|\\s]|^266\\D|\\D266$|[\\D|\\s]514[\\D|\\s]|^514\\D|\\D514$|[\\D|\\s]134[\\D|\\s]|^134\\D|\\D134$|[\\D|\\s]108[\\D|\\s]|^108\\D|\\D108$|[\\D|\\s]994[\\D|\\s]|^994\\D|\\D994$|[\\D|\\s]330[\\D|\\s]|^330\\D|\\D330$|[\\D|\\s]790[\\D|\\s]|^790\\D|\\D790$|[\\D|\\s]938[\\D|\\s]|^938\\D|\\D938$|[\\D|\\s]646[\\D|\\s]|^646\\D|\\D646$|[\\D|\\s]796[\\D|\\s]|^796\\D|\\D796$|[\\D|\\s]235[\\D|\\s]|^235\\D|\\D235$|[\\D|\\s]1147[\\D|\\s]|^1147\\D|\\D1147$|[\\D|\\s]450[\\D|\\s]|^450\\D|\\D450$|[\\D|\\s]441[\\D|\\s]|^441\\D|\\D441$|[\\D|\\s]937[\\D|\\s]|^937\\D|\\D937$|[\\D|\\s]63[\\D|\\s]|^63\\D|\\D63$|[\\D|\\s]936[\\D|\\s]|^936\\D|\\D936$|[\\D|\\s]841[\\D|\\s]|^841\\D|\\D841$|[\\D|\\s]913[\\D|\\s]|^913\\D|\\D913$|[\\D|\\s]466[\\D|\\s]|^466\\D|\\D466$|[\\D|\\s]334[\\D|\\s]|^334\\D|\\D334$|[\\D|\\s]675[\\D|\\s]|^675\\D|\\D675$|[\\D|\\s]911[\\D|\\s]|^911\\D|\\D911$|[\\D|\\s]467[\\D|\\s]|^467\\D|\\D467$|[\\D|\\s]155[\\D|\\s]|^155\\D|\\D155$|[\\D|\\s]123[\\D|\\s]|^123\\D|\\D123$|[\\D|\\s]238[\\D|\\s]|^238\\D|\\D238$|[\\D|\\s]464[\\D|\\s]|^464\\D|\\D464$|[\\D|\\s]853[\\D|\\s]|^853\\D|\\D853$|[\\D|\\s]228[\\D|\\s]|^228\\D|\\D228$",
      "ignore_case":true
    },{
      "function":"_re",
      "arg0":["macro",16],
      "arg1":"cio|cso|computerworld|infoworld|network"
    },{
      "function":"_eq",
      "arg0":["macro",1],
      "arg1":"editionChange"
    },{
      "function":"_cn",
      "arg0":["macro",114],
      "arg1":".pdf"
    },{
      "function":"_re",
      "arg0":["macro",106],
      "arg1":"(^$|((^|,)11064220_37($|,)))"
    },{
      "function":"_eq",
      "arg0":["macro",119],
      "arg1":"Scroll Depth"
    },{
      "function":"_eq",
      "arg0":["macro",1],
      "arg1":"pushOnUnload"
    },{
      "function":"_eq",
      "arg0":["macro",105],
      "arg1":"\/"
    },{
      "function":"_re",
      "arg0":["macro",120],
      "arg1":"cio|computerworld",
      "ignore_case":true
    },{
      "function":"_eq",
      "arg0":["macro",1],
      "arg1":"kickfire-api-error"
    },{
      "function":"_eq",
      "arg0":["macro",1],
      "arg1":"kickfire-api-success"
    },{
      "function":"_re",
      "arg0":["macro",26],
      "arg1":"4309|3443|3376|3255|3378|3374|3375|3712|3379|3377|3793|4791|3298|4774",
      "ignore_case":true
    },{
      "function":"_eq",
      "arg0":["macro",1],
      "arg1":"gtm.load"
    },{
      "function":"_css",
      "arg0":["macro",115],
      "arg1":".techDeals a"
    },{
      "function":"_re",
      "arg0":["macro",106],
      "arg1":"(^$|((^|,)11064220_105($|,)))"
    },{
      "function":"_css",
      "arg0":["macro",115],
      "arg1":".topDeals a"
    },{
      "function":"_re",
      "arg0":["macro",106],
      "arg1":"(^$|((^|,)11064220_106($|,)))"
    },{
      "function":"_re",
      "arg0":["macro",16],
      "arg1":"cio",
      "ignore_case":true
    },{
      "function":"_re",
      "arg0":["macro",57],
      "arg1":"[\\D|\\s]222[\\D|\\s]|^222\\D|\\D222$|[\\D|\\s]20[\\D|\\s]|^20\\D|\\D20$|[\\D|\\s]676[\\D|\\s]|^676\\D|\\D676$|[\\D|\\s]510[\\D|\\s]|^510\\D|\\D510$|[\\D|\\s]910[\\D|\\s]|^910\\D|\\D910$|[\\D|\\s]514[\\D|\\s]|^514\\D|\\D514$|[\\D|\\s]330[\\D|\\s]|^330\\D|\\D330$|[\\D|\\s]938[\\D|\\s]|^938\\D|\\D938$|[\\D|\\s]646[\\D|\\s]|^646\\D|\\D646$|[\\D|\\s]450[\\D|\\s]|^450\\D|\\D450$|[\\D|\\s]936[\\D|\\s]|^936\\D|\\D936$|[\\D|\\s]530[\\D|\\s]|^530\\D|\\530$|[\\D|\\s]134[\\D|\\s]|^134\\D|\\134$|[\\D|\\s]466[\\D|\\s]|^466\\D|\\466$|[\\D|\\s]123[\\D|\\s]|^123\\D|\\123$|[\\D|\\s]108[\\D|\\s]|^108\\D|\\108$|[\\D|\\s]480[\\D|\\s]|^480\\D|\\480$|[\\D|\\s]790[\\D|\\s]|^790\\D|\\790$|[\\D|\\s]527[\\D|\\s]|^527\\D|\\527$|[\\D|\\s]441[\\D|\\s]|^441\\D|\\441$|[\\D|\\s]91[\\D|\\s]|^91\\D|\\91$|[\\D|\\s]169[\\D|\\s]|^169\\D|\\169$|[\\D|\\s]63[\\D|\\s]|^63\\D|\\63$|[\\D|\\s]467[\\D|\\s]|^467\\D|\\467$|[\\D|\\s]911[\\D|\\s]|^911\\D|\\911$|[\\D|\\s]334[\\D|\\s]|^334\\D|\\334$",
      "ignore_case":true
    },{
      "function":"_cn",
      "arg0":["macro",105],
      "arg1":"\/resources"
    },{
      "function":"_eq",
      "arg0":["macro",15],
      "arg1":"staging"
    },{
      "function":"_css",
      "arg0":["macro",115],
      "arg1":"#jw-standalone-close-button"
    },{
      "function":"_eq",
      "arg0":["macro",1],
      "arg1":"gtm.click"
    },{
      "function":"_eq",
      "arg0":["macro",16],
      "arg1":"insiderpro"
    },{
      "function":"_eq",
      "arg0":["macro",78],
      "arg1":"true"
    },{
      "function":"_eq",
      "arg0":["macro",1],
      "arg1":"IP Logged In"
    },{
      "function":"_eq",
      "arg0":["macro",1],
      "arg1":"vicomplete"
    },{
      "function":"_css",
      "arg0":["macro",115],
      "arg1":"#reg_form div.reg-submit button"
    },{
      "function":"_eq",
      "arg0":["macro",1],
      "arg1":"Newsletter Reg Submit"
    },{
      "function":"_eq",
      "arg0":["macro",1],
      "arg1":"facebookConsentGiven"
    },{
      "function":"_eq",
      "arg0":["macro",135],
      "arg1":"true"
    },{
      "function":"_eq",
      "arg0":["macro",136],
      "arg1":"false"
    },{
      "function":"_eq",
      "arg0":["macro",137],
      "arg1":"false"
    },{
      "function":"_eq",
      "arg0":["macro",1],
      "arg1":"consentKnown"
    },{
      "function":"_eq",
      "arg0":["macro",6],
      "arg1":"home page"
    },{
      "function":"_eq",
      "arg0":["macro",141],
      "arg1":"true"
    },{
      "function":"_eq",
      "arg0":["macro",65],
      "arg1":"true"
    },{
      "function":"_re",
      "arg0":["macro",143],
      "arg1":"^[A-Z0-9]*$",
      "ignore_case":true
    },{
      "function":"_eq",
      "arg0":["macro",1],
      "arg1":"cntxReady"
    },{
      "function":"_eq",
      "arg0":["macro",40],
      "arg1":"false"
    },{
      "function":"_eq",
      "arg0":["macro",144],
      "arg1":"omit"
    },{
      "function":"_cn",
      "arg0":["macro",6],
      "arg1":"video"
    },{
      "function":"_cn",
      "arg0":["macro",105],
      "arg1":"learn-about-insider"
    },{
      "function":"_eq",
      "arg0":["macro",145],
      "arg1":"true"
    },{
      "function":"_eq",
      "arg0":["macro",1],
      "arg1":"twitterConsentGiven"
    },{
      "function":"_eq",
      "arg0":["macro",147],
      "arg1":"true"
    },{
      "function":"_eq",
      "arg0":["macro",148],
      "arg1":"true"
    },{
      "function":"_eq",
      "arg0":["macro",1],
      "arg1":"linkedinConsentGiven"
    },{
      "function":"_eq",
      "arg0":["macro",1],
      "arg1":"jwpReady"
    },{
      "function":"_re",
      "arg0":["macro",16],
      "arg1":"cio|computerworld|cso|infoworld|network world",
      "ignore_case":true
    },{
      "function":"_eq",
      "arg0":["macro",1],
      "arg1":"triblioConsentGiven"
    },{
      "function":"_eq",
      "arg0":["macro",153],
      "arg1":"true"
    },{
      "function":"_re",
      "arg0":["macro",48],
      "arg1":"CIO’s Guide to IT “As-a-Service”|Key Understandings: Security and IT “As-a-Service”|ITaaS 101 for Enterprise IT Leaders|Understanding ITaaS and Application Development|ITaaS and Corporate Storage Technology|Success At The Edge: Best Practices For CIOs",
      "ignore_case":true
    },{
      "function":"_re",
      "arg0":["macro",32],
      "arg1":"3575856|3575836|3575601|3574902|3575366|3575588|3575367|3575512"
    },{
      "function":"_eq",
      "arg0":["macro",1],
      "arg1":"gtm.elementVisibility"
    },{
      "function":"_re",
      "arg0":["macro",106],
      "arg1":"(^$|((^|,)11064220_192($|,)))"
    },{
      "function":"_eq",
      "arg0":["macro",1],
      "arg1":"dnbConsentGiven"
    },{
      "function":"_eq",
      "arg0":["macro",163],
      "arg1":"true"
    },{
      "function":"_re",
      "arg0":["macro",16],
      "arg1":"cio|computerworld|cso|infoworld|network world"
    },{
      "function":"_re",
      "arg0":["macro",48],
      "arg1":"A Foundation for Change|Ahead of the Pack"
    },{
      "function":"_cn",
      "arg0":["macro",105],
      "arg1":"blog\/a-foundation-for-change"
    },{
      "function":"_cn",
      "arg0":["macro",105],
      "arg1":"podcast\/aheadofthepack"
    },{
      "function":"_eq",
      "arg0":["macro",1],
      "arg1":"redditConsentGiven"
    },{
      "function":"_eq",
      "arg0":["macro",164],
      "arg1":"true"
    },{
      "function":"_re",
      "arg0":["macro",16],
      "arg1":"pcworld|macworld|techhive",
      "ignore_case":true
    }],
  "rules":[
    [["if",0,1],["add",8]],
    [["if",0,2],["add",9]],
    [["if",0,3],["add",10]],
    [["if",4],["add",11]],
    [["if",5,6,7],["add",12]],
    [["if",8],["add",13]],
    [["if",9],["add",14]],
    [["if",11,12,13],["unless",10],["add",15]],
    [["if",14],["add",16]],
    [["if",0,15],["add",17]],
    [["if",0,16],["add",18]],
    [["if",0,17],["add",18]],
    [["if",18,20],["unless",19],["add",19]],
    [["if",18,20],["add",20]],
    [["if",0,26],["add",21]],
    [["if",12,27,28],["add",22]],
    [["if",5,29,30],["add",23]],
    [["if",29,30,31,32],["add",23]],
    [["if",33],["add",24]],
    [["if",34],["add",25,70]],
    [["if",25,35,36],["add",26]],
    [["if",12,37,38],["add",27]],
    [["if",12,39,40],["add",28]],
    [["if",20,41],["add",29]],
    [["if",18,20,25,42],["add",30]],
    [["if",20,43],["add",31]],
    [["if",45,46],["add",32]],
    [["if",47,48,49],["add",33]],
    [["if",50],["add",34]],
    [["if",46,51],["add",35]],
    [["if",1,43],["add",36,78]],
    [["if",0,52],["add",37]],
    [["if",20],["add",38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,64,55,57,58,59,60,61,62]],
    [["if",20,21],["add",56,63],["block",19,67,6]],
    [["if",53],["add",3,4]],
    [["if",20,54],["add",3,4]],
    [["if",55,56,57],["add",3,1,2,4,5]],
    [["if",1,58],["add",65]],
    [["if",1,5],["add",65]],
    [["if",5,20],["add",66]],
    [["if",1,5,18,59],["add",7]],
    [["if",5,18,20,61],["add",67]],
    [["if",62],["add",68]],
    [["if",18,36,63],["unless",21,64],["add",69]],
    [["if",68],["add",1]],
    [["if",20,69],["add",1]],
    [["if",20,70],["add",2]],
    [["if",71],["add",2]],
    [["if",72],["add",71]],
    [["if",73,74],["add",72]],
    [["if",20,73,75],["add",72]],
    [["if",55,56,57,73],["add",72]],
    [["if",20,76],["add",73]],
    [["if",20,77],["add",73]],
    [["if",18,20,24,25],["block",19,7,67]],
    [["if",78,79],["add",74]],
    [["if",73,80],["add",0]],
    [["if",20,73,81],["add",0]],
    [["if",55,56,57,82],["add",0]],
    [["if",20,83],["add",75]],
    [["if",20,84],["add",76]],
    [["if",20,85],["add",77]],
    [["if",86],["add",5]],
    [["if",20,87],["add",5]],
    [["if",1,5,88],["add",6]],
    [["if",20,22],["block",19,20,3,67,1,2,4,5,6]],
    [["if",20,23],["block",19,7,67]],
    [["if",20,44],["block",31]],
    [["if",1,22],["block",65]],
    [["if",20,60],["block",7]],
    [["if",36,43],["block",69]],
    [["if",36,60],["block",69]],
    [["if",36,65],["block",69]],
    [["if",36,66],["block",69]],
    [["if",36,58],["block",69]],
    [["if",23,36],["block",69]],
    [["if",18,24,25,36],["block",69]],
    [["if",36,67],["block",69]]]
},
"runtime":[]




};
/*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
var aa,ba=function(a){var b=0;return function(){return b<a.length?{done:!1,value:a[b++]}:{done:!0}}},da=function(a){var b="undefined"!=typeof Symbol&&Symbol.iterator&&a[Symbol.iterator];return b?b.call(a):{next:ba(a)}},ea="function"==typeof Object.create?Object.create:function(a){var b=function(){};b.prototype=a;return new b},fa;
if("function"==typeof Object.setPrototypeOf)fa=Object.setPrototypeOf;else{var ia;a:{var ma={a:!0},na={};try{na.__proto__=ma;ia=na.a;break a}catch(a){}ia=!1}fa=ia?function(a,b){a.__proto__=b;if(a.__proto__!==b)throw new TypeError(a+" is not extensible");return a}:null}
var oa=fa,pa=function(a,b){a.prototype=ea(b.prototype);a.prototype.constructor=a;if(oa)oa(a,b);else for(var c in b)if("prototype"!=c)if(Object.defineProperties){var d=Object.getOwnPropertyDescriptor(b,c);d&&Object.defineProperty(a,c,d)}else a[c]=b[c];a.Mi=b.prototype},qa=this||self,ta=function(a){if(a&&a!=qa)return ra(a.document);null===sa&&(sa=ra(qa.document));return sa},ua=/^[\w+/_-]+[=]{0,2}$/,sa=null,ra=function(a){var b=a.querySelector&&a.querySelector("script[nonce]");if(b){var c=b.nonce||b.getAttribute("nonce");
if(c&&ua.test(c))return c}return""},va=function(a){return a};var xa=function(){},ya=function(a){return"function"==typeof a},g=function(a){return"string"==typeof a},za=function(a){return"number"==typeof a&&!isNaN(a)},Aa=function(a){return"[object Array]"==Object.prototype.toString.call(Object(a))},m=function(a,b){if(Array.prototype.indexOf){var c=a.indexOf(b);return"number"==typeof c?c:-1}for(var d=0;d<a.length;d++)if(a[d]===b)return d;return-1},Ba=function(a,b){if(a&&Aa(a))for(var c=0;c<a.length;c++)if(a[c]&&b(a[c]))return a[c]},Da=function(a,b){if(!za(a)||
!za(b)||a>b)a=0,b=2147483647;return Math.floor(Math.random()*(b-a+1)+a)},Ga=function(a,b){for(var c=new Ea,d=0;d<a.length;d++)c.set(a[d],!0);for(var e=0;e<b.length;e++)if(c.get(b[e]))return!0;return!1},Ia=function(a,b){for(var c in a)Object.prototype.hasOwnProperty.call(a,c)&&b(c,a[c])},Ja=function(a){return!!a&&("[object Arguments]"==Object.prototype.toString.call(a)||Object.prototype.hasOwnProperty.call(a,"callee"))},Ka=function(a){return Math.round(Number(a))||0},Ma=function(a){return"false"==
String(a).toLowerCase()?!1:!!a},Na=function(a){var b=[];if(Aa(a))for(var c=0;c<a.length;c++)b.push(String(a[c]));return b},Oa=function(a){return a?a.replace(/^\s+|\s+$/g,""):""},Pa=function(){return(new Date).getTime()},Ea=function(){this.prefix="gtm.";this.values={}};Ea.prototype.set=function(a,b){this.values[this.prefix+a]=b};Ea.prototype.get=function(a){return this.values[this.prefix+a]};
var Ra=function(a,b,c){return a&&a.hasOwnProperty(b)?a[b]:c},Sa=function(a){var b=a;return function(){if(b){var c=b;b=void 0;try{c()}catch(d){}}}},Ta=function(a,b){for(var c in b)b.hasOwnProperty(c)&&(a[c]=b[c])},Va=function(a){for(var b in a)if(a.hasOwnProperty(b))return!0;return!1},Wa=function(a,b){for(var c=[],d=0;d<a.length;d++)c.push(a[d]),c.push.apply(c,b[a[d]]||[]);return c},Za=function(a,b){for(var c={},d=c,e=a.split("."),f=0;f<e.length-1;f++)d=d[e[f]]={};d[e[e.length-1]]=b;return c},$a=function(a){var b=
[];Ia(a,function(c,d){10>c.length&&d&&b.push(c)});return b.join(",")};/*
 jQuery v1.9.1 (c) 2005, 2012 jQuery Foundation, Inc. jquery.org/license. */
var db=/\[object (Boolean|Number|String|Function|Array|Date|RegExp)\]/,eb=function(a){if(null==a)return String(a);var b=db.exec(Object.prototype.toString.call(Object(a)));return b?b[1].toLowerCase():"object"},fb=function(a,b){return Object.prototype.hasOwnProperty.call(Object(a),b)},gb=function(a){if(!a||"object"!=eb(a)||a.nodeType||a==a.window)return!1;try{if(a.constructor&&!fb(a,"constructor")&&!fb(a.constructor.prototype,"isPrototypeOf"))return!1}catch(c){return!1}for(var b in a);return void 0===
b||fb(a,b)},C=function(a,b){var c=b||("array"==eb(a)?[]:{}),d;for(d in a)if(fb(a,d)){var e=a[d];"array"==eb(e)?("array"!=eb(c[d])&&(c[d]=[]),c[d]=C(e,c[d])):gb(e)?(gb(c[d])||(c[d]={}),c[d]=C(e,c[d])):c[d]=e}return c};var hb=function(a){if(void 0===a||Aa(a)||gb(a))return!0;switch(typeof a){case "boolean":case "number":case "string":case "function":return!0}return!1};
var ib=[],kb={"\x00":"&#0;",'"':"&quot;","&":"&amp;","'":"&#39;","<":"&lt;",">":"&gt;","\t":"&#9;","\n":"&#10;","\x0B":"&#11;","\f":"&#12;","\r":"&#13;"," ":"&#32;","-":"&#45;","/":"&#47;","=":"&#61;","`":"&#96;","\u0085":"&#133;","\u00a0":"&#160;","\u2028":"&#8232;","\u2029":"&#8233;"},lb=function(a){return kb[a]},mb=/[\x00\x22\x26\x27\x3c\x3e]/g;ib[3]=function(a){return String(a).replace(mb,lb)};var qb=/[\x00\x08-\x0d\x22\x26\x27\/\x3c-\x3e\\\x85\u2028\u2029]/g,rb={"\x00":"\\x00","\b":"\\x08","\t":"\\t","\n":"\\n","\x0B":"\\x0b",
"\f":"\\f","\r":"\\r",'"':"\\x22","&":"\\x26","'":"\\x27","/":"\\/","<":"\\x3c","=":"\\x3d",">":"\\x3e","\\":"\\\\","\u0085":"\\x85","\u2028":"\\u2028","\u2029":"\\u2029",$:"\\x24","(":"\\x28",")":"\\x29","*":"\\x2a","+":"\\x2b",",":"\\x2c","-":"\\x2d",".":"\\x2e",":":"\\x3a","?":"\\x3f","[":"\\x5b","]":"\\x5d","^":"\\x5e","{":"\\x7b","|":"\\x7c","}":"\\x7d"},tb=function(a){return rb[a]};ib[7]=function(a){return String(a).replace(qb,tb)};
ib[8]=function(a){if(null==a)return" null ";switch(typeof a){case "boolean":case "number":return" "+a+" ";default:return"'"+String(String(a)).replace(qb,tb)+"'"}};var Eb=/[\x00- \x22\x27-\x29\x3c\x3e\\\x7b\x7d\x7f\x85\xa0\u2028\u2029\uff01\uff03\uff04\uff06-\uff0c\uff0f\uff1a\uff1b\uff1d\uff1f\uff20\uff3b\uff3d]/g,Fb={"\x00":"%00","\u0001":"%01","\u0002":"%02","\u0003":"%03","\u0004":"%04","\u0005":"%05","\u0006":"%06","\u0007":"%07","\b":"%08","\t":"%09","\n":"%0A","\x0B":"%0B","\f":"%0C","\r":"%0D","\u000e":"%0E","\u000f":"%0F","\u0010":"%10",
"\u0011":"%11","\u0012":"%12","\u0013":"%13","\u0014":"%14","\u0015":"%15","\u0016":"%16","\u0017":"%17","\u0018":"%18","\u0019":"%19","\u001a":"%1A","\u001b":"%1B","\u001c":"%1C","\u001d":"%1D","\u001e":"%1E","\u001f":"%1F"," ":"%20",'"':"%22","'":"%27","(":"%28",")":"%29","<":"%3C",">":"%3E","\\":"%5C","{":"%7B","}":"%7D","\u007f":"%7F","\u0085":"%C2%85","\u00a0":"%C2%A0","\u2028":"%E2%80%A8","\u2029":"%E2%80%A9","\uff01":"%EF%BC%81","\uff03":"%EF%BC%83","\uff04":"%EF%BC%84","\uff06":"%EF%BC%86",
"\uff07":"%EF%BC%87","\uff08":"%EF%BC%88","\uff09":"%EF%BC%89","\uff0a":"%EF%BC%8A","\uff0b":"%EF%BC%8B","\uff0c":"%EF%BC%8C","\uff0f":"%EF%BC%8F","\uff1a":"%EF%BC%9A","\uff1b":"%EF%BC%9B","\uff1d":"%EF%BC%9D","\uff1f":"%EF%BC%9F","\uff20":"%EF%BC%A0","\uff3b":"%EF%BC%BB","\uff3d":"%EF%BC%BD"},Gb=function(a){return Fb[a]};ib[16]=function(a){return a};var Ib;
var Jb=[],Kb=[],Lb=[],Mb=[],Nb=[],Ob={},Pb,Qb,Rb,Tb=function(a,b){var c=a["function"];if(!c)throw Error("Error: No function name given for function call.");var d=Ob[c],e={},f;for(f in a)a.hasOwnProperty(f)&&0===f.indexOf("vtp_")&&(d&&b&&b.$e&&b.$e(a[f]),e[void 0!==d?f:f.substr(4)]=a[f]);return void 0!==d?d(e):Ib(c,e,b)},Vb=function(a,b,c){c=c||[];var d={},e;for(e in a)a.hasOwnProperty(e)&&(d[e]=Ub(a[e],b,c));return d},Ub=function(a,b,c){if(Aa(a)){var d;switch(a[0]){case "function_id":return a[1];
case "list":d=[];for(var e=1;e<a.length;e++)d.push(Ub(a[e],b,c));return d;case "macro":var f=a[1];if(c[f])return;var h=Jb[f];if(!h||b.yd(h))return;c[f]=!0;try{var k=Vb(h,b,c);k.vtp_gtmEventId=b.id;d=Tb(k,b);Rb&&(d=Rb.ah(d,k))}catch(y){b.qf&&b.qf(y,Number(f)),d=!1}c[f]=!1;return d;case "map":d={};for(var l=1;l<a.length;l+=2)d[Ub(a[l],b,c)]=Ub(a[l+1],b,c);return d;case "template":d=[];for(var p=!1,r=1;r<a.length;r++){var n=Ub(a[r],b,c);Qb&&(p=p||n===Qb.bc);d.push(n)}return Qb&&p?Qb.eh(d):d.join("");
case "escape":d=Ub(a[1],b,c);if(Qb&&Aa(a[1])&&"macro"===a[1][0]&&Qb.Ah(a))return Qb.Rh(d);d=String(d);for(var t=2;t<a.length;t++)ib[a[t]]&&(d=ib[a[t]](d));return d;case "tag":var q=a[1];if(!Mb[q])throw Error("Unable to resolve tag reference "+q+".");return d={ef:a[2],index:q};case "zb":var u={arg0:a[2],arg1:a[3],ignore_case:a[5]};u["function"]=a[1];var v=Wb(u,b,c),x=!!a[4];return x||2!==v?x!==(1===v):null;default:throw Error("Attempting to expand unknown Value type: "+a[0]+".");}}return a},Wb=function(a,
b,c){try{return Pb(Vb(a,b,c))}catch(d){JSON.stringify(a)}return 2};var Xb=function(){var a=function(b){return{toString:function(){return b}}};return{Hf:a("consent"),Xd:a("convert_case_to"),Yd:a("convert_false_to"),Zd:a("convert_null_to"),$d:a("convert_true_to"),ae:a("convert_undefined_to"),mi:a("debug_mode_metadata"),Ma:a("function"),vg:a("instance_name"),wg:a("live_only"),xg:a("malware_disabled"),yg:a("metadata"),ri:a("original_activity_id"),si:a("original_vendor_template_id"),Ag:a("once_per_event"),Qe:a("once_per_load"),Ue:a("setup_tags"),Ve:a("tag_id"),We:a("teardown_tags")}}();var Yb=null,ac=function(a){function b(n){for(var t=0;t<n.length;t++)d[n[t]]=!0}var c=[],d=[];Yb=Zb(a);for(var e=0;e<Kb.length;e++){var f=Kb[e],h=$b(f);if(h){for(var k=f.add||[],l=0;l<k.length;l++)c[k[l]]=!0;b(f.block||[])}else null===h&&b(f.block||[])}for(var p=[],r=0;r<Mb.length;r++)c[r]&&!d[r]&&(p[r]=!0);return p},$b=function(a){for(var b=a["if"]||[],c=0;c<b.length;c++){var d=Yb(b[c]);if(0===d)return!1;if(2===d)return null}for(var e=a.unless||[],f=0;f<e.length;f++){var h=Yb(e[f]);if(2===h)return null;
if(1===h)return!1}return!0},Zb=function(a){var b=[];return function(c){void 0===b[c]&&(b[c]=Wb(Lb[c],a));return b[c]}};var bc={ah:function(a,b){b[Xb.Xd]&&"string"===typeof a&&(a=1==b[Xb.Xd]?a.toLowerCase():a.toUpperCase());b.hasOwnProperty(Xb.Zd)&&null===a&&(a=b[Xb.Zd]);b.hasOwnProperty(Xb.ae)&&void 0===a&&(a=b[Xb.ae]);b.hasOwnProperty(Xb.$d)&&!0===a&&(a=b[Xb.$d]);b.hasOwnProperty(Xb.Yd)&&!1===a&&(a=b[Xb.Yd]);return a}};/*
 Copyright (c) 2014 Derek Brans, MIT license https://github.com/krux/postscribe/blob/master/LICENSE. Portions derived from simplehtmlparser, which is licensed under the Apache License, Version 2.0 */

var yc,zc=function(){};(function(){function a(k,l){k=k||"";l=l||{};for(var p in b)b.hasOwnProperty(p)&&(l.Pg&&(l["fix_"+p]=!0),l.hf=l.hf||l["fix_"+p]);var r={comment:/^\x3c!--/,endTag:/^<\//,atomicTag:/^<\s*(script|style|noscript|iframe|textarea)[\s\/>]/i,startTag:/^</,chars:/^[^<]/},n={comment:function(){var q=k.indexOf("--\x3e");if(0<=q)return{content:k.substr(4,q),length:q+3}},endTag:function(){var q=k.match(d);if(q)return{tagName:q[1],length:q[0].length}},atomicTag:function(){var q=n.startTag();
if(q){var u=k.slice(q.length);if(u.match(new RegExp("</\\s*"+q.tagName+"\\s*>","i"))){var v=u.match(new RegExp("([\\s\\S]*?)</\\s*"+q.tagName+"\\s*>","i"));if(v)return{tagName:q.tagName,Y:q.Y,content:v[1],length:v[0].length+q.length}}}},startTag:function(){var q=k.match(c);if(q){var u={};q[2].replace(e,function(v,x,y,w,z){var A=y||w||z||f.test(x)&&x||null,B=document.createElement("div");B.innerHTML=A;u[x]=B.textContent||B.innerText||A});return{tagName:q[1],Y:u,Lc:!!q[3],length:q[0].length}}},chars:function(){var q=
k.indexOf("<");return{length:0<=q?q:k.length}}},t=function(){for(var q in r)if(r[q].test(k)){var u=n[q]();return u?(u.type=u.type||q,u.text=k.substr(0,u.length),k=k.slice(u.length),u):null}};l.hf&&function(){var q=/^(AREA|BASE|BASEFONT|BR|COL|FRAME|HR|IMG|INPUT|ISINDEX|LINK|META|PARAM|EMBED)$/i,u=/^(COLGROUP|DD|DT|LI|OPTIONS|P|TD|TFOOT|TH|THEAD|TR)$/i,v=[];v.pf=function(){return this[this.length-1]};v.Ad=function(B){var D=this.pf();return D&&D.tagName&&D.tagName.toUpperCase()===B.toUpperCase()};v.$g=
function(B){for(var D=0,F;F=this[D];D++)if(F.tagName===B)return!0;return!1};var x=function(B){B&&"startTag"===B.type&&(B.Lc=q.test(B.tagName)||B.Lc);return B},y=t,w=function(){k="</"+v.pop().tagName+">"+k},z={startTag:function(B){var D=B.tagName;"TR"===D.toUpperCase()&&v.Ad("TABLE")?(k="<TBODY>"+k,A()):l.Ci&&u.test(D)&&v.$g(D)?v.Ad(D)?w():(k="</"+B.tagName+">"+k,A()):B.Lc||v.push(B)},endTag:function(B){v.pf()?l.mh&&!v.Ad(B.tagName)?w():v.pop():l.mh&&(y(),A())}},A=function(){var B=k,D=x(y());k=B;if(D&&
z[D.type])z[D.type](D)};t=function(){A();return x(y())}}();return{append:function(q){k+=q},Wh:t,Hi:function(q){for(var u;(u=t())&&(!q[u.type]||!1!==q[u.type](u)););},clear:function(){var q=k;k="";return q},Ii:function(){return k},stack:[]}}var b=function(){var k={},l=this.document.createElement("div");l.innerHTML="<P><I></P></I>";k.Ni="<P><I></P></I>"!==l.innerHTML;l.innerHTML="<P><i><P></P></i></P>";k.Li=2===l.childNodes.length;return k}(),c=/^<([\-A-Za-z0-9_]+)((?:\s+[\w\-]+(?:\s*=?\s*(?:(?:"[^"]*")|(?:'[^']*')|[^>\s]+))?)*)\s*(\/?)>/,
d=/^<\/([\-A-Za-z0-9_]+)[^>]*>/,e=/([\-A-Za-z0-9_]+)(?:\s*=\s*(?:(?:"((?:\\.|[^"])*)")|(?:'((?:\\.|[^'])*)')|([^>\s]+)))?/g,f=/^(checked|compact|declare|defer|disabled|ismap|multiple|nohref|noresize|noshade|nowrap|readonly|selected)$/i;a.supports=b;for(var h in b);yc=a})();(function(){function a(){}function b(n){return void 0!==n&&null!==n}function c(n,t,q){var u,v=n&&n.length||0;for(u=0;u<v;u++)t.call(q,n[u],u)}function d(n,t,q){for(var u in n)n.hasOwnProperty(u)&&t.call(q,u,n[u])}function e(n,t){d(t,
function(q,u){n[q]=u});return n}function f(n,t){n=n||{};d(t,function(q,u){b(n[q])||(n[q]=u)});return n}function h(n){try{return p.call(n)}catch(q){var t=[];c(n,function(u){t.push(u)});return t}}var k={Hg:a,Ig:a,Jg:a,Kg:a,Qg:a,Rg:function(n){return n},done:a,error:function(n){throw n;},Zh:!1},l=this;if(!l.postscribe){var p=Array.prototype.slice,r=function(){function n(q,u,v){var x="data-ps-"+u;if(2===arguments.length){var y=q.getAttribute(x);return b(y)?String(y):y}b(v)&&""!==v?q.setAttribute(x,v):
q.removeAttribute(x)}function t(q,u){var v=q.ownerDocument;e(this,{root:q,options:u,Qb:v.defaultView||v.parentWindow,fb:v,Bc:yc("",{Pg:!0}),nd:[q],Kd:"",Ld:v.createElement(q.nodeName),Nb:[],Qa:[]});n(this.Ld,"proxyof",0)}t.prototype.write=function(){[].push.apply(this.Qa,arguments);for(var q;!this.qc&&this.Qa.length;)q=this.Qa.shift(),"function"===typeof q?this.Wg(q):this.Ud(q)};t.prototype.Wg=function(q){var u={type:"function",value:q.name||q.toString()};this.Fd(u);q.call(this.Qb,this.fb);this.rf(u)};
t.prototype.Ud=function(q){this.Bc.append(q);for(var u,v=[],x,y;(u=this.Bc.Wh())&&!(x=u&&"tagName"in u?!!~u.tagName.toLowerCase().indexOf("script"):!1)&&!(y=u&&"tagName"in u?!!~u.tagName.toLowerCase().indexOf("style"):!1);)v.push(u);this.ki(v);x&&this.th(u);y&&this.uh(u)};t.prototype.ki=function(q){var u=this.Tg(q);u.Ye&&(u.wd=this.Kd+u.Ye,this.Kd+=u.Uh,this.Ld.innerHTML=u.wd,this.ii())};t.prototype.Tg=function(q){var u=this.nd.length,v=[],x=[],y=[];c(q,function(w){v.push(w.text);if(w.Y){if(!/^noscript$/i.test(w.tagName)){var z=
u++;x.push(w.text.replace(/(\/?>)/," data-ps-id="+z+" $1"));"ps-script"!==w.Y.id&&"ps-style"!==w.Y.id&&y.push("atomicTag"===w.type?"":"<"+w.tagName+" data-ps-proxyof="+z+(w.Lc?" />":">"))}}else x.push(w.text),y.push("endTag"===w.type?w.text:"")});return{Oi:q,raw:v.join(""),Ye:x.join(""),Uh:y.join("")}};t.prototype.ii=function(){for(var q,u=[this.Ld];b(q=u.shift());){var v=1===q.nodeType;if(!v||!n(q,"proxyof")){v&&(this.nd[n(q,"id")]=q,n(q,"id",null));var x=q.parentNode&&n(q.parentNode,"proxyof");
x&&this.nd[x].appendChild(q)}u.unshift.apply(u,h(q.childNodes))}};t.prototype.th=function(q){var u=this.Bc.clear();u&&this.Qa.unshift(u);q.src=q.Y.src||q.Y.vi;q.src&&this.Nb.length?this.qc=q:this.Fd(q);var v=this;this.ji(q,function(){v.rf(q)})};t.prototype.uh=function(q){var u=this.Bc.clear();u&&this.Qa.unshift(u);q.type=q.Y.type||q.Y.TYPE||"text/css";this.li(q);u&&this.write()};t.prototype.li=function(q){var u=this.Vg(q);this.xh(u);q.content&&(u.styleSheet&&!u.sheet?u.styleSheet.cssText=q.content:
u.appendChild(this.fb.createTextNode(q.content)))};t.prototype.Vg=function(q){var u=this.fb.createElement(q.tagName);u.setAttribute("type",q.type);d(q.Y,function(v,x){u.setAttribute(v,x)});return u};t.prototype.xh=function(q){this.Ud('<span id="ps-style"/>');var u=this.fb.getElementById("ps-style");u.parentNode.replaceChild(q,u)};t.prototype.Fd=function(q){q.Nh=this.Qa;this.Qa=[];this.Nb.unshift(q)};t.prototype.rf=function(q){q!==this.Nb[0]?this.options.error({message:"Bad script nesting or script finished twice"}):
(this.Nb.shift(),this.write.apply(this,q.Nh),!this.Nb.length&&this.qc&&(this.Fd(this.qc),this.qc=null))};t.prototype.ji=function(q,u){var v=this.Ug(q),x=this.di(v),y=this.options.Hg;q.src&&(v.src=q.src,this.bi(v,x?y:function(){u();y()}));try{this.wh(v),q.src&&!x||u()}catch(w){this.options.error(w),u()}};t.prototype.Ug=function(q){var u=this.fb.createElement(q.tagName);d(q.Y,function(v,x){u.setAttribute(v,x)});q.content&&(u.text=q.content);return u};t.prototype.wh=function(q){this.Ud('<span id="ps-script"/>');
var u=this.fb.getElementById("ps-script");u.parentNode.replaceChild(q,u)};t.prototype.bi=function(q,u){function v(){q=q.onload=q.onreadystatechange=q.onerror=null}var x=this.options.error;e(q,{onload:function(){v();u()},onreadystatechange:function(){/^(loaded|complete)$/.test(q.readyState)&&(v(),u())},onerror:function(){var y={message:"remote script failed "+q.src};v();x(y);u()}})};t.prototype.di=function(q){return!/^script$/i.test(q.nodeName)||!!(this.options.Zh&&q.src&&q.hasAttribute("async"))};
return t}();l.postscribe=function(){function n(){var x=u.shift(),y;x&&(y=x[x.length-1],y.Ig(),x.stream=t.apply(null,x),y.Jg())}function t(x,y,w){function z(F){F=w.Rg(F);v.write(F);w.Kg(F)}v=new r(x,w);v.id=q++;v.name=w.name||v.id;var A=x.ownerDocument,B={close:A.close,open:A.open,write:A.write,writeln:A.writeln};e(A,{close:a,open:a,write:function(){return z(h(arguments).join(""))},writeln:function(){return z(h(arguments).join("")+"\n")}});var D=v.Qb.onerror||a;v.Qb.onerror=function(F,K,P){w.error({msg:F+
" - "+K+":"+P});D.apply(v.Qb,arguments)};v.write(y,function(){e(A,B);v.Qb.onerror=D;w.done();v=null;n()});return v}var q=0,u=[],v=null;return e(function(x,y,w){"function"===typeof w&&(w={done:w});w=f(w,k);x=/^#/.test(x)?l.document.getElementById(x.substr(1)):x.Ei?x[0]:x;var z=[x,y,w];x.Qh={cancel:function(){z.stream?z.stream.abort():z[1]=a}};w.Qg(z);u.push(z);v||n();return x.Qh},{streams:{},Gi:u,xi:r})}();zc=l.postscribe}})();var E={xb:"_ee",ld:"_syn",wi:"_uei",ed:"_eu",ui:"_pci",Tc:"event_callback",Xb:"event_timeout",ca:"gtag.config",Ia:"gtag.get",ka:"purchase",Wa:"refund",Ha:"begin_checkout",Ua:"add_to_cart",Va:"remove_from_cart",Rf:"view_cart",ee:"add_to_wishlist",xa:"view_item",de:"view_promotion",ce:"select_promotion",Oc:"select_item",Ub:"view_item_list",be:"add_payment_info",Qf:"add_shipping_info",Aa:"value_key",za:"value_callback",da:"allow_ad_personalization_signals",ad:"restricted_data_processing",nb:"allow_google_signals",
fa:"cookie_expires",qb:"cookie_update",ub:"session_duration",ma:"user_properties",La:"transport_url",M:"ads_data_redaction",B:"ad_storage",I:"analytics_storage",If:"region",Jf:"wait_for_update"};E.He=[E.ka,E.Wa,E.Ha,E.Ua,E.Va,E.Rf,E.ee,E.xa,E.de,E.ce,E.Ub,E.Oc,E.be,E.Qf];E.Ge=[E.da,E.nb,E.qb];E.Ie=[E.fa,E.Xb,E.ub];var Ac={},Bc=function(a,b){Ac[a]=Ac[a]||[];Ac[a][b]=!0},Cc=function(a){for(var b=[],c=Ac[a]||[],d=0;d<c.length;d++)c[d]&&(b[Math.floor(d/6)]^=1<<d%6);for(var e=0;e<b.length;e++)b[e]="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_".charAt(b[e]||0);return b.join("")};var Dc=function(a){Bc("GTM",a)};var Fc=function(a,b){var c=function(){};c.prototype=a.prototype;var d=new c;a.apply(d,Array.prototype.slice.call(arguments,1));return d},Gc=function(a){var b=a;return function(){if(b){var c=b;b=null;c()}}};var Hc,Ic=function(){if(void 0===Hc){var a=null,b=qa.trustedTypes;if(b&&b.createPolicy){try{a=b.createPolicy("goog#html",{createHTML:va,createScript:va,createScriptURL:va})}catch(c){qa.console&&qa.console.error(c.message)}Hc=a}else Hc=a}return Hc};var Oc=function(a,b){this.m=b===Nc?a:""};Oc.prototype.toString=function(){return this.m+""};var Nc={};var Pc=/^(?:(?:https?|mailto|ftp):|[^:/?#]*(?:[/?#]|$))/i;var Qc;a:{var Rc=qa.navigator;if(Rc){var Sc=Rc.userAgent;if(Sc){Qc=Sc;break a}}Qc=""}var Tc=function(a){return-1!=Qc.indexOf(a)};var Vc=function(a,b,c){this.m=c===Uc?a:""};Vc.prototype.toString=function(){return this.m.toString()};var Wc=function(a){return a instanceof Vc&&a.constructor===Vc?a.m:"type_error:SafeHtml"},Uc={},Xc=new Vc(qa.trustedTypes&&qa.trustedTypes.emptyHTML||"",0,Uc);var Yc=function(a){var b=!1,c;return function(){b||(c=a(),b=!0);return c}}(function(){var a=document.createElement("div"),b=document.createElement("div");b.appendChild(document.createElement("div"));a.appendChild(b);var c=a.firstChild.firstChild;a.innerHTML=Wc(Xc);return!c.parentElement}),Zc=function(a,b){if(Yc())for(;a.lastChild;)a.removeChild(a.lastChild);a.innerHTML=Wc(b)};var $c=function(a){var b=Ic(),c=b?b.createHTML(a):a;return new Vc(c,null,Uc)};var G=window,H=document,ad=navigator,bd=H.currentScript&&H.currentScript.src,cd=function(a,b){var c=G[a];G[a]=void 0===c?b:c;return G[a]},dd=function(a,b){b&&(a.addEventListener?a.onload=b:a.onreadystatechange=function(){a.readyState in{loaded:1,complete:1}&&(a.onreadystatechange=null,b())})},jd=function(a,b,c){var d=H.createElement("script");d.type="text/javascript";d.async=!0;var e,f=Ic(),h=f?f.createScriptURL(a):a;e=new Oc(h,Nc);d.src=e instanceof Oc&&e.constructor===Oc?e.m:"type_error:TrustedResourceUrl";
var k=ta(d.ownerDocument&&d.ownerDocument.defaultView);k&&d.setAttribute("nonce",k);dd(d,b);c&&(d.onerror=c);var l=ta();l&&d.setAttribute("nonce",l);var p=H.getElementsByTagName("script")[0]||H.body||H.head;p.parentNode.insertBefore(d,p);return d},kd=function(){if(bd){var a=bd.toLowerCase();if(0===a.indexOf("https://"))return 2;if(0===a.indexOf("http://"))return 3}return 1},ld=function(a,b){var c=H.createElement("iframe");c.height="0";c.width="0";c.style.display="none";c.style.visibility="hidden";
var d=H.body&&H.body.lastChild||H.body||H.head;d.parentNode.insertBefore(c,d);dd(c,b);void 0!==a&&(c.src=a);return c},md=function(a,b,c){var d=new Image(1,1);d.onload=function(){d.onload=null;b&&b()};d.onerror=function(){d.onerror=null;c&&c()};d.src=a;return d},nd=function(a,b,c,d){a.addEventListener?a.addEventListener(b,c,!!d):a.attachEvent&&a.attachEvent("on"+b,c)},od=function(a,b,c){a.removeEventListener?a.removeEventListener(b,c,!1):a.detachEvent&&a.detachEvent("on"+b,c)},I=function(a){G.setTimeout(a,
0)},pd=function(a,b){return a&&b&&a.attributes&&a.attributes[b]?a.attributes[b].value:null},qd=function(a){var b=a.innerText||a.textContent||"";b&&" "!=b&&(b=b.replace(/^[\s\xa0]+|[\s\xa0]+$/g,""));b&&(b=b.replace(/(\xa0+|\s{2,}|\n|\r\t)/g," "));return b},rd=function(a){var b=H.createElement("div"),c=$c("A<div>"+a+"</div>");Zc(b,c);b=b.lastChild;for(var d=[];b.firstChild;)d.push(b.removeChild(b.firstChild));return d},sd=function(a,b,c){c=c||100;for(var d={},e=0;e<b.length;e++)d[b[e]]=!0;for(var f=
a,h=0;f&&h<=c;h++){if(d[String(f.tagName).toLowerCase()])return f;f=f.parentElement}return null},td=function(a){ad.sendBeacon&&ad.sendBeacon(a)||md(a)},ud=function(a,b){var c=a[b];c&&"string"===typeof c.animVal&&(c=c.animVal);return c};var vd={},wd=function(){return void 0==vd.gtag_cs_api?!1:vd.gtag_cs_api};var xd=[];function yd(){var a=cd("google_tag_data",{});a.ics||(a.ics={entries:{},set:zd,update:Ad,addListener:Bd,notifyListeners:Cd,active:!1,usedDefault:!1});return a.ics}
function zd(a,b,c,d,e,f){var h=yd();h.active=!0;h.usedDefault=!0;if(void 0!=b){var k=h.entries,l=k[a]||{},p=l.region,r=c&&g(c)?c.toUpperCase():void 0;d=d.toUpperCase();e=e.toUpperCase();if(r===e||(r===d?p!==e:!r&&!p)){var n=!!(f&&0<f&&void 0===l.update),t={region:r,initial:"granted"===b,update:l.update,quiet:n};k[a]=t;n&&G.setTimeout(function(){k[a]===t&&t.quiet&&(t.quiet=!1,Dd(a),Cd(),Bc("TAGGING",2))},f)}}}
function Ad(a,b){var c=yd();c.active=!0;if(void 0!=b){var d=Ed(a),e=c.entries,f=e[a]=e[a]||{};f.update="granted"===b;var h=Ed(a);f.quiet?(f.quiet=!1,Dd(a)):h!==d&&Dd(a)}}function Bd(a,b){xd.push({bf:a,nh:b})}function Dd(a){for(var b=0;b<xd.length;++b){var c=xd[b];Aa(c.bf)&&-1!==c.bf.indexOf(a)&&(c.uf=!0)}}function Cd(a){for(var b=0;b<xd.length;++b){var c=xd[b];if(c.uf){c.uf=!1;try{c.nh({af:a})}catch(d){}}}}
var Ed=function(a){var b=yd().entries[a]||{};return void 0!==b.update?b.update:void 0!==b.initial?b.initial:void 0},Fd=function(a){return(yd().entries[a]||{}).initial},Gd=function(a){return!(yd().entries[a]||{}).quiet},Hd=function(){return wd()?yd().active:!1},Id=function(a,b){yd().addListener(a,b)},Jd=function(a,b){function c(){for(var e=0;e<b.length;e++)if(!Gd(b[e]))return!0;return!1}if(c()){var d=!1;Id(b,function(e){d||c()||(d=!0,a(e))})}else a({})},Kd=function(a,b){if(!1===Ed(b)){var c=!1;Id([b],
function(d){!c&&Ed(b)&&(a(d),c=!0)})}};function Ld(a){for(var b=[],c=0;c<Md.length;c++){var d=a(Md[c]);b[c]=!0===d?"1":!1===d?"0":"-"}return b.join("")}
var Md=[E.B,E.I],Nd=function(a){var b=a[E.If];b&&Dc(40);var c=a[E.Jf];c&&Dc(41);for(var d=Aa(b)?b:[b],e=0;e<d.length;++e)for(var f=0;f<Md.length;f++){var h=Md[f],k=a[Md[f]],l=d[e];yd().set(h,k,l,"","",c)}},Od=function(a,b){for(var c=0;c<Md.length;c++){var d=Md[c],e=a[Md[c]];yd().update(d,e)}yd().notifyListeners(b)},Pd=function(a){var b=Ed(a);return void 0!=b?b:!0},Qd=function(){return"G1"+Ld(Ed)},Rd=function(a,b){Jd(a,b)};var Td=function(a){return Sd?H.querySelectorAll(a):null},Ud=function(a,b){if(!Sd)return null;if(Element.prototype.closest)try{return a.closest(b)}catch(e){return null}var c=Element.prototype.matches||Element.prototype.webkitMatchesSelector||Element.prototype.mozMatchesSelector||Element.prototype.msMatchesSelector||Element.prototype.oMatchesSelector,d=a;if(!H.documentElement.contains(d))return null;do{try{if(c.call(d,b))return d}catch(e){break}d=d.parentElement||d.parentNode}while(null!==d&&1===d.nodeType);
return null},Vd=!1;if(H.querySelectorAll)try{var Wd=H.querySelectorAll(":root");Wd&&1==Wd.length&&Wd[0]==H.documentElement&&(Vd=!0)}catch(a){}var Sd=Vd;var Xd=function(a){if(H.hidden)return!0;var b=a.getBoundingClientRect();if(b.top==b.bottom||b.left==b.right||!G.getComputedStyle)return!0;var c=G.getComputedStyle(a,null);if("hidden"===c.visibility)return!0;for(var d=a,e=c;d;){if("none"===e.display)return!0;var f=e.opacity,h=e.filter;if(h){var k=h.indexOf("opacity(");0<=k&&(h=h.substring(k+8,h.indexOf(")",k)),"%"==h.charAt(h.length-1)&&(h=h.substring(0,h.length-1)),f=Math.min(h,f))}if(void 0!==f&&0>=f)return!0;(d=d.parentElement)&&(e=G.getComputedStyle(d,
null))}return!1};
var Yd=function(){var a=H.body,b=H.documentElement||a&&a.parentElement,c,d;if(H.compatMode&&"BackCompat"!==H.compatMode)c=b?b.clientHeight:0,d=b?b.clientWidth:0;else{var e=function(f,h){return f&&h?Math.min(f,h):Math.max(f,h)};Dc(7);c=e(b?b.clientHeight:0,a?a.clientHeight:0);d=e(b?b.clientWidth:0,a?a.clientWidth:0)}return{width:d,height:c}},Zd=function(a){var b=Yd(),c=b.height,d=b.width,e=a.getBoundingClientRect(),f=e.bottom-e.top,h=e.right-e.left;return f&&h?(1-Math.min((Math.max(0-e.left,0)+Math.max(e.right-
d,0))/h,1))*(1-Math.min((Math.max(0-e.top,0)+Math.max(e.bottom-c,0))/f,1)):0};var $d=[],ae=!(!G.IntersectionObserver||!G.IntersectionObserverEntry),be=function(a,b,c){for(var d=new G.IntersectionObserver(a,{threshold:c}),e=0;e<b.length;e++)d.observe(b[e]);for(var f=0;f<$d.length;f++)if(!$d[f])return $d[f]=d,f;return $d.push(d)-1},ce=function(a,b,c){function d(k,l){var p={top:0,bottom:0,right:0,left:0,width:0,height:0},r={boundingClientRect:k.getBoundingClientRect(),
intersectionRatio:l,intersectionRect:p,isIntersecting:0<l,rootBounds:p,target:k,time:Pa()};I(function(){return a(r)})}for(var e=[],f=[],h=0;h<b.length;h++)e.push(0),f.push(-1);c.sort(function(k,l){return k-l});return function(){for(var k=0;k<b.length;k++){var l=Zd(b[k]);if(l>e[k])for(;f[k]<c.length-1&&l>=c[f[k]+1];)d(b[k],l),f[k]++;else if(l<e[k])for(;0<=f[k]&&l<=c[f[k]];)d(b[k],l),f[k]--;e[k]=l}}},de=function(a,b,c){for(var d=0;d<c.length;d++)1<c[d]?c[d]=1:0>c[d]&&(c[d]=0);if(ae){var e=!1;I(function(){e||
ce(a,b,c)()});return be(function(f){e=!0;for(var h={jb:0};h.jb<f.length;h={jb:h.jb},h.jb++)I(function(k){return function(){return a(f[k.jb])}}(h))},b,c)}return G.setInterval(ce(a,b,c),1E3)},ee=function(a){ae?0<=a&&a<$d.length&&$d[a]&&($d[a].disconnect(),$d[a]=void 0):G.clearInterval(a)};var fe=/:[0-9]+$/,ge=function(a,b,c){for(var d=a.split("&"),e=0;e<d.length;e++){var f=d[e].split("=");if(decodeURIComponent(f[0]).replace(/\+/g," ")===b){var h=f.slice(1).join("=");return c?h:decodeURIComponent(h).replace(/\+/g," ")}}},je=function(a,b,c,d,e){b&&(b=String(b).toLowerCase());if("protocol"===b||"port"===b)a.protocol=he(a.protocol)||he(G.location.protocol);"port"===b?a.port=String(Number(a.hostname?a.port:G.location.port)||("http"==a.protocol?80:"https"==a.protocol?443:"")):"host"===b&&
(a.hostname=(a.hostname||G.location.hostname).replace(fe,"").toLowerCase());return ie(a,b,c,d,e)},ie=function(a,b,c,d,e){var f,h=he(a.protocol);b&&(b=String(b).toLowerCase());switch(b){case "url_no_fragment":f=ke(a);break;case "protocol":f=h;break;case "host":f=a.hostname.replace(fe,"").toLowerCase();if(c){var k=/^www\d*\./.exec(f);k&&k[0]&&(f=f.substr(k[0].length))}break;case "port":f=String(Number(a.port)||("http"==h?80:"https"==h?443:""));break;case "path":a.pathname||a.hostname||Bc("TAGGING",
1);f="/"==a.pathname.substr(0,1)?a.pathname:"/"+a.pathname;var l=f.split("/");0<=m(d||[],l[l.length-1])&&(l[l.length-1]="");f=l.join("/");break;case "query":f=a.search.replace("?","");e&&(f=ge(f,e,void 0));break;case "extension":var p=a.pathname.split(".");f=1<p.length?p[p.length-1]:"";f=f.split("/")[0];break;case "fragment":f=a.hash.replace("#","");break;default:f=a&&a.href}return f},he=function(a){return a?a.replace(":","").toLowerCase():""},ke=function(a){var b="";if(a&&a.href){var c=a.href.indexOf("#");
b=0>c?a.href:a.href.substr(0,c)}return b},le=function(a){var b=H.createElement("a");a&&(b.href=a);var c=b.pathname;"/"!==c[0]&&(a||Bc("TAGGING",1),c="/"+c);var d=b.hostname.replace(fe,"");return{href:b.href,protocol:b.protocol,host:b.host,hostname:d,pathname:c,search:b.search,hash:b.hash,port:b.port}},me=function(a){function b(p){var r=p.split("=")[0];return 0>d.indexOf(r)?p:r+"=0"}function c(p){return p.split("&").map(b).filter(function(r){return void 0!=r}).join("&")}var d="gclid dclid gclaw gcldc gclgp gclha gclgf _gl".split(" "),
e=le(a),f=a.split(/[?#]/)[0],h=e.search,k=e.hash;"?"===h[0]&&(h=h.substring(1));"#"===k[0]&&(k=k.substring(1));h=c(h);k=c(k);""!==h&&(h="?"+h);""!==k&&(k="#"+k);var l=""+f+h+k;"/"===l[l.length-1]&&(l=l.substring(0,l.length-1));return l};var ne=new RegExp(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i),oe=new RegExp(/support|noreply/i),pe=["SCRIPT","IMG","SVG","PATH","BR"],qe=["BR"];function re(a){var b;if(a===H.body)b="body";else{var c;if(a.id)c="#"+a.id;else{var d;if(a.parentElement){var e;a:{var f=a.parentElement;if(f){for(var h=0;h<f.childElementCount;h++)if(f.children[h]===a){e=h+1;break a}e=-1}else e=1}d=re(a.parentElement)+">:nth-child("+e+")"}else d="";c=d}b=c}return b}
var ue=function(){var a=!0;var b=a,c;var d=[],e=H.body;if(e){for(var f=e.querySelectorAll("*"),h=0;h<f.length&&1E4>h;h++){var k=f[h];if(!(0<=pe.indexOf(k.tagName.toUpperCase()))){for(var l=!1,p=0;p<k.childElementCount&&1E4>p;p++)if(!(0<=qe.indexOf(k.children[p].tagName.toUpperCase()))){l=!0;break}l||d.push(k)}}c={elements:d,status:1E4<f.length?"2":"1"}}else c=
{elements:d,status:"4"};for(var r=c,n=r.elements,t=[],q=0;q<n.length;q++){var u=n[q],v=u.textContent;u.value&&(v=u.value);if(v){var x=v.match(ne);if(x){var y=x[0],w;if(G.location){var z=ie(G.location,"host",!0);w=0<=y.toLowerCase().indexOf(z)}else w=!1;w||t.push({element:u,Mc:y})}}}var A;for(var B=[],D=10<t.length?"3":r.status,F=0;F<t.length&&
10>F;F++){var K=t[F].element,P=t[F].Mc,S=!1;B.push({Mc:P,querySelector:re(K),tagName:K.tagName,isVisible:!Xd(K),type:1,zc:!!S})}return{elements:B,status:D}};var Ie={},M=null,Je=Math.random();Ie.D="GTM-WR6LD2P";Ie.ic="1k0";Ie.oi="";Ie.Kf="ChAIgOregAYQ3NmOoJ7+rtBeEiQAC6TbqyyL2Lk0+excx663D2PKW13fRI09e810fjDxJfOX4OkaAv4r";var Ke={__cl:!0,__ecl:!0,__ehl:!0,__evl:!0,__fal:!0,__fil:!0,__fsl:!0,__hl:!0,__jel:!0,__lcl:!0,__sdl:!0,__tl:!0,__ytl:!0},Le={__paused:!0,__tg:!0},Me;for(Me in Ke)Ke.hasOwnProperty(Me)&&(Le[Me]=!0);var Ne="www.googletagmanager.com/gtm.js";
var Oe=Ne,Pe=Ma(""),Qe=null,Re=null,Se="//www.googletagmanager.com/a?id="+Ie.D+"&cv=132",Te={},Ue={},Ve=function(){var a=M.sequence||1;M.sequence=a+1;return a};var We={},Xe=new Ea,Ye={},Ze={},bf={name:"dataLayer",set:function(a,b){C(Za(a,b),Ye);$e()},get:function(a){return af(a,2)},reset:function(){Xe=new Ea;Ye={};$e()}},af=function(a,b){return 2!=b?Xe.get(a):cf(a)},cf=function(a){var b,c=a.split(".");b=b||[];for(var d=Ye,e=0;e<c.length;e++){if(null===d)return!1;if(void 0===d)break;d=d[c[e]];if(-1!==m(b,d))return}return d},df=function(a,b){Ze.hasOwnProperty(a)||(Xe.set(a,b),C(Za(a,b),Ye),$e())},$e=function(a){Ia(Ze,function(b,c){Xe.set(b,c);C(Za(b,void 0),
Ye);C(Za(b,c),Ye);a&&delete Ze[b]})},ef=function(a,b,c){We[a]=We[a]||{};var d=1!==c?cf(b):Xe.get(b);"array"===eb(d)||"object"===eb(d)?We[a][b]=C(d):We[a][b]=d},ff=function(a,b){if(We[a])return We[a][b]},gf=function(a,b){We[a]&&delete We[a][b]};var kf={},lf=function(a,b){if(G._gtmexpgrp&&G._gtmexpgrp.hasOwnProperty(a))return G._gtmexpgrp[a];void 0===kf[a]&&(kf[a]=Math.floor(Math.random()*b));return kf[a]};var nf=function(a){var b=1,c,d,e;if(a)for(b=0,d=a.length-1;0<=d;d--)e=a.charCodeAt(d),b=(b<<6&268435455)+e+(e<<14),c=b&266338304,b=0!=c?b^c>>21:b;return b};function of(a,b,c){for(var d=[],e=b.split(";"),f=0;f<e.length;f++){var h=e[f].split("="),k=h[0].replace(/^\s*|\s*$/g,"");if(k&&k==a){var l=h.slice(1).join("=").replace(/^\s*|\s*$/g,"");l&&c&&(l=decodeURIComponent(l));d.push(l)}}return d};var qf=function(a,b,c,d){return pf(d)?of(a,String(b||document.cookie),c):[]},tf=function(a,b,c,d,e){if(pf(e)){var f=rf(a,d,e);if(1===f.length)return f[0].id;if(0!==f.length){f=sf(f,function(h){return h.sc},b);if(1===f.length)return f[0].id;f=sf(f,function(h){return h.Lb},c);return f[0]?f[0].id:void 0}}};function uf(a,b,c,d){var e=document.cookie;document.cookie=a;var f=document.cookie;return e!=f||void 0!=c&&0<=qf(b,f,!1,d).indexOf(c)}
var yf=function(a,b,c){function d(q,u,v){if(null==v)return delete h[u],q;h[u]=v;return q+"; "+u+"="+v}function e(q,u){if(null==u)return delete h[u],q;h[u]=!0;return q+"; "+u}if(!pf(c.sa))return 2;var f;void 0==b?f=a+"=deleted; expires="+(new Date(0)).toUTCString():(c.encode&&(b=encodeURIComponent(b)),b=vf(b),f=a+"="+b);var h={};f=d(f,"path",c.path);var k;c.expires instanceof Date?k=c.expires.toUTCString():null!=c.expires&&(k=""+c.expires);f=d(f,"expires",k);f=d(f,"max-age",c.Fi);f=d(f,"samesite",
c.Ji);c.Ki&&(f=e(f,"secure"));var l=c.domain;if("auto"===l){for(var p=wf(),r=0;r<p.length;++r){var n="none"!==p[r]?p[r]:void 0,t=d(f,"domain",n);t=e(t,c.flags);if(!xf(n,c.path)&&uf(t,a,b,c.sa))return 0}return 1}l&&"none"!==l&&(f=d(f,"domain",l));f=e(f,c.flags);return xf(l,c.path)?1:uf(f,a,b,c.sa)?0:1},zf=function(a,b,c){null==c.path&&(c.path="/");c.domain||(c.domain="auto");return yf(a,b,c)};
function sf(a,b,c){for(var d=[],e=[],f,h=0;h<a.length;h++){var k=a[h],l=b(k);l===c?d.push(k):void 0===f||l<f?(e=[k],f=l):l===f&&e.push(k)}return 0<d.length?d:e}function rf(a,b,c){for(var d=[],e=qf(a,void 0,void 0,c),f=0;f<e.length;f++){var h=e[f].split("."),k=h.shift();if(!b||-1!==b.indexOf(k)){var l=h.shift();l&&(l=l.split("-"),d.push({id:h.join("."),sc:1*l[0]||1,Lb:1*l[1]||1}))}}return d}
var vf=function(a){a&&1200<a.length&&(a=a.substring(0,1200));return a},Af=/^(www\.)?google(\.com?)?(\.[a-z]{2})?$/,Bf=/(^|\.)doubleclick\.net$/i,xf=function(a,b){return Bf.test(document.location.hostname)||"/"===b&&Af.test(a)},wf=function(){var a=[],b=document.location.hostname.split(".");if(4===b.length){var c=b[b.length-1];if(parseInt(c,10).toString()===c)return["none"]}for(var d=b.length-2;0<=d;d--)a.push(b.slice(d).join("."));var e=document.location.hostname;Bf.test(e)||Af.test(e)||a.push("none");
return a},pf=function(a){if(!wd()||!a||!Hd())return!0;if(!Gd(a))return!1;var b=Ed(a);return null==b?!0:!!b};var Cf=function(){for(var a=ad.userAgent+(H.cookie||"")+(H.referrer||""),b=a.length,c=G.history.length;0<c;)a+=c--^b++;return[Math.round(2147483647*Math.random())^nf(a)&2147483647,Math.round(Pa()/1E3)].join(".")},Ff=function(a,b,c,d,e){var f=Df(b);return tf(a,f,Ef(c),d,e)},Gf=function(a,b,c,d){var e=""+Df(c),f=Ef(d);1<f&&(e+="-"+f);return[b,e,a].join(".")},Df=function(a){if(!a)return 1;a=0===a.indexOf(".")?a.substr(1):a;return a.split(".").length},Ef=function(a){if(!a||"/"===a)return 1;"/"!==a[0]&&
(a="/"+a);"/"!==a[a.length-1]&&(a+="/");return a.split("/").length-1};function Hf(a,b,c){var d,e=a.Kb;null==e&&(e=7776E3);0!==e&&(d=new Date((b||Pa())+1E3*e));return{path:a.path,domain:a.domain,flags:a.flags,encode:!!c,expires:d}};var If=["1"],Jf={},Mf=function(a){var b=Kf(a.prefix),c=Jf[b];c&&Lf(b,c,a)},Of=function(a){var b=Kf(a.prefix);if(!Jf[b]&&!Nf(b,a.path,a.domain)){var c=Cf();Lf(b,c,a);var d=cd("google_tag_data",{});d._gcl_au?Bc("GTM",57):d._gcl_au=c;Nf(b,a.path,a.domain)}};function Lf(a,b,c){var d=Gf(b,"1",c.domain,c.path),e=Hf(c);e.sa="ad_storage";zf(a,d,e)}function Nf(a,b,c){var d=Ff(a,b,c,If,"ad_storage");d&&(Jf[a]=d);return d}function Kf(a){return(a||"_gcl")+"_au"};function Pf(){for(var a=Qf,b={},c=0;c<a.length;++c)b[a[c]]=c;return b}function Rf(){var a="ABCDEFGHIJKLMNOPQRSTUVWXYZ";a+=a.toLowerCase()+"0123456789-_";return a+"."}var Qf,Sf;
function Tf(a){function b(l){for(;d<a.length;){var p=a.charAt(d++),r=Sf[p];if(null!=r)return r;if(!/^[\s\xa0]*$/.test(p))throw Error("Unknown base64 encoding at char: "+p);}return l}Qf=Qf||Rf();Sf=Sf||Pf();for(var c="",d=0;;){var e=b(-1),f=b(0),h=b(64),k=b(64);if(64===k&&-1===e)return c;c+=String.fromCharCode(e<<2|f>>4);64!=h&&(c+=String.fromCharCode(f<<4&240|h>>2),64!=k&&(c+=String.fromCharCode(h<<6&192|k)))}};var Uf;var Yf=function(){var a=Vf,b=Wf,c=Xf(),d=function(h){a(h.target||h.srcElement||{})},e=function(h){b(h.target||h.srcElement||{})};if(!c.init){nd(H,"mousedown",d);nd(H,"keyup",d);nd(H,"submit",e);var f=HTMLFormElement.prototype.submit;HTMLFormElement.prototype.submit=function(){b(this);f.call(this)};c.init=!0}},Zf=function(a,b,c,d,e){var f={callback:a,domains:b,fragment:2===c,placement:c,forms:d,sameHost:e};Xf().decorators.push(f)},$f=function(a,b,c){for(var d=Xf().decorators,e={},f=0;f<d.length;++f){var h=
d[f],k;if(k=!c||h.forms)a:{var l=h.domains,p=a,r=!!h.sameHost;if(l&&(r||p!==H.location.hostname))for(var n=0;n<l.length;n++)if(l[n]instanceof RegExp){if(l[n].test(p)){k=!0;break a}}else if(0<=p.indexOf(l[n])||r&&0<=l[n].indexOf(p)){k=!0;break a}k=!1}if(k){var t=h.placement;void 0==t&&(t=h.fragment?2:1);t===b&&Ta(e,h.callback())}}return e},Xf=function(){var a=cd("google_tag_data",{}),b=a.gl;b&&b.decorators||(b={decorators:[]},a.gl=b);return b};var ag=/(.*?)\*(.*?)\*(.*)/,bg=/^https?:\/\/([^\/]*?)\.?cdn\.ampproject\.org\/?(.*)/,cg=/^(?:www\.|m\.|amp\.)+/,dg=/([^?#]+)(\?[^#]*)?(#.*)?/;function eg(a){return new RegExp("(.*?)(^|&)"+a+"=([^&]*)&?(.*)")}
var gg=function(a){var b=[],c;for(c in a)if(a.hasOwnProperty(c)){var d=a[c];if(void 0!==d&&d===d&&null!==d&&"[object Object]"!==d.toString()){b.push(c);var e=b,f=e.push,h,k=String(d);Qf=Qf||Rf();Sf=Sf||Pf();for(var l=[],p=0;p<k.length;p+=3){var r=p+1<k.length,n=p+2<k.length,t=k.charCodeAt(p),q=r?k.charCodeAt(p+1):0,u=n?k.charCodeAt(p+2):0,v=t>>2,x=(t&3)<<4|q>>4,y=(q&15)<<2|u>>6,w=u&63;n||(w=64,r||(y=64));l.push(Qf[v],Qf[x],Qf[y],Qf[w])}h=l.join("");f.call(e,h)}}var z=b.join("*");return["1",fg(z),
z].join("*")},fg=function(a,b){var c=[window.navigator.userAgent,(new Date).getTimezoneOffset(),window.navigator.userLanguage||window.navigator.language,Math.floor((new Date).getTime()/60/1E3)-(void 0===b?0:b),a].join("*"),d;if(!(d=Uf)){for(var e=Array(256),f=0;256>f;f++){for(var h=f,k=0;8>k;k++)h=h&1?h>>>1^3988292384:h>>>1;e[f]=h}d=e}Uf=d;for(var l=4294967295,p=0;p<c.length;p++)l=l>>>8^Uf[(l^c.charCodeAt(p))&255];return((l^-1)>>>0).toString(36)},ig=function(){return function(a){var b=le(G.location.href),
c=b.search.replace("?",""),d=ge(c,"_gl",!0)||"";a.query=hg(d)||{};var e=je(b,"fragment").match(eg("_gl"));a.fragment=hg(e&&e[3]||"")||{}}},jg=function(a){var b=ig(),c=Xf();c.data||(c.data={query:{},fragment:{}},b(c.data));var d={},e=c.data;e&&(Ta(d,e.query),a&&Ta(d,e.fragment));return d},hg=function(a){var b;b=void 0===b?3:b;try{if(a){var c;a:{for(var d=a,e=0;3>e;++e){var f=ag.exec(d);if(f){c=f;break a}d=decodeURIComponent(d)}c=void 0}var h=c;if(h&&"1"===h[1]){var k=h[3],l;a:{for(var p=h[2],r=0;r<
b;++r)if(p===fg(k,r)){l=!0;break a}l=!1}if(l){for(var n={},t=k?k.split("*"):[],q=0;q<t.length;q+=2)n[t[q]]=Tf(t[q+1]);return n}}}}catch(u){}};function kg(a,b,c,d){function e(r){var n=r,t=eg(a).exec(n),q=n;if(t){var u=t[2],v=t[4];q=t[1];v&&(q=q+u+v)}r=q;var x=r.charAt(r.length-1);r&&"&"!==x&&(r+="&");return r+p}d=void 0===d?!1:d;var f=dg.exec(c);if(!f)return"";var h=f[1],k=f[2]||"",l=f[3]||"",p=a+"="+b;d?l="#"+e(l.substring(1)):k="?"+e(k.substring(1));return""+h+k+l}
function lg(a,b){var c="FORM"===(a.tagName||"").toUpperCase(),d=$f(b,1,c),e=$f(b,2,c),f=$f(b,3,c);if(Va(d)){var h=gg(d);c?mg("_gl",h,a):ng("_gl",h,a,!1)}if(!c&&Va(e)){var k=gg(e);ng("_gl",k,a,!0)}for(var l in f)if(f.hasOwnProperty(l))a:{var p=l,r=f[l],n=a;if(n.tagName){if("a"===n.tagName.toLowerCase()){ng(p,r,n,void 0);break a}if("form"===n.tagName.toLowerCase()){mg(p,r,n);break a}}"string"==typeof n&&kg(p,r,n,void 0)}}
function ng(a,b,c,d){if(c.href){var e=kg(a,b,c.href,void 0===d?!1:d);Pc.test(e)&&(c.href=e)}}
function mg(a,b,c){if(c&&c.action){var d=(c.method||"").toLowerCase();if("get"===d){for(var e=c.childNodes||[],f=!1,h=0;h<e.length;h++){var k=e[h];if(k.name===a){k.setAttribute("value",b);f=!0;break}}if(!f){var l=H.createElement("input");l.setAttribute("type","hidden");l.setAttribute("name",a);l.setAttribute("value",b);c.appendChild(l)}}else if("post"===d){var p=kg(a,b,c.action);Pc.test(p)&&(c.action=p)}}}
var Vf=function(a){try{var b;a:{for(var c=a,d=100;c&&0<d;){if(c.href&&c.nodeName.match(/^a(?:rea)?$/i)){b=c;break a}c=c.parentNode;d--}b=null}var e=b;if(e){var f=e.protocol;"http:"!==f&&"https:"!==f||lg(e,e.hostname)}}catch(h){}},Wf=function(a){try{if(a.action){var b=je(le(a.action),"host");lg(a,b)}}catch(c){}},og=function(a,b,c,d){Yf();Zf(a,b,"fragment"===c?2:1,!!d,!1)},pg=function(a,b){Yf();Zf(a,[ie(G.location,"host",!0)],b,!0,!0)},qg=function(){var a=H.location.hostname,b=bg.exec(H.referrer);if(!b)return!1;
var c=b[2],d=b[1],e="";if(c){var f=c.split("/"),h=f[1];e="s"===h?decodeURIComponent(f[2]):decodeURIComponent(h)}else if(d){if(0===d.indexOf("xn--"))return!1;e=d.replace(/-/g,".").replace(/\.\./g,"-")}var k=a.replace(cg,""),l=e.replace(cg,""),p;if(!(p=k===l)){var r="."+l;p=k.substring(k.length-r.length,k.length)===r}return p},rg=function(a,b){return!1===a?!1:a||b||qg()};var sg=/^\w+$/,tg=/^[\w-]+$/,ug=/^~?[\w-]+$/,vg={aw:"_aw",dc:"_dc",gf:"_gf",ha:"_ha",gp:"_gp"},wg=function(){if(!wd()||!Hd())return!0;var a=Ed("ad_storage");return null==a?!0:!!a},xg=function(a,b){Gd("ad_storage")?wg()?a():Kd(a,"ad_storage"):b?Bc("TAGGING",3):Jd(function(){xg(a,!0)},["ad_storage"])},Ag=function(a){var b=[];if(!H.cookie)return b;var c=qf(a,H.cookie,void 0,"ad_storage");if(!c||0==c.length)return b;for(var d=0;d<c.length;d++){var e=yg(c[d]);e&&-1===m(b,e)&&b.push(e)}return zg(b)};
function Bg(a){return a&&"string"==typeof a&&a.match(sg)?a:"_gcl"}
var Dg=function(){var a=le(G.location.href),b=je(a,"query",!1,void 0,"gclid"),c=je(a,"query",!1,void 0,"gclsrc"),d=je(a,"query",!1,void 0,"dclid");if(!b||!c){var e=a.hash.replace("#","");b=b||ge(e,"gclid",void 0);c=c||ge(e,"gclsrc",void 0)}return Cg(b,c,d)},Cg=function(a,b,c){var d={},e=function(f,h){d[h]||(d[h]=[]);d[h].push(f)};d.gclid=a;d.gclsrc=b;d.dclid=c;if(void 0!==a&&a.match(tg))switch(b){case void 0:e(a,"aw");break;case "aw.ds":e(a,"aw");e(a,"dc");break;case "ds":e(a,"dc");break;case "3p.ds":e(a,
"dc");break;case "gf":e(a,"gf");break;case "ha":e(a,"ha");break;case "gp":e(a,"gp")}c&&e(c,"dc");return d},Eg=function(a,b){switch(a){case void 0:case "aw":return"aw"===b;case "aw.ds":return"aw"===b||"dc"===b;case "ds":case "3p.ds":return"dc"===b;case "gf":return"gf"===b;case "ha":return"ha"===b;case "gp":return"gp"===b}return!1},Gg=function(a){var b=Dg();xg(function(){Fg(b,a)})};
function Fg(a,b,c){function d(l,p){var r=Hg(l,e);r&&zf(r,p,f)}b=b||{};var e=Bg(b.prefix);c=c||Pa();var f=Hf(b,c,!0);f.sa="ad_storage";var h=Math.round(c/1E3),k=function(l){return["GCL",h,l].join(".")};a.aw&&(!0===b.Pi?d("aw",k("~"+a.aw[0])):d("aw",k(a.aw[0])));a.dc&&d("dc",k(a.dc[0]));a.gf&&d("gf",k(a.gf[0]));a.ha&&d("ha",k(a.ha[0]));a.gp&&d("gp",k(a.gp[0]))}
var Jg=function(a,b){var c=jg(!0);xg(function(){for(var d=Bg(b.prefix),e=0;e<a.length;++e){var f=a[e];if(void 0!==vg[f]){var h=Hg(f,d),k=c[h];if(k){var l=Math.min(Ig(k),Pa()),p;b:{for(var r=l,n=qf(h,H.cookie,void 0,"ad_storage"),t=0;t<n.length;++t)if(Ig(n[t])>r){p=!0;break b}p=!1}if(!p){var q=Hf(b,l,!0);q.sa="ad_storage";zf(h,k,q)}}}}Fg(Cg(c.gclid,c.gclsrc),b)})},Hg=function(a,b){var c=vg[a];if(void 0!==c)return b+c},Ig=function(a){var b=a.split(".");return 3!==b.length||"GCL"!==b[0]?0:1E3*(Number(b[1])||
0)};function yg(a){var b=a.split(".");if(3==b.length&&"GCL"==b[0]&&b[1])return b[2]}
var Kg=function(a,b,c,d,e){if(Aa(b)){var f=Bg(e),h=function(){for(var k={},l=0;l<a.length;++l){var p=Hg(a[l],f);if(p){var r=qf(p,H.cookie,void 0,"ad_storage");r.length&&(k[p]=r.sort()[r.length-1])}}return k};xg(function(){og(h,b,c,d)})}},zg=function(a){return a.filter(function(b){return ug.test(b)})},Lg=function(a,b){for(var c=Bg(b.prefix),d={},e=0;e<a.length;e++)vg[a[e]]&&(d[a[e]]=vg[a[e]]);xg(function(){Ia(d,function(f,h){var k=qf(c+h,H.cookie,void 0,"ad_storage");if(k.length){var l=k[0],p=Ig(l),
r={};r[f]=[yg(l)];Fg(r,b,p)}})})};function Mg(a,b){for(var c=0;c<b.length;++c)if(a[b[c]])return!0;return!1}
var Ng=function(){function a(e,f,h){h&&(e[f]=h)}var b=["aw","dc"];if(Hd()){var c=Dg();if(Mg(c,b)){var d={};a(d,"gclid",c.gclid);a(d,"dclid",c.dclid);a(d,"gclsrc",c.gclsrc);pg(function(){return d},3);pg(function(){var e={};return e._up="1",e},1)}}},Og=function(){var a;if(wg()){for(var b=[],c=H.cookie.split(";"),d=/^\s*_gac_(UA-\d+-\d+)=\s*(.+?)\s*$/,e=0;e<c.length;e++){var f=c[e].match(d);f&&b.push({Rd:f[1],value:f[2]})}var h={};if(b&&b.length)for(var k=0;k<b.length;k++){var l=b[k].value.split(".");
"1"==l[0]&&3==l.length&&l[1]&&(h[b[k].Rd]||(h[b[k].Rd]=[]),h[b[k].Rd].push({timestamp:l[1],vc:l[2]}))}a=h}else a={};return a};var Pg=/^\d+\.fls\.doubleclick\.net$/,Qg=!1;function Rg(a,b){Gd(E.B)?Pd(E.B)?a():Kd(a,E.B):b?Dc(42):Rd(function(){Rg(a,!0)},[E.B])}function Sg(a){var b=le(G.location.href),c=je(b,"host",!1);if(c&&c.match(Pg)){var d=je(b,"path").split(a+"=");if(1<d.length)return d[1].split(";")[0].split("?")[0]}}
function Tg(a,b,c){if("aw"==a||"dc"==a){var d=Sg("gcl"+a);if(d)return d.split(".")}var e=Bg(b);if("_gcl"==e){c=void 0===c?!0:c;var f=!Pd(E.B)&&c,h;h=Dg()[a]||[];if(0<h.length)return f?["0"]:h}var k=Hg(a,e);return k?Ag(k):[]}
var Ug=function(a){var b=Sg("gac");if(b)return!Pd(E.B)&&a?"0":decodeURIComponent(b);var c=Og(),d=[];Ia(c,function(e,f){for(var h=[],k=0;k<f.length;k++)h.push(f[k].vc);h=zg(h);h.length&&d.push(e+":"+h.join(","))});return d.join(";")},Wg=function(a,b){if(Qg)Vg(a,b,"dc");else{var c=Dg().dc||[];Rg(function(){Of(b);var d=Jf[Kf(b.prefix)],e=!1;if(d&&0<c.length){var f=M.joined_au=M.joined_au||{},h=b.prefix||"_gcl";if(!f[h])for(var k=0;k<c.length;k++){var l="https://adservice.google.com/ddm/regclk";l=l+"?gclid="+c[k]+"&auiddc="+
d;td(l);e=f[h]=!0}}null==a&&(a=e);a&&d&&Mf(b)})}},Vg=function(a,b,c){var d=Dg(),e=[],f=d.gclid,h=d.dclid,k=d.gclsrc||"aw";!f||"aw.ds"!==k&&"aw"!==k&&"ds"!==k||c&&!Eg(k,c)||e.push({vc:f,lf:k});!h||c&&"dc"!==c||e.push({vc:h,lf:"ds"});Rg(function(){Of(b);var l=Jf[Kf(b.prefix)],p=!1;if(l&&0<e.length)for(var r=M.joined_auid=M.joined_auid||{},n=0;n<e.length;n++){var t=e[n],q=t.vc,u=t.lf,v=(b.prefix||"_gcl")+"."+u+"."+q;if(!r[v]){var x="https://adservice.google.com/pagead/regclk";x=x+"?gclid="+q+"&auid="+l+"&gclsrc="+u;td(x);
p=r[v]=!0}}null==a&&(a=p);a&&l&&Mf(b)})};var Xg=/[A-Z]+/,Yg=/\s/,Zg=function(a){if(g(a)&&(a=Oa(a),!Yg.test(a))){var b=a.indexOf("-");if(!(0>b)){var c=a.substring(0,b);if(Xg.test(c)){for(var d=a.substring(b+1).split("/"),e=0;e<d.length;e++)if(!d[e])return;return{id:a,prefix:c,containerId:c+"-"+d[0],F:d}}}}},ah=function(a){for(var b={},c=0;c<a.length;++c){var d=Zg(a[c]);d&&(b[d.id]=d)}$g(b);var e=[];Ia(b,function(f,h){e.push(h)});return e};
function $g(a){var b=[],c;for(c in a)if(a.hasOwnProperty(c)){var d=a[c];"AW"===d.prefix&&d.F[1]&&b.push(d.containerId)}for(var e=0;e<b.length;++e)delete a[b[e]]};var bh=function(){var a=!1;return a};var dh=function(a,b,c,d){return(2===ch()||d||"http:"!=G.location.protocol?a:b)+c},ch=function(){var a=kd(),b;if(1===a)a:{var c=Oe;c=c.toLowerCase();for(var d="https://"+c,e="http://"+c,f=1,h=H.getElementsByTagName("script"),k=0;k<h.length&&100>k;k++){var l=h[k].src;if(l){l=l.toLowerCase();if(0===l.indexOf(e)){b=3;break a}1===f&&0===l.indexOf(d)&&(f=2)}}b=f}else b=a;return b};
var rh=function(a){return Pd(E.B)?a:a.replace(/&url=([^&#]+)/,function(b,c){var d=me(decodeURIComponent(c));return"&url="+encodeURIComponent(d)})},sh=function(){var a;if(!(a=Pe)){var b;if(!0===G._gtmdgs)b=!0;else{var c=ad&&ad.userAgent||"";b=0>c.indexOf("Safari")||/Chrome|Coast|Opera|Edg|Silk|Android/.test(c)||11>((/Version\/([\d]+)/.exec(c)||[])[1]||"")?!1:!0}a=!b}if(a)return-1;var d=Ka("1");return lf(1,100)<d?lf(2,2):-1},th=function(a){var b;
if(!a||!a.length)return;for(var c=[],d=0;d<a.length;++d){var e=a[d];e&&e.estimated_delivery_date?c.push(""+e.estimated_delivery_date):c.push("")}b=c.join(",");return b};var uh=new RegExp(/^(.*\.)?(google|youtube|blogger|withgoogle)(\.com?)?(\.[a-z]{2})?\.?$/),vh={cl:["ecl"],customPixels:["nonGooglePixels"],ecl:["cl"],ehl:["hl"],hl:["ehl"],html:["customScripts","customPixels","nonGooglePixels","nonGoogleScripts","nonGoogleIframes"],customScripts:["html","customPixels","nonGooglePixels","nonGoogleScripts","nonGoogleIframes"],nonGooglePixels:[],nonGoogleScripts:["nonGooglePixels"],nonGoogleIframes:["nonGooglePixels"]},wh={cl:["ecl"],customPixels:["customScripts","html"],
ecl:["cl"],ehl:["hl"],hl:["ehl"],html:["customScripts"],customScripts:["html"],nonGooglePixels:["customPixels","customScripts","html","nonGoogleScripts","nonGoogleIframes"],nonGoogleScripts:["customScripts","html"],nonGoogleIframes:["customScripts","html","nonGoogleScripts"]},xh="google customPixels customScripts html nonGooglePixels nonGoogleScripts nonGoogleIframes".split(" ");
var zh=function(a){var b=af("gtm.allowlist")||af("gtm.whitelist");b&&Dc(9);var c=b&&Wa(Na(b),vh),d=af("gtm.blocklist")||af("gtm.blacklist");d||(d=af("tagTypeBlacklist"))&&
Dc(3);d?Dc(8):d=[];yh()&&(d=Na(d),d.push("nonGooglePixels","nonGoogleScripts","sandboxedScripts"));0<=m(Na(d),"google")&&Dc(2);var e=d&&Wa(Na(d),wh),f={};return function(h){var k=h&&h[Xb.Ma];if(!k||"string"!=typeof k)return!0;k=k.replace(/^_*/,"");if(void 0!==f[k])return f[k];var l=Ue[k]||[],p=a(k,l);if(b){var r;if(r=p)a:{if(0>m(c,k))if(l&&0<l.length)for(var n=0;n<
l.length;n++){if(0>m(c,l[n])){Dc(11);r=!1;break a}}else{r=!1;break a}r=!0}p=r}var t=!1;if(d){var q=0<=m(e,k);if(q)t=q;else{var u=Ga(e,l||[]);u&&Dc(10);t=u}}var v=!p||t;v||!(0<=m(l,"sandboxedScripts"))||c&&-1!==m(c,"sandboxedScripts")||(v=Ga(e,xh));return f[k]=v}},yh=function(){return uh.test(G.location&&G.location.hostname)};var Ah={active:!0,isAllowed:function(){return!0}},Bh=function(a){var b=M.zones;return b?b.checkState(Ie.D,a):Ah},Ch=function(a){var b=M.zones;!b&&a&&(b=M.zones=a());return b};var Hh=function(){},Ih=function(){};var Jh=!1,Kh=0,Lh=[];function Mh(a){if(!Jh){var b=H.createEventObject,c="complete"==H.readyState,d="interactive"==H.readyState;if(!a||"readystatechange"!=a.type||c||!b&&d){Jh=!0;for(var e=0;e<Lh.length;e++)I(Lh[e])}Lh.push=function(){for(var f=0;f<arguments.length;f++)I(arguments[f]);return 0}}}function Nh(){if(!Jh&&140>Kh){Kh++;try{H.documentElement.doScroll("left"),Mh()}catch(a){G.setTimeout(Nh,50)}}}var Oh=function(a){Jh?a():Lh.push(a)};var Ph={},Qh={},Rh=function(a,b,c,d){if(!Qh[a]||Le[b]||"__zone"===b)return-1;var e={};gb(d)&&(e=C(d,e));e.id=c;e.status="timeout";return Qh[a].tags.push(e)-1},Sh=function(a,b,c,d){if(Qh[a]){var e=Qh[a].tags[b];e&&(e.status=c,e.executionTime=d)}};function Th(a){for(var b=Ph[a]||[],c=0;c<b.length;c++)b[c]();Ph[a]={push:function(d){d(Ie.D,Qh[a])}}}
var Wh=function(a,b,c){Qh[a]={tags:[]};ya(b)&&Uh(a,b);c&&G.setTimeout(function(){return Th(a)},Number(c));return Vh(a)},Uh=function(a,b){Ph[a]=Ph[a]||[];Ph[a].push(Sa(function(){return I(function(){b(Ie.D,Qh[a])})}))};function Vh(a){var b=0,c=0,d=!1;return{add:function(){c++;return Sa(function(){b++;d&&b>=c&&Th(a)})},Og:function(){d=!0;b>=c&&Th(a)}}};var Xh=function(){function a(d){return!za(d)||0>d?0:d}if(!M._li&&G.performance&&G.performance.timing){var b=G.performance.timing.navigationStart,c=za(bf.get("gtm.start"))?bf.get("gtm.start"):0;M._li={cst:a(c-b),cbt:a(Re-b)}}};var ai={},bi=function(){return G.GoogleAnalyticsObject&&G[G.GoogleAnalyticsObject]},ci=!1;
var di=function(a){G.GoogleAnalyticsObject||(G.GoogleAnalyticsObject=a||"ga");var b=G.GoogleAnalyticsObject;if(G[b])G.hasOwnProperty(b)||Dc(12);else{var c=function(){c.q=c.q||[];c.q.push(arguments)};c.l=Number(new Date);G[b]=c}Xh();return G[b]},ei=function(a,b,c,d){b=String(b).replace(/\s+/g,"").split(",");var e=bi();e(a+"require","linker");e(a+"linker:autoLink",b,c,d)},fi=function(a){};
var hi=function(a){},gi=function(){return G.GoogleAnalyticsObject||"ga"},ii=function(a,b){return function(){var c=bi(),d=c&&c.getByName&&c.getByName(a);if(d){var e=d.get("sendHitTask");d.set("sendHitTask",function(f){var h=f.get("hitPayload"),k=f.get("hitCallback"),l=0>h.indexOf("&tid="+b);l&&(f.set("hitPayload",h.replace(/&tid=UA-[0-9]+-[0-9]+/,"&tid="+
b),!0),f.set("hitCallback",void 0,!0));e(f);l&&(f.set("hitPayload",h,!0),f.set("hitCallback",k,!0),f.set("_x_19",void 0,!0),e(f))})}}};
var ni=function(){return"&tc="+Mb.filter(function(a){return a}).length},qi=function(){2022<=oi().length&&pi()},si=function(){ri||(ri=G.setTimeout(pi,500))},pi=function(){ri&&(G.clearTimeout(ri),ri=void 0);void 0===ti||ui[ti]&&!vi&&!wi||(xi[ti]||yi.Bh()||0>=zi--?(Dc(1),xi[ti]=!0):(yi.Xh(),md(oi()),ui[ti]=!0,Ai=Bi=Ci=wi=vi=""))},oi=function(){var a=ti;if(void 0===a)return"";var b=Cc("GTM"),c=Cc("TAGGING");return[Di,ui[a]?"":"&es=1",Ei[a],b?"&u="+b:"",c?"&ut="+c:"",ni(),vi,wi,Ci?Ci:"",Bi,Ai,"&z=0"].join("")},
Fi=function(){return[Se,"&v=3&t=t","&pid="+Da(),"&rv="+Ie.ic].join("")},Gi="0.005000">Math.random(),Di=Fi(),Hi=function(){Di=Fi()},ui={},vi="",wi="",Ai="",Bi="",Ci="",ti=void 0,Ei={},xi={},ri=void 0,yi=function(a,b){var c=0,d=0;return{Bh:function(){if(c<a)return!1;Pa()-d>=b&&(c=0);return c>=a},Xh:function(){Pa()-d>=b&&(c=0);c++;d=Pa()}}}(2,1E3),zi=1E3,Ii=function(a,b,c){if(Gi&&!xi[a]&&b){a!==ti&&(pi(),ti=a);var d,e=String(b[Xb.Ma]||"").replace(/_/g,"");0===e.indexOf("cvt")&&(e="cvt");
d=e;var f=c+d;vi=vi?vi+"."+f:"&tr="+f;var h=b["function"];if(!h)throw Error("Error: No function name given for function call.");var k=(Ob[h]?"1":"2")+d;Ai=Ai?Ai+"."+k:"&ti="+k;si();qi()}},Ji=function(a,b,c){if(Gi&&!xi[a]){a!==ti&&(pi(),ti=a);var d=c+b;wi=wi?wi+"."+d:"&epr="+d;si();qi()}},Ki=function(a,b,c){};
function Li(a,b,c,d){var e=Mb[a],f=Mi(a,b,c,d);if(!f)return null;var h=Ub(e[Xb.Ue],c,[]);if(h&&h.length){var k=h[0];f=Li(k.index,{onSuccess:f,onFailure:1===k.ef?b.terminate:f,terminate:b.terminate},c,d)}return f}
function Mi(a,b,c,d){function e(){if(f[Xb.xg])k();else{var x=Vb(f,c,[]);var z=Rh(c.id,String(f[Xb.Ma]),Number(f[Xb.Ve]),x[Xb.yg]),A=!1;x.vtp_gtmOnSuccess=function(){if(!A){A=!0;var F=Pa()-D;Ii(c.id,Mb[a],"5");Sh(c.id,z,"success",
F);h()}};x.vtp_gtmOnFailure=function(){if(!A){A=!0;var F=Pa()-D;Ii(c.id,Mb[a],"6");Sh(c.id,z,"failure",F);k()}};x.vtp_gtmTagId=f.tag_id;x.vtp_gtmEventId=c.id;Ii(c.id,f,"1");var B=function(){var F=Pa()-D;Ii(c.id,f,"7");Sh(c.id,z,"exception",F);A||(A=!0,k())};var D=Pa();try{Tb(x,c)}catch(F){B(F)}}}var f=Mb[a],h=b.onSuccess,k=b.onFailure,l=b.terminate;if(c.yd(f))return null;var p=Ub(f[Xb.We],c,[]);if(p&&p.length){var r=p[0],n=Li(r.index,{onSuccess:h,onFailure:k,terminate:l},c,d);if(!n)return null;h=n;k=2===r.ef?l:n}if(f[Xb.Qe]||f[Xb.Ag]){var t=f[Xb.Qe]?Nb:
c.ei,q=h,u=k;if(!t[a]){e=Sa(e);var v=Ni(a,t,e);h=v.onSuccess;k=v.onFailure}return function(){t[a](q,u)}}return e}function Ni(a,b,c){var d=[],e=[];b[a]=Oi(d,e,c);return{onSuccess:function(){b[a]=Pi;for(var f=0;f<d.length;f++)d[f]()},onFailure:function(){b[a]=Qi;for(var f=0;f<e.length;f++)e[f]()}}}function Oi(a,b,c){return function(d,e){a.push(d);b.push(e);c()}}function Pi(a){a()}function Qi(a,b){b()};var Ti=function(a,b,c){for(var d=[],e=0;e<Mb.length;e++)if(a[e]){var f=Mb[e];var h=c.add();try{var k=Li(e,{onSuccess:h,onFailure:h,terminate:h},b,e);if(k){var l=d,p=l.push,r=e,n=f["function"];if(!n)throw"Error: No function name given for function call.";var t=Ob[n];p.call(l,{Cf:r,vf:t?t.priorityOverride||0:0,lh:k})}else Ri(e,b),h()}catch(u){h()}}c.Og();d.sort(Si);for(var q=0;q<d.length;q++)d[q].lh();return 0<
d.length};function Si(a,b){var c,d=b.vf,e=a.vf;c=d>e?1:d<e?-1:0;var f;if(0!==c)f=c;else{var h=a.Cf,k=b.Cf;f=h>k?1:h<k?-1:0}return f}function Ri(a,b){if(!Gi)return;var c=function(d){var e=b.yd(Mb[d])?"3":"4",f=Ub(Mb[d][Xb.Ue],b,[]);f&&f.length&&c(f[0].index);Ii(b.id,Mb[d],e);var h=Ub(Mb[d][Xb.We],b,[]);h&&h.length&&c(h[0].index)};c(a);}
var Ui=!1,Zi=function(a){var b=a["gtm.uniqueEventId"],c=a.event;if("gtm.js"===c){if(Ui)return!1;Ui=!0}var d=Bh(b),e=!1;if(!d.active){if("gtm.js"!==c)return!1;e=!0;d=Bh(Number.MAX_SAFE_INTEGER)}Gi&&!xi[b]&&ti!==b&&(pi(),ti=b,Ai=vi="",Ei[b]="&e="+(0===c.indexOf("gtm.")?encodeURIComponent(c):"*")+"&eid="+b,si());var f={id:b,name:c,yd:zh(d.isAllowed),ei:[],qf:function(){Dc(6)},$e:Vi(b)},h=Wh(b,a.eventCallback,a.eventTimeout);Wi(b);
var k=ac(f);e&&(k=Xi(k));var l=Ti(k,f,h);"gtm.js"!==c&&"gtm.sync"!==c||hi(Ie.D);switch(c){case "gtm.init":Dc(19),l&&Dc(20)}return Yi(k,l)};function Vi(a){return function(b){Gi&&(hb(b)||Ki(a,"input",b))}}
function Wi(a){ef(a,"event",1);ef(a,"ecommerce",1);ef(a,"gtm");ef(a,"eventModel");}function Xi(a){for(var b=[],c=0;c<a.length;c++)a[c]&&Ke[String(Mb[c][Xb.Ma])]&&(b[c]=!0);return b}function Yi(a,b){if(!b)return b;for(var c=0;c<a.length;c++)if(a[c]&&Mb[c]&&!Le[String(Mb[c][Xb.Ma])])return!0;return!1}function $i(a,b){if(a){var c=""+a;0!==c.indexOf("http://")&&0!==c.indexOf("https://")&&(c="https://"+c);"/"===c[c.length-1]&&(c=c.substring(0,c.length-1));return le(""+c+b).href}}function aj(a,b){return bj()?$i(a,b):void 0}function bj(){var a=!1;return a};var cj=function(){this.eventModel={};this.targetConfig={};this.containerConfig={};this.remoteConfig={};this.globalConfig={};this.onSuccess=function(){};this.onFailure=function(){};this.setContainerTypeLoaded=function(){};this.getContainerTypeLoaded=function(){};this.eventId=void 0},dj=function(a){var b=new cj;b.eventModel=a;return b},ej=function(a,b){a.targetConfig=b;return a},fj=function(a,b){a.containerConfig=b;return a},gj=function(a,b){a.remoteConfig=b;return a},hj=function(a,b){a.globalConfig=
b;return a},ij=function(a,b){a.onSuccess=b;return a},jj=function(a,b){a.setContainerTypeLoaded=b;return a},kj=function(a,b){a.getContainerTypeLoaded=b;return a},lj=function(a,b){a.onFailure=b;return a};cj.prototype.getWithConfig=function(a){if(void 0!==this.eventModel[a])return this.eventModel[a];if(void 0!==this.targetConfig[a])return this.targetConfig[a];if(void 0!==this.containerConfig[a])return this.containerConfig[a];if(void 0!==this.remoteConfig[a])return this.remoteConfig[a];if(void 0!==this.globalConfig[a])return this.globalConfig[a]};
var mj=function(a){function b(e){Ia(e,function(f){c[f]=null})}var c={};b(a.eventModel);b(a.targetConfig);b(a.containerConfig);b(a.globalConfig);var d=[];Ia(c,function(e){d.push(e)});return d};var nj;if(3===Ie.ic.length)nj="g";else{var oj="G";nj=oj}
var pj={"":"n",UA:"u",AW:"a",DC:"d",G:"e",GF:"f",HA:"h",GTM:nj,OPT:"o"},qj=function(a){var b=Ie.D.split("-"),c=b[0].toUpperCase(),d=pj[c]||"i",e=a&&"GTM"===c?b[1]:"OPT"===c?b[1]:"",f;if(3===Ie.ic.length){var h="w";f="2"+h}else f="";return f+d+Ie.ic+e};var rj=function(a,b){a.addEventListener&&a.addEventListener.call(a,"message",b,!1)};var sj=function(){return Tc("iPhone")&&!Tc("iPod")&&!Tc("iPad")};Tc("Opera");Tc("Trident")||Tc("MSIE");Tc("Edge");!Tc("Gecko")||-1!=Qc.toLowerCase().indexOf("webkit")&&!Tc("Edge")||Tc("Trident")||Tc("MSIE")||Tc("Edge");-1!=Qc.toLowerCase().indexOf("webkit")&&!Tc("Edge")&&Tc("Mobile");Tc("Macintosh");Tc("Windows");Tc("Linux")||Tc("CrOS");var tj=qa.navigator||null;tj&&(tj.appVersion||"").indexOf("X11");Tc("Android");sj();Tc("iPad");Tc("iPod");sj()||Tc("iPad")||Tc("iPod");Qc.toLowerCase().indexOf("kaios");var uj=function(a,b){for(var c=a,d=0;50>d;++d){var e;try{e=!(!c.frames||!c.frames[b])}catch(k){e=!1}if(e)return c;var f;a:{try{var h=c.parent;if(h&&h!=c){f=h;break a}}catch(k){}f=null}if(!(c=f))break}return null};var vj=function(){};var wj=function(a){void 0!==a.addtlConsent&&"string"!==typeof a.addtlConsent&&(a.addtlConsent=void 0);void 0!==a.gdprApplies&&"boolean"!==typeof a.gdprApplies&&(a.gdprApplies=void 0);return void 0!==a.tcString&&"string"!==typeof a.tcString||void 0!==a.listenerId&&"number"!==typeof a.listenerId?2:a.cmpStatus&&"error"!==a.cmpStatus?0:3},xj=function(a,b){this.o=a;this.m=null;this.K={};this.va=0;this.ja=void 0===b?500:b;this.C=null};pa(xj,vj);
var zj=function(a){return"function"===typeof a.o.__tcfapi||null!=yj(a)};
xj.prototype.addEventListener=function(a){var b={},c=Gc(function(){return a(b)}),d=0;-1!==this.ja&&(d=setTimeout(function(){b.tcString="tcunavailable";b.internalErrorState=1;c()},this.ja));var e=function(f,h){clearTimeout(d);f?(b=f,b.internalErrorState=wj(b),h&&0===b.internalErrorState||(b.tcString="tcunavailable",h||(b.internalErrorState=3))):(b.tcString="tcunavailable",b.internalErrorState=3);a(b)};try{Aj(this,"addEventListener",e)}catch(f){b.tcString="tcunavailable",b.internalErrorState=3,d&&(clearTimeout(d),
d=0),c()}};xj.prototype.removeEventListener=function(a){a&&a.listenerId&&Aj(this,"removeEventListener",null,a.listenerId)};
var Cj=function(a,b,c){var d;d=void 0===d?"755":d;var e;a:{if(a.publisher&&a.publisher.restrictions){var f=a.publisher.restrictions[b];if(void 0!==f){e=f[void 0===d?"755":d];break a}}e=void 0}var h=e;if(0===h)return!1;var k=c;2===c?(k=0,2===h&&(k=1)):3===c&&(k=1,1===h&&(k=0));var l;if(0===k)if(a.purpose&&a.vendor){var p=Bj(a.vendor.consents,void 0===d?"755":d);l=p&&"1"===b&&a.purposeOneTreatment&&"DE"===a.publisherCC?!0:p&&Bj(a.purpose.consents,b)}else l=!0;else l=1===k?a.purpose&&a.vendor?Bj(a.purpose.legitimateInterests,
b)&&Bj(a.vendor.legitimateInterests,void 0===d?"755":d):!0:!0;return l},Bj=function(a,b){return!(!a||!a[b])},Aj=function(a,b,c,d){c||(c=function(){});if("function"===typeof a.o.__tcfapi){var e=a.o.__tcfapi;e(b,2,c,d)}else if(yj(a)){Dj(a);var f=++a.va;a.K[f]=c;if(a.m){var h={};a.m.postMessage((h.__tcfapiCall={command:b,version:2,callId:f,parameter:d},h),"*")}}else c({},!1)},yj=function(a){if(a.m)return a.m;a.m=uj(a.o,"__tcfapiLocator");return a.m},Dj=function(a){a.C||(a.C=function(b){try{var c;c=("string"===
typeof b.data?JSON.parse(b.data):b.data).__tcfapiReturn;a.K[c.callId](c.returnValue,c.success)}catch(d){}},rj(a.o,a.C))};var Ej={1:0,3:0,4:0,7:3,9:3,10:3};function Fj(a,b){if(""===a)return b;var c=Number(a);return isNaN(c)?b:c}var Gj=Fj("",550),Hj=Fj("",500);function Ij(){var a=M.tcf||{};return M.tcf=a}
var Jj=function(a,b){this.C=a;this.m=b;this.o=Pa();},Kj=function(a){},Lj=function(a){},Rj=function(){var a=Ij(),b=new xj(G,3E3),c=new Jj(b,a);if((Mj()?!0===G.gtag_enable_tcf_support:!1!==G.gtag_enable_tcf_support)&&!a.active&&("function"===typeof G.__tcfapi||zj(b))){a.active=!0;a.Mb={};Nj();var d=setTimeout(function(){Oj(a);Pj(a);d=null},Hj);try{b.addEventListener(function(e){d&&(clearTimeout(d),d=null);if(0!==e.internalErrorState)Oj(a),Pj(a),Kj(c);else{var f;if(!1===e.gdprApplies)f=Qj(),b.removeEventListener(e);
else if("tcloaded"===e.eventStatus||"useractioncomplete"===e.eventStatus||"cmpuishown"===e.eventStatus){var h={},k;for(k in Ej)if(Ej.hasOwnProperty(k))if("1"===k){var l=e,p=!0;p=void 0===p?!1:p;var r;var n=l;!1===n.gdprApplies?r=!0:(void 0===n.internalErrorState&&(n.internalErrorState=wj(n)),r="error"===n.cmpStatus||0!==n.internalErrorState||"loaded"===n.cmpStatus&&("tcloaded"===n.eventStatus||"useractioncomplete"===n.eventStatus)?!0:!1);h["1"]=r?!1===l.gdprApplies||"tcunavailable"===l.tcString||
void 0===l.gdprApplies&&!p||"string"!==typeof l.tcString||!l.tcString.length?!0:Cj(l,"1",0):!1}else h[k]=Cj(e,k,Ej[k]);f=h}f&&(a.tcString=e.tcString||"tcempty",a.Mb=f,Pj(a),Kj(c))}}),Lj(c)}catch(e){d&&(clearTimeout(d),d=null),Oj(a),Pj(a)}}};function Oj(a){a.type="e";a.tcString="tcunavailable";a.Mb=Qj()}function Nj(){var a={};Nd((a.ad_storage="denied",a.wait_for_update=Gj,a))}
var Mj=function(){var a=!1;a=!0;return a};function Qj(){var a={},b;for(b in Ej)Ej.hasOwnProperty(b)&&(a[b]=!0);return a}function Pj(a){var b={};Od((b.ad_storage=a.Mb["1"]?"granted":"denied",b))}
var Sj=function(){var a=Ij();if(a.active&&void 0!==a.loadTime)return Number(a.loadTime)},Tj=function(){var a=Ij();return a.active?a.tcString||"":""},Uj=function(a){if(!Ej.hasOwnProperty(String(a)))return!0;var b=Ij();return b.active&&b.Mb?!!b.Mb[String(a)]:!0};var Vj=!1;function Wj(a){var b=String(G.location).split(/[?#]/)[0],c=Ie.Kf||G._CONSENT_MODE_SALT;return a?c?String(nf(b+a+c)):"0":""}
function Xj(a){function b(q){var u;M.reported_gclid||(M.reported_gclid={});u=M.reported_gclid;var v;v=Vj&&h&&(!Hd()||Pd(E.B))?l+"."+(f.prefix||"_gcl")+(q?"gcu":"gcs"):l+(q?"gcu":"gcs");if(!u[v]){u[v]=!0;var x=[],y=function(D,F){F&&x.push(D+"="+encodeURIComponent(F))},w="https://www.google.com";if(Hd()){var z=Pd(E.B);y("gcs",Qd());q&&y("gcu","1");M.dedupe_gclid||
(M.dedupe_gclid=""+Cf());y("rnd",M.dedupe_gclid);if((!l||p&&"aw.ds"!==p)&&Pd(E.B)){var A=Ag("_gcl_aw");y("gclaw",A.join("."))}y("url",String(G.location).split(/[?#]/)[0]);y("dclid",Yj(d,r));!z&&d&&(w="https://pagead2.googlesyndication.com")}y("gdpr_consent",Tj());"1"===jg(!1)._up&&y("gtm_up","1");y("gclid",Yj(d,
l));y("gclsrc",p);y("gtm",qj(!e));Vj&&h&&Pd(E.B)&&(Of(f||{}),y("auid",Jf[Kf(f.prefix)]||""));var B=w+"/pagead/landing?"+x.join("&");td(B)}}var c=!!a.pd,d=!!a.qa,e=a.R,f=void 0===a.nc?{}:a.nc,h=void 0===a.yc?!0:a.yc,k=Dg(),l=k.gclid||"",p=k.gclsrc,r=k.dclid||"",n=!c&&(!l||p&&"aw.ds"!==p?!1:!0),t=Hd();if(n||t)t?Rd(function(){b();Pd(E.B)||Kd(function(q){return b(!0,q.af)},E.B)},[E.B]):b()}function Yj(a,b){var c=a&&!Pd(E.B);return b&&c?"0":b}var Ik=function(){var a=!0;Uj(7)&&Uj(9)&&Uj(10)||(a=!1);var b=!0;b=!1;b&&!Hk()&&(a=!1);return a},Hk=function(){var a=!0;Uj(3)&&Uj(4)||(a=!1);return a};var dl=!1;function el(){var a=M;return a.gcq=a.gcq||new fl}
var gl=function(a,b,c){el().register(a,b,c)},hl=function(a,b,c,d){el().push("event",[b,a],c,d)},il=function(a,b){el().push("config",[a],b)},jl=function(a,b,c,d){el().push("get",[a,b],c,d)},kl={},ll=function(){this.status=1;this.containerConfig={};this.targetConfig={};this.remoteConfig={};this.o=null;this.m=!1},ml=function(a,b,c,d,e){this.type=a;this.C=b;this.R=c||"";this.m=d;this.o=e},fl=function(){this.K={};this.o={};this.m=[];this.C={AW:!1,UA:!1}},nl=function(a,b){var c=Zg(b);return a.K[c.containerId]=
a.K[c.containerId]||new ll},ol=function(a,b,c){if(b){var d=Zg(b);if(d&&1===nl(a,b).status){nl(a,b).status=2;var e={};Gi&&(e.timeoutId=G.setTimeout(function(){Dc(38);si()},3E3));a.push("require",[e],d.containerId);kl[d.containerId]=Pa();if(bh()){}else{var h=
"/gtag/js?id="+encodeURIComponent(d.containerId)+"&l=dataLayer&cx=c",k=("http:"!=G.location.protocol?"https:":"http:")+("//www.googletagmanager.com"+h),l=aj(c,h)||k;jd(l)}}}},pl=function(a,b,c,d){if(d.R){var e=nl(a,d.R),f=e.o;if(f){var h=C(c),k=C(e.targetConfig[d.R]),l=C(e.containerConfig),p=C(e.remoteConfig),r=C(a.o),n=af("gtm.uniqueEventId"),t=Zg(d.R).prefix,q=kj(jj(lj(ij(hj(gj(fj(ej(dj(h),k),l),p),r),function(){Ji(n,t,"2");}),function(){
Ji(n,t,"3");}),function(u,v){a.C[u]=v}),function(u){return a.C[u]});try{Ji(n,t,"1");f(d.R,b,d.C,q)}catch(u){Ji(n,t,"4");}}}};aa=fl.prototype;
aa.register=function(a,b,c){var d=nl(this,a);if(3!==d.status){d.o=b;d.status=3;if(c){d.remoteConfig=c}var e=Zg(a),f=kl[e.containerId];if(void 0!==f){var h=M[e.containerId].bootstrap,k=e.prefix.toUpperCase();M[e.containerId]._spx&&(k=k.toLowerCase());var l=af("gtm.uniqueEventId"),p=k,r=Pa()-h;if(Gi&&!xi[l]){l!==ti&&(pi(),ti=l);var n=p+"."+Math.floor(h-f)+
"."+Math.floor(r);Bi=Bi?Bi+","+n:"&cl="+n}delete kl[e.containerId]}this.flush()}};aa.push=function(a,b,c,d){var e=Math.floor(Pa()/1E3);ol(this,c,b[0][E.La]||this.o[E.La]);dl&&c&&nl(this,c).m&&(d=!1);this.m.push(new ml(a,e,c,b,d));d||this.flush()};aa.insert=function(a,b,c){var d=Math.floor(Pa()/1E3);0<this.m.length?this.m.splice(1,0,new ml(a,d,c,b,!1)):this.m.push(new ml(a,d,c,b,!1))};
aa.flush=function(a){for(var b=this,c=[],d=!1;this.m.length;){var e=this.m[0];if(e.o)dl?!e.R||nl(this,e.R).m?(e.o=!1,this.m.push(e)):c.push(e):(e.o=!1,this.m.push(e));else switch(e.type){case "require":if(3!==nl(this,e.R).status&&!a){dl&&this.m.push.apply(this.m,c);return}Gi&&G.clearTimeout(e.m[0].timeoutId);break;case "set":Ia(e.m[0],function(t,q){C(Za(t,q),b.o)});break;case "config":var f=e.m[0],h=!!f[E.ac];delete f[E.ac];var k=nl(this,e.R),l=Zg(e.R),p=l.containerId===l.id;h||(p?k.containerConfig=
{}:k.targetConfig[e.R]={});k.m&&h||pl(this,E.ca,f,e);k.m=!0;delete f[E.xb];p?C(f,k.containerConfig):C(f,k.targetConfig[e.R]);dl&&(d=!0);break;case "event":pl(this,e.m[1],e.m[0],e);break;case "get":var r={},n=(r[E.Aa]=e.m[0],r[E.za]=e.m[1],r);pl(this,E.Ia,n,e)}this.m.shift()}dl&&(this.m.push.apply(this.m,c),d&&this.flush())};aa.getRemoteConfig=function(a){return nl(this,a).remoteConfig};var ql=function(a,b,c){function d(f,h){var k=f[h];return k}var e={event:b,"gtm.element":a,"gtm.elementClasses":d(a,"className"),"gtm.elementId":a["for"]||pd(a,"id")||"","gtm.elementTarget":a.formTarget||d(a,"target")||""};c&&(e["gtm.triggers"]=c.join(","));e["gtm.elementUrl"]=(a.attributes&&a.attributes.formaction?a.formAction:"")||a.action||d(a,"href")||a.src||a.code||a.codebase||
"";return e},rl=function(a){M.hasOwnProperty("autoEventsSettings")||(M.autoEventsSettings={});var b=M.autoEventsSettings;b.hasOwnProperty(a)||(b[a]={});return b[a]},sl=function(a,b,c){rl(a)[b]=c},tl=function(a,b,c,d){var e=rl(a),f=Ra(e,b,d);e[b]=c(f)},ul=function(a,b,c){var d=rl(a);return Ra(d,b,c)};var vl=!!G.MutationObserver,wl=void 0,xl=function(a){if(!wl){var b=function(){var c=H.body;if(c)if(vl)(new MutationObserver(function(){for(var e=0;e<wl.length;e++)I(wl[e])})).observe(c,{childList:!0,subtree:!0});else{var d=!1;nd(c,"DOMNodeInserted",function(){d||(d=!0,I(function(){d=!1;for(var e=0;e<wl.length;e++)I(wl[e])}))})}};wl=[];H.body?b():I(b)}wl.push(a)};
var yl=function(a,b,c){function d(){var h=a();f+=e?(Pa()-e)*h.playbackRate/1E3:0;e=Pa()}var e=0,f=0;return{createEvent:function(h,k,l){var p=a(),r=p.df,n=void 0!==l?Math.round(l):void 0!==k?Math.round(p.df*k):Math.round(p.fh),t=void 0!==k?Math.round(100*k):0>=r?0:Math.round(n/r*100),q=H.hidden?!1:.5<=Zd(c);d();var u=void 0;void 0!==b&&(u=[b]);var v=ql(c,"gtm.video",u);v["gtm.videoProvider"]="youtube";v["gtm.videoStatus"]=h;v["gtm.videoUrl"]=p.url;v["gtm.videoTitle"]=p.title;v["gtm.videoDuration"]=
Math.round(r);v["gtm.videoCurrentTime"]=Math.round(n);v["gtm.videoElapsedTime"]=Math.round(f);v["gtm.videoPercent"]=t;v["gtm.videoVisible"]=q;return v},$h:function(){e=Pa()},md:function(){d()}}};var zl=!1,Al=[];function Bl(){if(!zl){zl=!0;for(var a=0;a<Al.length;a++)I(Al[a])}}var Cl=function(a){zl?I(a):Al.push(a)};var Dl="HA GF G UA AW DC".split(" "),El=!1,Fl={},Gl=!1;function Hl(a,b){var c={event:a};b&&(c.eventModel=C(b),b[E.Tc]&&(c.eventCallback=b[E.Tc]),b[E.Xb]&&(c.eventTimeout=b[E.Xb]));return c}function Il(){return El}
var Ll={config:function(a){var b;return b},consent:function(a){function b(){Il()&&
C(a[2],{subcommand:a[1]})}if(3===a.length){Dc(39);var c=Ve(),d=a[1];"default"===d?(b(),Nd(a[2])):"update"===d&&(b(),Od(a[2],c))}},event:function(a){var b=a[1];if(!(2>a.length)&&g(b)){var c;if(2<a.length){if(!gb(a[2])&&void 0!=a[2]||3<a.length)return;c=a[2]}var d=Hl(b,c);return d}},get:function(a){},js:function(a){if(2==a.length&&a[1].getTime)return Gl=!0,Il(),{event:"gtm.js","gtm.start":a[1].getTime()}},policy:function(){},set:function(a){var b;2==a.length&&gb(a[1])?b=C(a[1]):3==a.length&&g(a[1])&&(b={},gb(a[2])||Aa(a[2])?b[a[1]]=C(a[2]):b[a[1]]=a[2]);if(b){b._clear=!0;return b}}},Ml={policy:!0};var Nl=function(a,b){var c=a.hide;if(c&&void 0!==c[b]&&c.end){c[b]=!1;var d=!0,e;for(e in c)if(c.hasOwnProperty(e)&&!0===c[e]){d=!1;break}d&&(c.end(),c.end=null)}},Pl=function(a){var b=Ol(),c=b&&b.hide;c&&c.end&&(c[a]=!0)};var hm=function(a){if(gm(a))return a;this.m=a};hm.prototype.sh=function(){return this.m};var gm=function(a){return!a||"object"!==eb(a)||gb(a)?!1:"getUntrustedUpdateValue"in a};hm.prototype.getUntrustedUpdateValue=hm.prototype.sh;var im=[];var lm=!1,mm=function(a){return G["dataLayer"].push(a)},nm=function(a){var b=M["dataLayer"],c=b?b.subscribers:1,d=0;return function(){++d===c&&a()}};
function om(a){var b=a._clear;Ia(a,function(d,e){"_clear"!==d&&(b&&df(d,void 0),df(d,e))});Qe||(Qe=a["gtm.start"]);var c=a["gtm.uniqueEventId"];if(!a.event)return!1;c||(c=Ve(),a["gtm.uniqueEventId"]=c,df("gtm.uniqueEventId",c));return Zi(a)}function pm(){var a=im[0];if(null==a||"object"!==typeof a)return!1;if(a.event)return!0;if(Ja(a)){var b=a[0];if("config"===b||"event"===b||"js"===b)return!0}return!1}
function qm(){for(var a=!1;!lm&&0<im.length;){
lm=!0;delete Ye.eventModel;$e();var d=im.shift();if(null!=d){var e=gm(d);if(e){var f=d;d=gm(f)?f.getUntrustedUpdateValue():void 0;for(var h=["gtm.allowlist","gtm.blocklist","gtm.whitelist","gtm.blacklist","tagTypeBlacklist"],k=0;k<h.length;k++){var l=h[k],p=af(l,1);if(Aa(p)||gb(p))p=C(p);Ze[l]=p}}try{if(ya(d))try{d.call(bf)}catch(y){}else if(Aa(d)){var r=d;if(g(r[0])){var n=r[0].split("."),t=n.pop(),q=r.slice(1),u=af(n.join("."),2);if(void 0!==u&&null!==u)try{u[t].apply(u,q)}catch(y){}}}else{if(Ja(d)){a:{var v=
d;if(v.length&&g(v[0])){var x=Ll[v[0]];if(x&&(!e||!Ml[v[0]])){d=x(v);break a}}d=void 0}if(!d){lm=!1;continue}}a=om(d)||a}}finally{e&&$e(!0)}}lm=!1}return!a}function rm(){var a=qm();try{Nl(G["dataLayer"],Ie.D)}catch(b){}return a}
var tm=function(){var a=cd("dataLayer",[]),b=cd("google_tag_manager",{});b=b["dataLayer"]=b["dataLayer"]||{};Oh(function(){b.gtmDom||(b.gtmDom=!0,a.push({event:"gtm.dom"}))});Cl(function(){b.gtmLoad||(b.gtmLoad=!0,a.push({event:"gtm.load"}))});b.subscribers=(b.subscribers||0)+1;var c=a.push;a.push=function(){var e;if(0<M.SANDBOXED_JS_SEMAPHORE){e=[];for(var f=0;f<arguments.length;f++)e[f]=new hm(arguments[f])}else e=[].slice.call(arguments,0);var h=c.apply(a,e);im.push.apply(im,e);if(300<
this.length)for(Dc(4);300<this.length;)this.shift();var k="boolean"!==typeof h||h;return qm()&&k};var d=a.slice(0);im.push.apply(im,d);sm()&&I(rm)},sm=function(){var a=!0;return a};var um={};um.bc=new String("undefined");
var vm=function(a){this.m=function(b){for(var c=[],d=0;d<a.length;d++)c.push(a[d]===um.bc?b:a[d]);return c.join("")}};vm.prototype.toString=function(){return this.m("undefined")};vm.prototype.valueOf=vm.prototype.toString;um.Dg=vm;um.jd={};um.eh=function(a){return new vm(a)};var wm={};um.Yh=function(a,b){var c=Ve();wm[c]=[a,b];return c};um.cf=function(a){var b=a?0:1;return function(c){var d=wm[c];if(d&&"function"===typeof d[b])d[b]();wm[c]=void 0}};um.Ah=function(a){for(var b=!1,c=!1,d=2;d<a.length;d++)b=
b||8===a[d],c=c||16===a[d];return b&&c};um.Rh=function(a){if(a===um.bc)return a;var b=Ve();um.jd[b]=a;return'google_tag_manager["'+Ie.D+'"].macro('+b+")"};um.Kh=function(a,b,c){a instanceof um.Dg&&(a=a.m(um.Yh(b,c)),b=xa);return{wd:a,onSuccess:b}};var xm=["input","select","textarea"],ym=["button","hidden","image","reset","submit"],zm=function(a){var b=a.tagName.toLowerCase();return!Ba(xm,function(c){return c===b})||"input"===b&&Ba(ym,function(c){return c===a.type.toLowerCase()})?!1:!0},Am=function(a){return a.form?a.form.tagName?a.form:H.getElementById(a.form):sd(a,["form"],100)},Bm=function(a,b,c){if(!a.elements)return 0;for(var d=b.getAttribute(c),e=0,f=1;e<a.elements.length;e++){var h=a.elements[e];if(zm(h)){if(h.getAttribute(c)===d)return f;
f++}}return 0};var Mm=G.clearTimeout,Nm=G.setTimeout,N=function(a,b,c){if(bh()){b&&I(b)}else return jd(a,b,c)},Om=function(){return new Date},Pm=function(){return G.location.href},Qm=function(a){return je(le(a),"fragment")},Rm=function(a){return ke(le(a))},Sm=function(a,b){return af(a,b||2)},Tm=function(a,b,c){var d;b?(a.eventCallback=b,c&&(a.eventTimeout=c),d=mm(a)):d=mm(a);return d},Um=function(a,b){G[a]=b},U=function(a,b,c){b&&
(void 0===G[a]||c&&!G[a])&&(G[a]=b);return G[a]},Vm=function(a,b,c){return qf(a,b,void 0===c?!0:!!c)},Wm=function(a,b,c){return 0===zf(a,b,c)},Xm=function(a,b){if(bh()){b&&I(b)}else ld(a,b)},Ym=function(a){return!!ul(a,"init",!1)},Zm=function(a){sl(a,"init",!0)},$m=function(a,b){var c=(void 0===b?0:b)?"www.googletagmanager.com/gtag/js":Oe;c+="?id="+encodeURIComponent(a)+"&l=dataLayer";N(dh("https://","http://",c))},an=function(a,
b){var c=a[b];return c},bn=function(a,b,c){Gi&&(hb(a)||Ki(c,b,a))};
var cn=um.Kh;function An(a,b){a=String(a);b=String(b);var c=a.length-b.length;return 0<=c&&a.indexOf(b,c)==c}var Bn=new Ea;function Cn(a,b){function c(h){var k=le(h),l=je(k,"protocol"),p=je(k,"host",!0),r=je(k,"port"),n=je(k,"path").toLowerCase().replace(/\/$/,"");if(void 0===l||"http"==l&&"80"==r||"https"==l&&"443"==r)l="web",r="default";return[l,p,r,n]}for(var d=c(String(a)),e=c(String(b)),f=0;f<d.length;f++)if(d[f]!==e[f])return!1;return!0}
function Dn(a){return En(a)?1:0}
function En(a){var b=a.arg0,c=a.arg1;if(a.any_of&&Aa(c)){for(var d=0;d<c.length;d++){var e=C(a,{});C({arg1:c[d],any_of:void 0},e);if(Dn(e))return!0}return!1}switch(a["function"]){case "_cn":return 0<=String(b).indexOf(String(c));case "_css":var f;a:{if(b){var h=["matches","webkitMatchesSelector","mozMatchesSelector","msMatchesSelector","oMatchesSelector"];try{for(var k=0;k<h.length;k++)if(b[h[k]]){f=b[h[k]](c);break a}}catch(q){}}f=!1}return f;case "_ew":return An(b,c);case "_eq":return String(b)==
String(c);case "_ge":return Number(b)>=Number(c);case "_gt":return Number(b)>Number(c);case "_lc":var l;l=String(b).split(",");return 0<=m(l,String(c));case "_le":return Number(b)<=Number(c);case "_lt":return Number(b)<Number(c);case "_re":var p;var r=a.ignore_case?"i":void 0;try{var n=String(c)+r,t=Bn.get(n);t||(t=new RegExp(c,r),Bn.set(n,t));p=t.test(b)}catch(q){p=!1}return p;case "_sw":return 0==String(b).indexOf(String(c));case "_um":return Cn(b,c)}return!1};var Fn=encodeURI,Y=encodeURIComponent,Gn=md;var Hn=function(a,b){if(!a)return!1;var c=je(le(a),"host");if(!c)return!1;for(var d=0;b&&d<b.length;d++){var e=b[d]&&b[d].toLowerCase();if(e){var f=c.length-e.length;0<f&&"."!=e.charAt(0)&&(f--,e="."+e);if(0<=f&&c.indexOf(e,f)==f)return!0}}return!1};
var In=function(a,b,c){for(var d={},e=!1,f=0;a&&f<a.length;f++)a[f]&&a[f].hasOwnProperty(b)&&a[f].hasOwnProperty(c)&&(d[a[f][b]]=a[f][c],e=!0);return e?d:null};function op(){return G.gaGlobal=G.gaGlobal||{}}var pp=function(){var a=op();a.hid=a.hid||Da();return a.hid},qp=function(a,b){var c=op();if(void 0==c.vid||b&&!c.from_cookie)c.vid=a,c.from_cookie=b};var Zp=window,$p=document,aq=function(a){var b=Zp._gaUserPrefs;if(b&&b.ioo&&b.ioo()||a&&!0===Zp["ga-disable-"+a])return!0;try{var c=Zp.external;if(c&&c._gaUserPrefs&&"oo"==c._gaUserPrefs)return!0}catch(f){}for(var d=of("AMP_TOKEN",String($p.cookie),!0),e=0;e<d.length;e++)if("$OPT_OUT"==d[e])return!0;return $p.getElementById("__gaOptOutExtension")?!0:!1};var bq={};function dq(a){delete a.eventModel[E.xb];fq(a.eventModel)}
var fq=function(a){Ia(a,function(c){"_"===c.charAt(0)&&delete a[c]});var b=a[E.ma]||{};Ia(b,function(c){"_"===c.charAt(0)&&delete b[c]})};var iq=function(a,b,c){hl(b,c,a)},jq=function(a,b,c){hl(b,c,a,!0)},qq=function(a,b){};
function kq(a,b){}var Z={g:{}};

Z.g.jsm=["customScripts"],function(){(function(a){Z.__jsm=a;Z.__jsm.h="jsm";Z.__jsm.i=!0;Z.__jsm.priorityOverride=0})(function(a){if(void 0!==a.vtp_javascript){var b=a.vtp_javascript;try{var c=U("google_tag_manager");var d=c&&c.e&&c.e(b);bn(d,"jsm",a.vtp_gtmEventId);return d}catch(e){}}})}();
Z.g.c=["google"],function(){(function(a){Z.__c=a;Z.__c.h="c";Z.__c.i=!0;Z.__c.priorityOverride=0})(function(a){bn(a.vtp_value,"c",a.vtp_gtmEventId);return a.vtp_value})}();
Z.g.e=["google"],function(){(function(a){Z.__e=a;Z.__e.h="e";Z.__e.i=!0;Z.__e.priorityOverride=0})(function(a){return String(ff(a.vtp_gtmEventId,"event"))})}();
Z.g.f=["google"],function(){(function(a){Z.__f=a;Z.__f.h="f";Z.__f.i=!0;Z.__f.priorityOverride=0})(function(a){var b=Sm("gtm.referrer",1)||H.referrer;return b?a.vtp_component&&"URL"!=a.vtp_component?je(le(String(b)),a.vtp_component,a.vtp_stripWww,a.vtp_defaultPages,a.vtp_queryKey):Rm(String(b)):String(b)})}();
Z.g.cl=["google"],function(){function a(b){var c=b.target;if(c){var d=ql(c,"gtm.click");Tm(d)}}(function(b){Z.__cl=b;Z.__cl.h="cl";Z.__cl.i=!0;Z.__cl.priorityOverride=0})(function(b){if(!Ym("cl")){var c=U("document");nd(c,"click",a,!0);Zm("cl")}I(b.vtp_gtmOnSuccess)})}();
Z.g.j=["google"],function(){(function(a){Z.__j=a;Z.__j.h="j";Z.__j.i=!0;Z.__j.priorityOverride=0})(function(a){for(var b=String(a.vtp_name).split("."),c=U(b.shift()),d=0;d<b.length;d++)c=c&&c[b[d]];bn(c,"j",a.vtp_gtmEventId);return c})}();Z.g.k=["google"],function(){(function(a){Z.__k=a;Z.__k.h="k";Z.__k.i=!0;Z.__k.priorityOverride=0})(function(a){return Vm(a.vtp_name,Sm("gtm.cookie",1),!!a.vtp_decodeCookie)[0]})}();

Z.g.t=["google"],function(){(function(a){Z.__t=a;Z.__t.h="t";Z.__t.i=!0;Z.__t.priorityOverride=0})(function(){return Om().getTime()})}();
Z.g.u=["google"],function(){var a=function(b){return{toString:function(){return b}}};(function(b){Z.__u=b;Z.__u.h="u";Z.__u.i=!0;Z.__u.priorityOverride=0})(function(b){var c;c=(c=b.vtp_customUrlSource?b.vtp_customUrlSource:Sm("gtm.url",1))||Pm();var d=b[a("vtp_component")];if(!d||"URL"==d)return Rm(String(c));var e=le(String(c)),f;if("QUERY"===d)a:{var h=b[a("vtp_multiQueryKeys").toString()],k=b[a("vtp_queryKey").toString()]||"",l=b[a("vtp_ignoreEmptyQueryParam").toString()],p;h?Aa(k)?p=k:p=String(k).replace(/\s+/g,
"").split(","):p=[String(k)];for(var r=0;r<p.length;r++){var n=je(e,"QUERY",void 0,void 0,p[r]);if(void 0!=n&&(!l||""!==n)){f=n;break a}}f=void 0}else f=je(e,d,"HOST"==d?b[a("vtp_stripWww")]:void 0,"PATH"==d?b[a("vtp_defaultPages")]:void 0,void 0);return f})}();
Z.g.v=["google"],function(){(function(a){Z.__v=a;Z.__v.h="v";Z.__v.i=!0;Z.__v.priorityOverride=0})(function(a){var b=a.vtp_name;if(!b||!b.replace)return!1;var c=Sm(b.replace(/\\\./g,"."),a.vtp_dataLayerVersion||1),d=void 0!==c?c:a.vtp_defaultValue;bn(d,"v",a.vtp_gtmEventId);return d})}();
Z.g.ua=["google"],function(){function a(n){return Pd(n)}function b(n,t){if(Hd()&&!e[n]){var q=function(){var u=bi(),v="gtm"+Ve(),x=p(t),y={name:v};l(x,y,!0);u("create",n,y);u(function(){u.remove(v)})};Kd(q,E.I);Kd(q,E.B);e[n]=!0}}var c,d={},e={},f={name:!0,clientId:!0,sampleRate:!0,siteSpeedSampleRate:!0,alwaysSendReferrer:!0,allowAnchor:!0,allowLinker:!0,cookieName:!0,cookieDomain:!0,cookieExpires:!0,cookiePath:!0,cookieUpdate:!0,cookieFlags:!0,legacyCookieDomain:!0,legacyHistoryImport:!0,storage:!0,
useAmpClientId:!0,storeGac:!0,_cd2l:!0,_useUp:!0,_cs:!0},h={allowAnchor:!0,allowLinker:!0,alwaysSendReferrer:!0,anonymizeIp:!0,cookieUpdate:!0,exFatal:!0,forceSSL:!0,javaEnabled:!0,legacyHistoryImport:!0,nonInteraction:!0,useAmpClientId:!0,useBeacon:!0,storeGac:!0,allowAdFeatures:!0,allowAdPersonalizationSignals:!0,_cd2l:!0},k={urlPassthrough:!0},l=function(n,t,q){var u=0;if(n)for(var v in n)if(!k[v]&&n.hasOwnProperty(v)&&(q&&f[v]||!q&&void 0===f[v])){var x=h[v]?Ma(n[v]):n[v];"anonymizeIp"!=v||x||
(x=void 0);t[v]=x;u++}return u},p=function(n){var t={};n.vtp_gaSettings&&C(In(n.vtp_gaSettings.vtp_fieldsToSet,"fieldName","value"),t);C(In(n.vtp_fieldsToSet,"fieldName","value"),t);Pd(E.I)||(t.storage="none");Pd(E.B)||(t.allowAdFeatures=!1,t.storeGac=!1);Ik()||(t.allowAdFeatures=!1);Hk()||(t.allowAdPersonalizationSignals=!1);n.vtp_transportUrl&&(t._x_19=n.vtp_transportUrl);
return t},r=function(n){function t(ca,T){void 0!==T&&F("set",ca,T)}var q={},u={},v={},x={};if(n.vtp_gaSettings){var y=n.vtp_gaSettings;C(In(y.vtp_contentGroup,"index","group"),u);C(In(y.vtp_dimension,"index","dimension"),v);C(In(y.vtp_metric,"index","metric"),x);var w=C(y);w.vtp_fieldsToSet=void 0;w.vtp_contentGroup=void 0;w.vtp_dimension=
void 0;w.vtp_metric=void 0;n=C(n,w)}C(In(n.vtp_contentGroup,"index","group"),u);C(In(n.vtp_dimension,"index","dimension"),v);C(In(n.vtp_metric,"index","metric"),x);var z=p(n),A=di(n.vtp_functionName);if(ya(A)){var B="",D="";n.vtp_setTrackerName&&"string"==typeof n.vtp_trackerName?""!==n.vtp_trackerName&&(D=n.vtp_trackerName,B=D+"."):(D="gtm"+Ve(),B=D+".");var F=function(ca){var T=[].slice.call(arguments,0);T[0]=B+T[0];A.apply(window,T)},K=function(ca,T){return void 0===T?T:ca(T)},P=function(ca,T){if(T)for(var Qa in T)T.hasOwnProperty(Qa)&&
F("set",ca+Qa,T[Qa])},S=function(){},W={name:D};l(z,W,!0);var ja=n.vtp_trackingId||q.trackingId;A("create",ja,W);F("set","&gtm",qj(!0));
Hd()&&(F("set","&gcs",Qd()),b(ja,n));z._x_19&&(null==bd&&delete z._x_19,z._x_20&&!d[D]&&(d[D]=!0,A(ii(D,String(z._x_20)))));n.vtp_enableRecaptcha&&F("require","recaptcha","recaptcha.js");(function(ca,T){void 0!==n[T]&&F("set",ca,n[T])})("nonInteraction","vtp_nonInteraction");P("contentGroup",u);P("dimension",v);P("metric",x);var O={};l(z,O,!1)&&F("set",O);var J;
n.vtp_enableLinkId&&F("require","linkid","linkid.js");F("set","hitCallback",function(){var ca=z&&z.hitCallback;ya(ca)&&ca();n.vtp_gtmOnSuccess()});var L=function(ca,T){return void 0===n[ca]?q[T]:n[ca]};if("TRACK_EVENT"==n.vtp_trackType){n.vtp_enableEcommerce&&(F("require","ec","ec.js"),S());var X={hitType:"event",eventCategory:String(L("vtp_eventCategory","category")),eventAction:String(L("vtp_eventAction","action")),eventLabel:K(String,
L("vtp_eventLabel","label")),eventValue:K(Ka,L("vtp_eventValue","value"))};l(J,X,!1);F("send",X);}else if("TRACK_SOCIAL"==n.vtp_trackType){}else if("TRACK_TRANSACTION"==
n.vtp_trackType){}else if("TRACK_TIMING"==n.vtp_trackType){}else if("DECORATE_LINK"==
n.vtp_trackType){}else if("DECORATE_FORM"==n.vtp_trackType){}else if("TRACK_DATA"==n.vtp_trackType){}else{n.vtp_enableEcommerce&&
(F("require","ec","ec.js"),S());if(n.vtp_doubleClick||"DISPLAY_FEATURES"==n.vtp_advertisingFeaturesType){var Sb="_dc_gtm_"+String(n.vtp_trackingId).replace(/[^A-Za-z0-9-]/g,"");F("require","displayfeatures",void 0,{cookieName:Sb})}if("DISPLAY_FEATURES_WITH_REMARKETING_LISTS"==n.vtp_advertisingFeaturesType){var sb="_dc_gtm_"+String(n.vtp_trackingId).replace(/[^A-Za-z0-9-]/g,"");F("require","adfeatures",{cookieName:sb})}J?F("send","pageview",J):F("send","pageview");Ma(z.urlPassthrough)&&fi(B)}if(!c){var Ha=n.vtp_useDebugVersion?"u/analytics_debug.js":"analytics.js";n.vtp_useInternalVersion&&!n.vtp_useDebugVersion&&(Ha="internal/"+Ha);c=!0;var Cb=aj(z._x_19,"/analytics.js"),Ec=dh("https:","http:","//www.google-analytics.com/"+Ha,z&&!!z.forceSSL);N("analytics.js"===Ha&&Cb?Cb:Ec,function(){var ca=
bi();ca&&ca.loaded||n.vtp_gtmOnFailure();},n.vtp_gtmOnFailure)}}else I(n.vtp_gtmOnFailure)};(function(n){Z.__ua=n;Z.__ua.h="ua";Z.__ua.i=!0;Z.__ua.priorityOverride=0})(function(n){Rd(function(){r(n)},[E.I,E.B])})}();




Z.g.ytl=["google"],function(){function a(){var u=Math.round(1E9*Math.random())+"";return H.getElementById(u)?a():u}function b(u,v){if(!u)return!1;for(var x=0;x<r.length;x++)if(0<=u.indexOf("//"+r[x]+"/"+v))return!0;return!1}function c(u,v){var x=u.getAttribute("src");if(b(x,"embed/")){if(0<x.indexOf("enablejsapi=1"))return!0;if(v){var y=u.setAttribute,w;var z=-1!==x.indexOf("?")?"&":"?";if(-1<x.indexOf("origin="))w=x+z+"enablejsapi=1";else{if(!t){var A=U("document");t=A.location.protocol+"//"+A.location.hostname;
A.location.port&&(t+=":"+A.location.port)}w=x+z+"enablejsapi=1&origin="+encodeURIComponent(t)}y.call(u,"src",w);return!0}}return!1}function d(u,v){if(!u.getAttribute("data-gtm-yt-inspected-"+v.Sd)&&(u.setAttribute("data-gtm-yt-inspected-"+v.Sd,"true"),c(u,v.jf))){u.id||(u.id=a());var x=U("YT"),y=x.get(u.id);y||(y=new x.Player(u.id));var w=f(y,v),z={},A;for(A in w)z.kb=A,w.hasOwnProperty(z.kb)&&y.addEventListener(z.kb,function(B){return function(D){return w[B.kb](D.data)}}(z)),z={kb:z.kb}}}function e(u){I(function(){function v(){for(var y=
x.getElementsByTagName("iframe"),w=y.length,z=0;z<w;z++)d(y[z],u)}var x=U("document");v();xl(v)})}function f(u,v){var x,y;function w(){W=yl(function(){return{url:J,title:L,df:O,fh:u.getCurrentTime(),playbackRate:X}},v.Sd,u.getIframe());O=0;L=J="";X=1;return z}function z(la){switch(la){case n.PLAYING:O=Math.round(u.getDuration());J=u.getVideoUrl();if(u.getVideoData){var R=u.getVideoData();L=R?R.title:""}X=u.getPlaybackRate();v.Zg?Tm(W.createEvent("start")):W.md();ja=l(v.Th,v.Sh,u.getDuration());return A(la);
default:return z}}function A(){ha=u.getCurrentTime();V=Om().getTime();W.$h();S();return B}function B(la){var R;switch(la){case n.ENDED:return F(la);case n.PAUSED:R="pause";case n.BUFFERING:var ka=u.getCurrentTime()-ha;R=1<Math.abs((Om().getTime()-V)/1E3*X-ka)?"seek":R||"buffering";u.getCurrentTime()&&(v.Yg?Tm(W.createEvent(R)):W.md());P();return D;case n.UNSTARTED:return w(la);default:return B}}function D(la){switch(la){case n.ENDED:return F(la);case n.PLAYING:return A(la);case n.UNSTARTED:return w(la);
default:return D}}function F(){for(;y;){var la=x;Mm(y);la()}v.Xg&&Tm(W.createEvent("complete",1));return w(n.UNSTARTED)}function K(){}function P(){y&&(Mm(y),y=0,x=K)}function S(){if(ja.length&&0!==X){var la=-1,R;do{R=ja[0];if(R.Oa>u.getDuration())return;la=(R.Oa-u.getCurrentTime())/X;if(0>la&&(ja.shift(),0===ja.length))return}while(0>la);x=function(){y=0;x=K;0<ja.length&&ja[0].Oa===R.Oa&&(ja.shift(),Tm(W.createEvent("progress",R.tf,R.xf)));S()};y=Nm(x,1E3*la)}}var W,ja=[],O,J,L,X,ha,V,wa=w(n.UNSTARTED);
y=0;x=K;return{onStateChange:function(la){wa=wa(la)},onPlaybackRateChange:function(la){ha=u.getCurrentTime();V=Om().getTime();W.md();X=la;P();S()}}}function h(u){for(var v=u.split(","),x=v.length,y=[],w=0;w<x;w++){var z=parseInt(v[w],10);isNaN(z)||100<z||0>z||y.push(z/100)}y.sort(function(A,B){return A-B});return y}function k(u){for(var v=u.split(","),x=v.length,y=[],w=0;w<x;w++){var z=parseInt(v[w],10);isNaN(z)||0>z||y.push(z)}y.sort(function(A,B){return A-B});return y}function l(u,v,x){var y=u.map(function(A){return{Oa:A,
xf:A,tf:void 0}});if(!v.length)return y;var w=v.map(function(A){return{Oa:A*x,xf:void 0,tf:A}});if(!y.length)return w;var z=y.concat(w);z.sort(function(A,B){return A.Oa-B.Oa});return z}function p(u){var v=!!u.vtp_captureStart,x=!!u.vtp_captureComplete,y=!!u.vtp_capturePause,w=h(u.vtp_progressThresholdsPercent+""),z=k(u.vtp_progressThresholdsTimeInSeconds+""),A=!!u.vtp_fixMissingApi;if(v||x||y||w.length||z.length){var B={Zg:v,Xg:x,Yg:y,Sh:w,Th:z,jf:A,Sd:void 0===u.vtp_uniqueTriggerId?"":u.vtp_uniqueTriggerId},
D=U("YT"),F=function(){e(B)};I(u.vtp_gtmOnSuccess);if(D)D.ready&&D.ready(F);else{var K=U("onYouTubeIframeAPIReady");Um("onYouTubeIframeAPIReady",function(){K&&K();F()});I(function(){for(var P=U("document"),S=P.getElementsByTagName("script"),W=S.length,ja=0;ja<W;ja++){var O=S[ja].getAttribute("src");if(b(O,"iframe_api")||b(O,"player_api"))return}for(var J=P.getElementsByTagName("iframe"),L=J.length,X=0;X<L;X++)if(!q&&c(J[X],B.jf)){N("https://www.youtube.com/iframe_api");q=!0;break}})}}else I(u.vtp_gtmOnSuccess)}
var r=["www.youtube.com","www.youtube-nocookie.com"],n={UNSTARTED:-1,ENDED:0,PLAYING:1,PAUSED:2,BUFFERING:3,CUED:5},t,q=!1;(function(u){Z.__ytl=u;Z.__ytl.h="ytl";Z.__ytl.i=!0;Z.__ytl.priorityOverride=0})(function(u){u.vtp_triggerStartOption?p(u):Oh(function(){p(u)})})}();




Z.g.aev=["google"],function(){function a(q,u){var v=ff(q,"gtm");if(v)return v[u]}function b(q,u,v,x){x||(x="element");var y=q+"."+u,w;if(r.hasOwnProperty(y))w=r[y];else{var z=a(q,x);if(z&&(w=v(z),r[y]=w,n.push(y),35<n.length)){var A=n.shift();delete r[A]}}return w}function c(q,u,v){var x=a(q,t[u]);return void 0!==x?x:v}function d(q,u){if(!q)return!1;var v=e(Pm());Aa(u)||(u=String(u||"").replace(/\s+/g,"").split(","));for(var x=[v],y=0;y<u.length;y++){var w=u[y];if(w.hasOwnProperty("is_regex"))if(w.is_regex)try{w=
new RegExp(w.domain)}catch(A){continue}else w=w.domain;if(w instanceof RegExp){if(w.test(q))return!1}else{var z=w;if(0!=z.length){if(0<=e(q).indexOf(z))return!1;x.push(e(z))}}}return!Hn(q,x)}function e(q){p.test(q)||(q="http://"+q);return je(le(q),"HOST",!0)}function f(q,u,v){switch(q){case "SUBMIT_TEXT":return b(u,"FORM."+q,h,"formSubmitElement")||v;case "LENGTH":var x=b(u,"FORM."+q,k);return void 0===x?v:x;case "INTERACTED_FIELD_ID":return l(u,"id",v);case "INTERACTED_FIELD_NAME":return l(u,"name",
v);case "INTERACTED_FIELD_TYPE":return l(u,"type",v);case "INTERACTED_FIELD_POSITION":var y=a(u,"interactedFormFieldPosition");return void 0===y?v:y;case "INTERACT_SEQUENCE_NUMBER":var w=a(u,"interactSequenceNumber");return void 0===w?v:w;default:return v}}function h(q){switch(q.tagName.toLowerCase()){case "input":return pd(q,"value");case "button":return qd(q);default:return null}}function k(q){if("form"===q.tagName.toLowerCase()&&q.elements){for(var u=0,v=0;v<q.elements.length;v++)zm(q.elements[v])&&
u++;return u}}function l(q,u,v){var x=a(q,"interactedFormField");return x&&pd(x,u)||v}var p=/^https?:\/\//i,r={},n=[],t={ATTRIBUTE:"elementAttribute",CLASSES:"elementClasses",ELEMENT:"element",ID:"elementId",HISTORY_CHANGE_SOURCE:"historyChangeSource",HISTORY_NEW_STATE:"newHistoryState",HISTORY_NEW_URL_FRAGMENT:"newUrlFragment",HISTORY_OLD_STATE:"oldHistoryState",HISTORY_OLD_URL_FRAGMENT:"oldUrlFragment",TARGET:"elementTarget"};(function(q){Z.__aev=q;Z.__aev.h="aev";Z.__aev.i=!0;Z.__aev.priorityOverride=
0})(function(q){var u=q.vtp_gtmEventId,v=q.vtp_defaultValue,x=q.vtp_varType;switch(x){case "TAG_NAME":var y=a(u,"element");return y&&y.tagName||v;case "TEXT":return b(u,x,qd)||v;case "URL":var w;a:{var z=String(a(u,"elementUrl")||v||""),A=le(z),B=String(q.vtp_component||"URL");switch(B){case "URL":w=z;break a;case "IS_OUTBOUND":w=d(z,q.vtp_affiliatedDomains);break a;default:w=je(A,B,q.vtp_stripWww,q.vtp_defaultPages,q.vtp_queryKey)}}return w;case "ATTRIBUTE":var D;if(void 0===q.vtp_attribute)D=c(u,
x,v);else{var F=q.vtp_attribute,K=a(u,"element");D=K&&pd(K,F)||v||""}return D;case "MD":var P=q.vtp_mdValue,S=b(u,"MD",Im);return P&&S?Lm(S,P)||v:S||v;case "FORM":return f(String(q.vtp_component||"SUBMIT_TEXT"),u,v);default:var W=c(u,x,v);bn(W,"aev",q.vtp_gtmEventId);return W}})}();Z.g.gas=["google"],function(){(function(a){Z.__gas=a;Z.__gas.h="gas";Z.__gas.i=!0;Z.__gas.priorityOverride=0})(function(a){var b=C(a),c=b;c[Xb.Ma]=null;c[Xb.vg]=null;var d=b=c;d.vtp_fieldsToSet=d.vtp_fieldsToSet||[];var e=d.vtp_cookieDomain;void 0!==e&&(d.vtp_fieldsToSet.push({fieldName:"cookieDomain",value:e}),delete d.vtp_cookieDomain);return b})}();Z.g.smm=["google"],function(){(function(a){Z.__smm=a;Z.__smm.h="smm";Z.__smm.i=!0;Z.__smm.priorityOverride=0})(function(a){var b=a.vtp_input,c=In(a.vtp_map,"key","value")||{},d=c.hasOwnProperty(b)?c[b]:a.vtp_defaultValue;bn(d,"smm",a.vtp_gtmEventId);return d})}();



Z.g.paused=[],function(){(function(a){Z.__paused=a;Z.__paused.h="paused";Z.__paused.i=!0;Z.__paused.priorityOverride=0})(function(a){I(a.vtp_gtmOnFailure)})}();

Z.g.zone=[],function(){function a(r){for(var n=r.vtp_boundaries||[],t=0;t<n.length;t++)if(!n[t])return!1;return!0}function b(r){var n=Ie.D,t=n+":"+r.vtp_gtmTagId,q=Sm("gtm.uniqueEventId")||0,u=Ch(function(){return new h}),v=a(r),x=r.vtp_enableTypeRestrictions?r.vtp_whitelistedTypes.map(function(D){return D.typeId}):null;x=x&&Wa(x,f);if(u.registerZone(t,q,v,x))for(var y=r.vtp_childContainers.map(function(D){return D.publicId}),w=0;w<y.length;w++){var z=String(y[w]);if(u.registerChild(z,n,t)){var A=
0!==z.indexOf("GTM-");if(A){var B=function(D,F){Tm(arguments)};B("js",new Date);p?(B("config",z),l||$m(z,A)):(M.addTargetToGroup(z),il({},z))}else $m(z,A)}}}var c={active:!1,isAllowed:function(){return!1},Ch:function(){return!1}},d={active:!0,isAllowed:function(){return!0},Ch:function(){return!0}},e={zone:!0,cn:!0,css:!0,ew:!0,eq:!0,ge:!0,gt:!0,lc:!0,le:!0,lt:!0,re:!0,sw:!0,um:!0},f={cl:["ecl"],ecl:["cl"],ehl:["hl"],hl:["ehl"]},h=function(){this.m={};this.o={}};h.prototype.checkState=function(r,n){var t=
this.m[r];if(!t)return d;var q=this.checkState(t.sf,n);if(!q.active)return c;for(var u=[],v=0;v<t.Vd.length;v++){var x=this.o[t.Vd[v]];x.Ib(n)&&u.push(x)}return u.length?{active:!0,isAllowed:function(y,w){w=w||[];var z=q.isAllowed;if(!z(y,w))return!1;for(var A=0;A<u.length;++A)if(u[A].isAllowed(y,w))return!0;return!1}}:c};h.prototype.unregisterChild=function(r){delete this.m[r]};h.prototype.registerZone=function(r,n,t,q){var u=this.o[r];if(u)return u.C(n,t),!1;if(!t)return!1;this.o[r]=new k(n,q);
return!0};h.prototype.registerChild=function(r,n,t){var q=this.m[r];if(!q&&M[r]||q&&q.sf!==n)return!1;if(q)return q.Vd.push(t),!1;this.m[r]={sf:n,Vd:[t]};return!0};var k=function(r,n){this.m=[{eventId:r,Ib:!0}];this.o=null;if(n){this.o={};for(var t=0;t<n.length;t++)this.o[n[t]]=!0}};k.prototype.C=function(r,n){var t=this.m[this.m.length-1];r<=t.eventId||t.Ib!=n&&this.m.push({eventId:r,Ib:n})};k.prototype.Ib=function(r){if(!this.m||0==this.m.length)return!1;for(var n=this.m.length-1;0<=n;n--)if(this.m[n].eventId<=
r)return this.m[n].Ib;return!1};k.prototype.isAllowed=function(r,n){n=n||[];if(!this.o||e[r]||this.o[r])return!0;for(var t=0;t<n.length;++t)if(this.o[n[t]])return!0;return!1};var l=!1;var p=!0;p=!1;(function(r){Z.__zone=r;Z.__zone.h="zone";Z.__zone.i=
!0;Z.__zone.priorityOverride=0})(function(r){b(r);I(r.vtp_gtmOnSuccess)})}();
Z.g.html=["customScripts"],function(){function a(d,e,f,h){return function(){try{if(0<e.length){var k=e.shift(),l=a(d,e,f,h);if("SCRIPT"==String(k.nodeName).toUpperCase()&&"text/gtmscript"==k.type){var p=H.createElement("script");p.async=!1;p.type="text/javascript";p.id=k.id;p.text=k.text||k.textContent||k.innerHTML||"";k.charset&&(p.charset=k.charset);var r=k.getAttribute("data-gtmsrc");r&&(p.src=r,dd(p,l));d.insertBefore(p,null);r||l()}else if(k.innerHTML&&0<=k.innerHTML.toLowerCase().indexOf("<script")){for(var n=
[];k.firstChild;)n.push(k.removeChild(k.firstChild));d.insertBefore(k,null);a(k,n,l,h)()}else d.insertBefore(k,null),l()}else f()}catch(t){I(h)}}}var b=function(d,e,f){Oh(function(){var h=M.postscribe,k={done:e},l=H.createElement("div");l.style.display="none";l.style.visibility="hidden";H.body.appendChild(l);try{h(l,d,k)}catch(p){I(f)}})};var c=function(d){if(H.body){var e=d.vtp_gtmOnFailure,f=cn(d.vtp_html,d.vtp_gtmOnSuccess,
e),h=f.wd,k=f.onSuccess;if(d.vtp_useIframe){}else d.vtp_supportDocumentWrite?b(h,k,e):a(H.body,rd(h),k,e)()}else Nm(function(){c(d)},200)};Z.__html=c;Z.__html.h="html";
Z.__html.i=!0;Z.__html.priorityOverride=0}();






Z.g.lcl=[],function(){function a(){var c=U("document"),d=0,e=function(f){var h=f.target;if(h&&3!==f.which&&!(f.zh||f.timeStamp&&f.timeStamp===d)){d=f.timeStamp;h=sd(h,["a","area"],100);if(!h)return f.returnValue;var k=f.defaultPrevented||!1===f.returnValue,l=ul("lcl",k?"nv.mwt":"mwt",0),p;p=k?ul("lcl","nv.ids",[]):ul("lcl","ids",[]);if(p.length){var r=ql(h,"gtm.linkClick",p);if(b(f,h,c)&&!k&&l&&h.href){var n=String(an(h,"rel")||""),t=!!Ba(n.split(" "),function(v){return"noreferrer"===v.toLowerCase()});
t&&Dc(36);var q=U((an(h,"target")||"_self").substring(1)),u=!0;if(Tm(r,nm(function(){var v;if(v=u&&q){var x;a:if(t){var y;try{var w=void 0;w={bubbles:!0};y=new MouseEvent(f.type,w)}catch(z){if(!c.createEvent){x=!1;break a}y=c.createEvent("MouseEvents");y.initEvent(f.type,!0,!0)}y.zh=!0;f.target.dispatchEvent(y);x=!0}else x=!1;v=!x}v&&(q.location.href=an(h,"href"))}),l))u=!1;else return f.preventDefault&&
f.preventDefault(),f.returnValue=!1}else Tm(r,function(){},l||2E3);return!0}}};nd(c,"click",e,!1);nd(c,"auxclick",e,!1)}function b(c,d,e){if(2===c.which||c.ctrlKey||c.shiftKey||c.altKey||c.metaKey)return!1;var f=an(d,"href"),h=f.indexOf("#"),k=an(d,"target");if(k&&"_self"!==k&&"_parent"!==k&&"_top"!==k||0===h)return!1;if(0<h){var l=Rm(f),p=Rm(e.location);return l!==p}return!0}(function(c){Z.__lcl=c;Z.__lcl.h="lcl";Z.__lcl.i=!0;Z.__lcl.priorityOverride=0})(function(c){var d=void 0===c.vtp_waitForTags?
!0:c.vtp_waitForTags,e=void 0===c.vtp_checkValidation?!0:c.vtp_checkValidation,f=Number(c.vtp_waitForTagsTimeout);if(!f||0>=f)f=2E3;var h=c.vtp_uniqueTriggerId||"0";if(d){var k=function(p){return Math.max(f,p)};tl("lcl","mwt",k,0);e||tl("lcl","nv.mwt",k,0)}var l=function(p){p.push(h);return p};tl("lcl","ids",l,[]);e||tl("lcl","nv.ids",l,[]);Ym("lcl")||(a(),Zm("lcl"));I(c.vtp_gtmOnSuccess)})}();
Z.g.evl=["google"],function(){function a(){var f=Number(Sm("gtm.start"))||0;return Om().getTime()-f}function b(f,h,k,l){function p(){if(!Xd(f.target)){h.has(d.hc)||h.set(d.hc,""+a());h.has(d.fd)||h.set(d.fd,""+a());var n=0;h.has(d.jc)&&(n=Number(h.get(d.jc)));n+=100;h.set(d.jc,""+n);if(n>=k){var t=ql(f.target,"gtm.elementVisibility",[h.m]),q=Zd(f.target);t["gtm.visibleRatio"]=Math.round(1E3*q)/10;t["gtm.visibleTime"]=k;t["gtm.visibleFirstTime"]=Number(h.get(d.fd));t["gtm.visibleLastTime"]=Number(h.get(d.hc));
Tm(t);l()}}}if(!h.has(d.Ab)&&(0==k&&p(),!h.has(d.cb))){var r=U("self").setInterval(p,100);h.set(d.Ab,r)}}function c(f){f.has(d.Ab)&&(U("self").clearInterval(Number(f.get(d.Ab))),f.o(d.Ab))}var d={Ab:"polling-id-",fd:"first-on-screen-",hc:"recent-on-screen-",jc:"total-visible-time-",cb:"has-fired-"},e=function(f,h){this.element=f;this.m=h};e.prototype.has=function(f){return!!this.element.getAttribute("data-gtm-vis-"+f+this.m)};e.prototype.get=function(f){return this.element.getAttribute("data-gtm-vis-"+
f+this.m)};e.prototype.set=function(f,h){this.element.setAttribute("data-gtm-vis-"+f+this.m,h)};e.prototype.o=function(f){this.element.removeAttribute("data-gtm-vis-"+f+this.m)};(function(f){Z.__evl=f;Z.__evl.h="evl";Z.__evl.i=!0;Z.__evl.priorityOverride=0})(function(f){function h(){var y=!1,w=null;if("CSS"===l){try{w=Td(p)}catch(F){Dc(46)}y=!!w&&v.length!=w.length}else if("ID"===l){var z=H.getElementById(p);z&&(w=[z],y=1!=v.length||v[0]!==z)}w||(w=[],y=0<v.length);if(y){for(var A=0;A<v.length;A++){var B=
new e(v[A],q);c(B)}v=[];for(var D=0;D<w.length;D++)v.push(w[D]);0<=x&&ee(x);0<v.length&&(x=de(k,v,[t]))}}function k(y){var w=new e(y.target,q);y.intersectionRatio>=t?w.has(d.cb)||b(y,w,n,"ONCE"===u?function(){for(var z=0;z<v.length;z++){var A=new e(v[z],q);A.set(d.cb,"1");c(A)}ee(x);if(r&&wl)for(var B=0;B<wl.length;B++)wl[B]===h&&wl.splice(B,1)}:function(){w.set(d.cb,"1");c(w)}):(c(w),"MANY_PER_ELEMENT"===u&&w.has(d.cb)&&(w.o(d.cb),w.o(d.jc)),w.o(d.hc))}var l=f.vtp_selectorType,p;"ID"===l?p=String(f.vtp_elementId):
"CSS"===l&&(p=String(f.vtp_elementSelector));var r=!!f.vtp_useDomChangeListener,n=f.vtp_useOnScreenDuration&&Number(f.vtp_onScreenDuration)||0,t=(Number(f.vtp_onScreenRatio)||50)/100,q=f.vtp_uniqueTriggerId,u=f.vtp_firingFrequency,v=[],x=-1;h();r&&xl(h);I(f.vtp_gtmOnSuccess)})}();


var rq={};rq.macro=function(a){if(um.jd.hasOwnProperty(a))return um.jd[a]},rq.onHtmlSuccess=um.cf(!0),rq.onHtmlFailure=um.cf(!1);rq.dataLayer=bf;rq.callback=function(a){Te.hasOwnProperty(a)&&ya(Te[a])&&Te[a]();delete Te[a]};rq.bootstrap=0;rq._spx=!1;function sq(){M[Ie.D]=rq;Ta(Ue,Z.g);Qb=Qb||um;Rb=bc}
function tq(){vd.gtag_cs_api=!0;M=G.google_tag_manager=G.google_tag_manager||{};Rj();if(M[Ie.D]){var a=M.zones;a&&a.unregisterChild(Ie.D);}else{for(var b=data.resource||{},c=b.macros||[],d=0;d<c.length;d++)Jb.push(c[d]);
for(var e=b.tags||[],f=0;f<e.length;f++)Mb.push(e[f]);for(var h=b.predicates||[],k=0;k<h.length;k++)Lb.push(h[k]);for(var l=b.rules||[],p=0;p<l.length;p++){for(var r=l[p],n={},t=0;t<r.length;t++)n[r[t][0]]=Array.prototype.slice.call(r[t],1);Kb.push(n)}Ob=Z;Pb=Dn;sq();tm();Jh=!1;Kh=0;if("interactive"==H.readyState&&!H.createEventObject||"complete"==H.readyState)Mh();else{nd(H,"DOMContentLoaded",Mh);nd(H,"readystatechange",Mh);if(H.createEventObject&&H.documentElement.doScroll){var q=!0;try{q=!G.frameElement}catch(w){}q&&
Nh()}nd(G,"load",Mh)}zl=!1;"complete"===H.readyState?Bl():nd(G,"load",Bl);a:{if(!Gi)break a;G.setInterval(Hi,864E5);}var y=M;y.postscribe||(y.postscribe=G.postscribe||zc);Re=(new Date).getTime();}}
(function(a){if(!G["__TAGGY_INSTALLED"]){var b=!1;if(H.referrer){var c=le(H.referrer);b="cct.google"===ie(c,"host")}if(!b){var d=qf("googTaggyReferrer");b=d.length&&d[0].length}b&&(G["__TAGGY_INSTALLED"]=!0,jd("https://cct.google/taggy/agent.js"))}var f=function(){var p=G["google.tagmanager.debugui2.queue"];p||(p=[],G["google.tagmanager.debugui2.queue"]=p,jd("https://www.googletagmanager.com/debug/bootstrap"));return p},h="x"===je(G.location,"query",!1,void 0,"gtm_debug");if(!h&&H.referrer){var k=le(H.referrer);h="tagassistant.google.com"===ie(k,"host")}if(!h){var l=qf("__TAG_ASSISTANT");h=l.length&&l[0].length}G.__TAG_ASSISTANT_API&&(h=!0);h&&bd?f().push({messageType:"CONTAINER_STARTING",
data:{scriptSource:bd,resume:function(){a()}}}):a()})(tq);

})()
