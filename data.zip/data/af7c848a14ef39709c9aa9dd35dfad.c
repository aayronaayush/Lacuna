
AdFuel.registry.push([
{
  "rktr_deployed_date": "2017-05-10 14:43:20",
  "rktr_slot_id": "page",
  "rktr_id": "cnni_entitlement_01",
  "gpt_id": "8663477",
  "site": "cnni",
  "root": "CNNI",
  "targeting": []
}
,
{
  "rktr_slot_id": "ad_mod_85a882a72",
  "rktr_ad_id": "CNNi",
  "sizes": [[175,31],[200,60]],
  "targeting": [["pos",["mod"]]],
  "responsive":[[["1024", "0"], [["200", "60"], ["175", "31"]]], [["782", "0"], [["200", "60"], ["175", "31"]]], [["0", "0"], [["200", "60"], ["175", "31"]]]]
}

]);
