    var edgeSupport_674591 = "f";
    var isIEBrowser_674591=false;
    var browserVersion_674591;

    function initiateNewRequest_674591(edgeSupport, html5Support) {
            var newUrl = "https://ads.everesttech.net/ads/mts/15699/4249?DFA_Click_Tracker=https%3A%2F%2Fadclick.g.doubleclick.net%2Fpcs%2Fclick%3Fxai%3DAKAOjsvnXWhH6SwmdQS38csZKMIyIdluOTnIjlkSx9q3T6zDUWsOIXzUNxevFJukC0gLF8yLzn_mNHd2ACVIthNxcp3RGhZ3JprB6CigH3tD2PtG2GqRZz-4mC6-f065zL3xiv5WLJ07BrGO0tQPVIL8VkZ9A5ZW-h7E-8ET3k2AJZJq3vbPWHKWqXe-1crD85q3rhh3AnopTjDceqBbB9zvRI3isW2oYm54aeyZjlARRMf93TCodDje6g5-JTlGpiwWQs9VZoe_YA0nlzXcasLykE3czZX_ATSzRLgZvQOJms49_fmCRtNvZnJTSKYfIX8veDgTw5tpMNPYJjXggoqz_E4n036VxmipoQBOzfLDWPNeH9dHxqDa1PujuiBNVltu7K3dq6Eq_ui-bR2nwVdffVK9oZ3tNPGgB__QUsisUtdsxMWGg_k0Et4CChMz4Lk6OJqBGOHCNpB3KdG7RFkpg3vLS1ulamK2JNJ7Nx2E3i1JOnA_Uy3yz_hqn-TkYU4wAl1tXxU24y4F2TgrRlUpQR-I_PQTYxR841jFpNOTB8I2XOswkcdpKSCE4c0vSmpRnc8-hpbcS-K6Q6xg2eYJfWeu8Fg_9cEnBckbyEn_bxGtnm0KVWiJhJnJjdrRm-746zmGKSFrqk4imcfzKnoWG3mAITf5XTIBQm5Gcij6_GjbBflG3sdJcKmEwcpRoUGpIvQ6qBKJGpHxsiPPWSFuIGgawKsNgeLK9tTpXMtSIek6VgCxWousn8M-by1eFFYXrZ-_J4ooTPONMt2IRQhDHIOH50-dTJuXoZj5ow_7-OAriqIWPlWZUFOF_tfJLWdlwJNClpBskcwnEFHYFxl2Oi3nXa52GvagI4Tk7VAs_OLNaT7GwRSxH1zXdXzaGNugwU2otsT3HJCdYdlABQlD_JfUX13Z4EOX1PjYFnFZsJgmpeNJN3s_-Uh_0ipQP8Hz2-T5fxys62nh2-fOWRa1UICxML3lKdziS9xD-kBbWATI8aOJgto_yAzJOFUFmGudUv1oiYIHYGg_pSn-bcyMlKycRJUzGgIGv1MHb6nrkSlIt7HT5JbmWw%26sai%3DAMfl-YQCHxkjpPj0TkoiDo436zYzEawrBLFKSzmogFt-DWgioR1vMUgMXxp3MiRK8Y71V1LbThO2ABe-bAHv10MaWIaJVm5VssshAIrclkQz9pZF-YENsAH3RXGCeDA5ZdJKQXU3MCdZm5cE9Y-RBY6n2uMj-70ejdE3YU7sINwh%26sig%3DCg0ArKJSzOX6Qc-7pJzWEAE%26urlfix%3D1%26adurl%3D&DFA_BuyId=25098950&DFA_PlacementId=290313581&DFA_AdId=484260885&DFA_CreativeId=119738357&DFA_SiteId=3654125&TC_1=2100124&TC_2=25098950&TC_3=290313581&TC_4=119738357&TC_5=dcmadvertiserid|8391437$dcmcampaignid|25098950$dcmadid|484260885$dcmrenderingid|119807174$dcmsiteid|3654125$dcmplacementid|290313581$customer|Microsoft$dv360auctionid|ct=AE&st=&city=13129&dma=0&zp=&bw=4&DCM_PlacementID=290313581" + "&edge=" + edgeSupport + "&html5="+ html5Support +"&nr=" + Math.random();
            if(document.readyState === "complete")
            {
                var sc = document.createElement("script");
                sc.setAttribute("type","text/javascript");
                sc.setAttribute("src",newUrl);
                if (document.currentScript) {
                    var pn = document.currentScript.parentNode;
                    var sbn = document.currentScript.nextSibling;
                    if (sbn) {
                        pn.insertBefore(sc,sbn);
                    } else {
                        pn.appendChild(sc);
                    }
                } else {
                    document.body.appendChild(sc);
                }
            } else {
                document.write('<' + 'script type="text/javascript" src="' + newUrl +'"></' + 'script>');
            }
        }

     function getInternetExplorerVersion_674591() {
         // Returns the version of Internet Explorer or a -1
         // (indicating the use of another browser).

             var rv = -1; // Return value assumes failure.
             if (navigator.appName == 'Microsoft Internet Explorer') {
                 isIEBrowser_674591=true;
                 var ua = navigator.userAgent;
                 var re  = new RegExp("MSIE ([0-9]{1,}[\.0-9]{0,})");

                 if (re.exec(ua) != null)
                     rv = parseFloat( RegExp.$1 );
             }

             return rv;
         }

      //returns true if ie version is less than 9, say ie6, ie7, ie8
         // -1 for non IE browsers.
         function isIEBrowserWithVersionLessThan9_674591 () {

             browserVersion_674591 = getInternetExplorerVersion_674591();  //-1 for non IE browsers
             if((browserVersion_674591 != -1) && (browserVersion_674591 < 9)) {
                 return true;

             }
             return false;
         }

    //code to detect Edge Features, courtesy  (http://dl.dropboxusercontent.com/u/13483458/test-edge.html)
    var testEle_674591=document.createElement("div_674591");
    function isSupported_674591(a){

        var d=testEle_674591.style,e;
        for(i=0;i<a.length;i++)
            if(e=a[i],d[e]!==void 0)
                return!0;
        return!1
    }

    function supportsRGBA_674591(){

        testEle_674591.cssText="background-color:rgba(150,255,150,.5)";
        if((""+testEle_674591.style.backgroundColor).indexOf("rgba")==0)
            return!0;
        return!1
    }

    var hasTransform_674591=isSupported_674591([
        "transformProperty",
        "WebkitTransform",
        "MozTransform",
        "OTransform",
        "msTransform"
    ]),

    hasSVG_674591=!!document.createElementNS&&!!document.createElementNS("http://www.w3.org/2000/svg","svg").createSVGRect,
    hasRGBA_674591=supportsRGBA_674591(),
    hasJSON_674591=window.JSON&&window.JSON.parse&&window.JSON.stringify,
    readyToPlay=!1;

    function isIEBrowserVersion9_674591() {
        return (isIEBrowser_674591 && (browserVersion_674591 == 9)) ? true : false;
    }

    function isEdgeSupported_674591() {
        if(isIEBrowserVersion9_674591()) {
            return "y";           //hardcoding IE9 edge support.
        }
        if(hasTransform_674591) {
            if(requiresSVG_674591&&!hasSVG_674591)
                return "f";
            return "y";
        }
        return "f";
    }

    function isCanvasSupported_674591(){
      var elem = document.createElement('canvas');
      return !!(elem.getContext && elem.getContext('2d'));
    }

    function isHTML5FeaturesSupported_674591() {
         return (isCanvasSupported_674591()) ? "y" : "f";
    }

    var requiresSVG_674591=false;
    //edge detection code end

    //Edge is not supported in IE 6,7,8. Hence hardcoding edge as not supported for the same.
   // edgeSupport_674591 = (isIEBrowserWithVersionLessThan9_674591()) ? "f" : isHTMLFeaturesSupported_674591(featureArray_674591);
    edgeSupport_674591 = (isIEBrowserWithVersionLessThan9_674591()) ? "f" : isEdgeSupported_674591();
    html5Support_674591 = isHTML5FeaturesSupported_674591();

    initiateNewRequest_674591(edgeSupport_674591, html5Support_674591);
