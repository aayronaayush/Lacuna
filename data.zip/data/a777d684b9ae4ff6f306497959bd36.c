(function(){
  window['optimizely'] = window['optimizely'] || [];
  window['optimizely'].push(['activateGeoDelayedExperiments', {
    'location':{
      'city': "DUBAI",
      'continent': "AS",
      'country': "AE",
      'region': ""
    },
    'ip':"91.230.41.203"
  }]);
})
//
()

;