(function($){
  $(document).ready(function(){
    $("a.colorbox").each(function(){
      var imgAlt = $("img", this).attr("alt");
      $(this).attr("title", imgAlt);
      $(this).attr("rel", "colorbox-gallery");
    });
  });
})( jQuery );
;
(function($){
     $.fn.expandable = function (options) {
         var settings = $.extend({}, $.fn.expandable.defaults, options);

         return this.each(function(){

            var $tabs = $(this);
            prepareTabs($tabs);
            tabEvents($tabs);
            accordionEvents($tabs);
            selectEvents($tabs);
            displayTabs($tabs);


        });
    };

    $.fn.expandable.defaults = {


    }

    function prepareTabs($tabs) {
      //var config = this.config;

      // Add aria, accordion headers
      $('.expandable-tablist .expandable-tablist-item', $tabs).each(function(i){
        var $tab = $('a', this);

        $tab.attr({
          'aria-selected': 'false',
        });
        $('.expandable-tabcontent:eq(' + i + ')', $tabs).attr({
          'aria-hidden':'true',
          'aria-labelledby':$tab.attr('id')
        });
        $('.expandable-panel', $tabs).hide();

        var id = $($tab).data('expandable-panel');
        var label = $($tab).text();
        var link = '<a href="#' + id +'" role="tab" tabindex="0" aria-controls="' + id + '" aria-expanded="false" id="accordion-section-' + id + '" class="text-color">' + label + '</a>';
        $('.expandable-tabcontent:eq(' + i + ')', $tabs).before('<strong class="expandable-accordion-heading">' + link + '</strong>');
        // $('.expandable-accordion-heading', $tabs).hide();



        $(".expandable-tablist li[role='tab']").keydown(function(ev) {
          if (ev.which ==13) {
            $('a', this).click();
          }
          if ((ev.which ==39)||(ev.which ==37)) {
           var selected= $(this).attr("aria-selected");
           if (selected =="true"){
             $("li[aria-selected='false']").attr("aria-selected","true").focus() ;
             $(this).attr("aria-selected","false");
             var tabpanid= $("li[aria-selected='true']").attr("aria-controls");
             var tabpan = $("#"+tabpanid);
             $("div[role='tabpanel']").attr("aria-hidden","true");
             tabpan.attr("aria-hidden","false");
             }
          }
        });

      });
    }
    function tabEvents($tabs) {
      //var config = this.config;
      $('.expandable-tablist a', $tabs).click(function(event){
        event.preventDefault();
        var $tab = $(this);

        $('.expandable-tabcontent', $tabs).hide().attr({'aria-hidden':'true'});
        $('.expandable-tablist li', $tabs).removeClass('is-active');
        $('.expandable-tablist li a', $tabs).removeClass('is-active');
        $('.expandable-tablist li a', $tabs).attr({
          'aria-selected': 'false',
        });

        $tab.attr({
          'aria-selected': 'true',
        }).addClass('is-active').parent().addClass('is-active');
        $tab.focus();

        var $panel = $tab.attr('href');
        //alert($tabs.attr('id'));
        $($panel).fadeIn().attr({'aria-hidden':'false'});
        expandableHashUpdate($panel);
      });
    }
    function accordionEvents($tabs) {
      $('.expandable-accordion-heading a', $tabs).click(function(event){
        event.preventDefault();
        var $tab = $(this);
        var $panel = $tab.attr('href');
        $('.expandable-accordion-heading a', $tabs).removeClass('is-active').attr({'aria-expanded':'false'});
        $('.expandable-tabcontent', $tabs).slideUp().attr({'aria-hidden':'true'});
        if($($panel).is(':visible')) {
          $($panel).slideUp().attr({'aria-hidden':'false'});
          $tab.attr({'aria-expanded':'false'}).removeClass('is-active');
        }
        else {
          $($panel).slideDown().attr({'aria-hidden':'true'});
          $tab.attr({'aria-expanded':'true'}).addClass('is-active');
          expandableHashUpdate($panel);
          var $accordionID = '#' + $tab.attr('id');
          setTimeout(function(){
            $('html, body').animate({
              scrollTop: $($accordionID).offset().top - 100
            }, 500);
          }, 600);
        }

        //$tab.toggleClass('is-active').attr({'aria-expanded':'true'});
      });
    }
    function selectEvents($tabs) {
      if ( $tabs.hasClass('expandable-select') ) {
        $('a.expandable-prompt', $tabs).click(function(event){
          event.preventDefault();
          if ($(this).attr('aria-expanded') == 'false') {
            $(this).attr('aria-expanded', 'true');
          }
          else {
            $(this).attr('aria-expanded', 'false');
          }
          $('.expandable-tab-group', $tabs).toggle('fast');
        });
        $('a.expandable-tablist-link', $tabs).click(function(event) {

          event.preventDefault();
          $tabset = '#' + $(this).data('tabset');
          $($tabset + ' .expandable-tab-group').fadeOut('fast');
        });
        $('body').click(function() {
          $('.expandable-select .expandable-tab-group').fadeOut('fast');
          $('a.expandable-prompt').attr('aria-expanded', 'false');
        });
        $('.expandable-select-prompt').click(function(event){
          event.stopPropagation();
        });
      }

    }
    function displayTabs($tabs) {
      // Open first panel
      if ( $tabs.hasClass('expandable-open') ) {

        $('.expandable-accordion-heading:first a', $tabs).attr({
          'aria-expanded':'true',
        }).addClass('is-active');
        $('.expandable-tablist li:first', $tabs).addClass('is-active');
        $('.expandable-tablist li:first a', $tabs).attr({
          'aria-selected':'true',
        }).addClass('is-active');
        $('.expandable-tabcontent:first', $tabs).show().attr({
          'aria-hidden':'false',
        });
      }
      // Check for hash
      if(window.location.hash) {
        var $hash = window.location.hash;
        if ( $($hash, $tabs).length ) {
          // reset tabs
          $('.expandable-tabcontent', $tabs).hide().attr({'aria-hidden':'true'});
          $('.expandable-tablist li, .expandable-tablist li a', $tabs).removeClass('is-active');
          $('.expandable-tablist li a', $tabs).attr({
            'aria-selected': 'false',
          });
          $('.expandable-accordion-heading a', $tabs).removeClass('is-active').attr({'aria-expanded':'false'});
          // show panel
          $($hash, $tabs).show().attr({'aria-expanded':'true'});
          $('.expandable-tablist li a[href="' + $hash + '"]', $tabs).addClass('is-active').attr({
            'aria-selected': 'true',
          }).parent().addClass('is-active');
          $('.expandable-accordion-heading a[href="' + $hash + '"]', $tabs).addClass('is-active').attr({'aria-expanded':'true'});
        }
      }
    }
    function expandableHashUpdate($panel) {
      history.pushState(null,null,$panel);
    }
})(jQuery);
;
(function ($) {
  $(document).ready(function(){

    $(".expandable").expandable({
      type: 'accordion',
      class: 'outline',
      animation: 'fade',
      responsive: {
        breakpoint: 3000,
        headingTagName: "strong",
      },
    });
    
  });
}(jQuery));
;
(function ($) {
  $(document).ready(function(){
     // encodeURI(uri)
     $('a.share-on-twitter').each(function(){
       var share_url = $(this).attr('href');
       $(this).click(function(){
         window.open(share_url,'ShareOnTwitterWindow', 'width=600, height=400');
         return false;
       });
     });
  });

})(jQuery);
;
(function( $ ){
  $(document).ready(function(){
    $('.video-hero-unit').each(function(){

      var vars = {};
      var iframe = $('#' + $(this).data('video-hero-iframe'));
      var iframeID = '#' + $(this).data('video-hero-iframe');
      var id = $(this).data('video-hero-id');
      console.log(id);
      vars['player' + id] = new Vimeo.Player(iframe);

      // Play the video.
      vars['player' + id].play();
      // Wait for their to be progress and then fade out poster frame
      vars['player' + id].on('progress', function(data) {
        var videoheroID = $(this).data('video-hero-id');
        $('#video-hero-' + id + ' .video-hero-poster-frame').fadeOut();
        $('#video-hero-' + id).addClass('video-hero-playing');
      });
      $('#video-hero-' + id + ' .button-play').on('click', function() { videoHeroPlayPause(vars['player' + id], id); } );
    });
    // Size video on load
    fullscreenVideoHero();
    videoSize();
  });

  // Play/Pause controls
  function videoHeroPlayPause(player, id) {
    player.getPaused().then(function(paused) {
      if (paused) {
        player.play();
        $('#video-hero-' + id + ' .button-play').addClass('paused');
        $('#video-hero-' + id + ' .button-play').find('.fa-play').addClass('fa-pause').removeClass('fa-play');

      } else {
        player.pause();
        $('#video-hero-' + id + ' .button-play').removeClass('paused');
        $('#video-hero-' + id + ' .button-play').find('.fa-pause').removeClass('fa-pause').addClass('fa-play');
      }
    });
  }

  // Full Screen Video Hero
  function fullscreenVideoHero() {
    $('.video-hero-unit-size-full').each(function(){
      // Determine header size by calculating site of header + navigation
      var header = $('#header-wrapper').outerHeight() + $('#navigation-wrapper').outerHeight();
      $(this).css('min-height', 'calc(100vh - ' + header + 'px)');
    });
  }

  // Resize video hero units
  function videoSize() {
    $('.video-hero-unit').each(function(){
      var $wrapper = $(this);
      var $h = $wrapper.height();
      var $w = $wrapper.width();
      // console.log($w);
      // console.log($h);

      var dimensions = calculateAspectRatioFit(800, 450, $w, $h);
      //console.log(dimensions);
      $('iframe', $wrapper).css('width', dimensions['width']).css('height', dimensions['height']);

      var l = ($w - dimensions['width'])/2;
      var t = ($h - dimensions['height'])/2;
      //console.log(l);
      $('iframe', $wrapper).css('top', t).css('left', l);
    });
  }


  // Calculate aspect ratio/dimensions
  function calculateAspectRatioFit(srcWidth, srcHeight, maxWidth, maxHeight) {
    var ratio = Math.max(maxWidth / srcWidth, maxHeight / srcHeight);
    return { width: srcWidth*ratio, height: srcHeight*ratio };
 }

  // Size video on window resize
  $( window ).resize(function() {
    fullscreenVideoHero();
    videoSize();
  });
})( jQuery );
;
(function ($) {
  $(document).ready(function(){
    $(".bean-collection-grid .expand-trigger").each(function(i){
      var trigger = $(this).attr('href');
      var trigger2 = trigger + '-' + i;
      var target = trigger2.substring(1);
      $(this).attr('href', trigger2);
      $(this).next('.expand-content').attr('id', target);
    });
    $(".collection-items-categories").hide();

    $(".collection-filter-links button").click(function(){
      // Get the collection to operate on
      var collectionTarget = $(this).attr("data-collection");
      // Remove disabled class, aria from all items in collection
      $("#" + collectionTarget + " .collection-item").removeClass('collection-item-disabled').removeAttr('aria-hidden').removeAttr('role').removeClass('collection-item-active');
      // Get the collection category
      var target = $(this).attr("data-collection-category");
      history.pushState(null,null,'#' + target);
      // Apply disabled class, aria to all items not in category
      $('#' + collectionTarget + ' .collection-item').not('.collection-category-' + target).addClass('collection-item-disabled').attr('aria-hidden', 'true').attr('role', 'presentation');
      $('#' + collectionTarget + ' .collection-item.collection-category-' + target).addClass('collection-item-active');
      // Remove active class from category links
      $('#' + collectionTarget + ' .collection-filter-links button').removeClass('active');
      // Apply active class to the clicked link
      $(this).addClass('active');
      updateCollectionResults(collectionTarget);
      return false;
    });


    $('.collection-filter-links-multi-select input').change(function(){
      var collectionTarget = $(this).attr("data-collection");
      var filters = [];
      var breadcrumbs = [];
      var filterClasses;
      var type;
      // When a filter is changed, get all checked filters.
      $('#' + collectionTarget + ' .collection-filter-links-single.collection-filter-links-multi-select input:checkbox:checked').each(function () {
        filters.push('.collection-category-' + $(this).val());
        var label = $(this).next().text();
        breadcrumbs.push(label);
        type = 'multiple';
      });
      // When a filter is changed, display a breadcrumb of what was selected.
      $('#' + collectionTarget + ' .collection-filter-links-multi-select.collection-filter-links-multiple').each(function () {
        var $groups = $(this);
        $('input:checkbox:checked', $groups).each(function(){
          filters.push('.collection-category-' + $(this).val());
          var label = $(this).next().text();
          breadcrumbs.push(label);
          type = 'multiple';
        });
      });
      if (type == 'single') {
        filterClasses = filters.join(', ');
      }
      else if (type == 'multiple') {
        filterClasses = filters.join(', ');
        filterBreadcrumbs = breadcrumbs.join(', ');
      }
      if (filters.length == 0) {
        $('#' + collectionTarget + ' .collection-item').fadeIn();
        $('#' + collectionTarget + ' .collection-breadcrumbs').html('');
        $('.collection-breadcrumbs-wrapper .collection-reset').hide();
      }
      else {
        $('#' + collectionTarget + ' .collection-item').hide();
        //$(filterClasses).fadeIn();
        $('#' + collectionTarget + ' .collection-item' + filterClasses).fadeIn();
        $('#' + collectionTarget + ' .collection-breadcrumbs').html('<strong>Selected filters:</strong> ' + filterBreadcrumbs);
        $('.collection-breadcrumbs-wrapper .collection-reset').show();
      }
      $(this).parent().toggleClass('active');
      updateCollectionResults(collectionTarget, 'multiple');
    });
    $('.collection-reset').click(function(){
      var collectionTarget = $(this).attr("data-collection");
      $('#' + collectionTarget + ' .collection-item').fadeIn();
      $('#' + collectionTarget + ' .collection-breadcrumbs').html('');
      $('#' + collectionTarget + ' input:checkbox').prop( "checked", false );
      $('.collection-breadcrumbs-wrapper .collection-reset').hide();
      updateCollectionResults(collectionTarget, 'multiple');
      return false;
    });
    // Collection ALL link
    $("button.collection-filter-clear").click(function(){
      // Get the collection to operate on
      var collectionTarget = $(this).attr("data-collection");
      // Remove disabled class, aria from all items in collection
      $("#" + collectionTarget + " .collection-item").removeClass('collection-item-disabled').removeAttr('aria-hidden').removeAttr('role').addClass('collection-item-active');
      // Remove active class from category links
      $("ul.collection-items-navigation a").removeClass('active');
      // Apply active class to the clicked link
      $(this).addClass('active');
      updateCollectionResults(collectionTarget);
      return false;
    });

    $('.collection-filter-links-multiple h3.collection-filter-label a').click(function(event){
      event.preventDefault();
      var link = $(this);
      if ($(this).attr('aria-expanded') == 'true') {
        $('.collection-filter-links').slideUp().parent().removeClass('expanded');
        $('h3.collection-filter-label a').attr('aria-expanded', 'false');
      }
      else {
        $('.collection-filter-links').slideUp().parent().removeClass('expanded');
        $('h3.collection-filter-label a').attr('aria-expanded', 'false');
        $(this).parent().next().slideDown().parent().addClass('expanded');
        $(this).attr('aria-expanded', 'true');

        setTimeout(function(){
            $('html, body').animate({
              scrollTop: $(link).offset().top - 100
            }, 500);
          }, 600);
      }
    });
    $('.collection-grid').each(function(){
      $('.collection-item', this).addClass('collection-item-active');
      var items = $('.collection-item-active', this).length;
      $('.collection-grid .results').text(items + ' items found.');
      $('.collection-filter-clear').addClass('active');

      // Check for hash
      if(window.location.hash) {
        var $hash = window.location.hash;
        if ( $("button[data-collection-category-hash='" + $hash + "']", this).length ) {
          $("button[data-collection-category-hash='" + $hash + "']").click();
        }
      }

    });



    // UPdate the items found in a collection grid.
    function updateCollectionResults(collectionId, type) {

      $('#' + collectionId + ' .collection-item').removeAttr('tabindex');
      var items = $('#' + collectionId + ' .collection-item-active').length;
      if (type == 'multiple') {
        $('#' + collectionId + ' .results').text(items + ' items found.');
      }
      else {
        $('#' + collectionId + ' .results').text(items + ' items found.').attr('tabindex','-1').focus();
      }
      $('.element-item').removeAttr('tabindex');
      $('#' + collectionId + ' .collection-item-active').attr('tabindex',0);

    }
  });
})(jQuery);
;
(function( $ ){
  $(document).ready(function(){
    $('.feature-layout-wrapper img.image-hero').wrap('<div class="feature-layout-hero-wrapper"></div>');
  });
})( jQuery );
;
(function ($) {
  Drupal.behaviors.fitvids = {
    attach: function (context, settings) {
      try
      {
        // Check that fitvids exists
        if (typeof $.fn.fitVids !== 'undefined') {
        
          // Check that the settings object exists
          if (typeof settings.fitvids !== 'undefined') {
            
            // Default settings values
            var selectors = ['body'];
            var simplifymarkup = true;
            var custom_domains = null;
            
            // Get settings for this behaviour
            if (typeof settings.fitvids.selectors !== 'undefined') {
              selectors = settings.fitvids.selectors;
            }
            if (typeof settings.fitvids.simplifymarkup !== 'undefined') {
              simplifymarkup = settings.fitvids.simplifymarkup;
            }
            if (settings.fitvids.custom_domains.length > 0) {
              custom_domains = settings.fitvids.custom_domains;
            }
                
            // Remove media wrappers
            if (simplifymarkup) {
              if ($(".media-youtube-outer-wrapper").length) {
                $(".media-youtube-outer-wrapper").removeAttr("style");
                $(".media-youtube-preview-wrapper").removeAttr("style");
                $(".media-youtube-outer-wrapper").removeClass("media-youtube-outer-wrapper");
                $(".media-youtube-preview-wrapper").removeClass("media-youtube-preview-wrapper");
              }
              if ($(".media-vimeo-outer-wrapper").length) {
                $(".media-vimeo-outer-wrapper").removeAttr("style");
                $(".media-vimeo-preview-wrapper").removeAttr("style");
                $(".media-vimeo-outer-wrapper").removeClass("media-vimeo-outer-wrapper");
                $(".media-vimeo-preview-wrapper").removeClass("media-vimeo-preview-wrapper");
              }
            }
            
            // Fitvids!
            for (var x = 0; x < selectors.length; x ++) {
              $(selectors[x]).fitVids({customSelector: custom_domains});
            }
          }
        }
      }
      catch (e) {
        // catch any fitvids errors
        window.console && console.warn('Fitvids stopped with the following exception');
        window.console && console.error(e);
      }
    }
  };
}(jQuery));
;
(function ($) {

  /**
   * Google CSE utility functions.
   */
  Drupal.googleCSE = Drupal.googleCSE || {};

  Drupal.behaviors.googleCSE = {
    attach: function (context, settings) {
      // Show watermark, if not disabled in module settings.
      if (Drupal.settings.googleCSE.showWaterMark) {
        Drupal.googleCSE.googleCSEWatermark('#search-block-form.google-cse', context);
        Drupal.googleCSE.googleCSEWatermark('#search-form.google-cse', context);
        Drupal.googleCSE.googleCSEWatermark('#google-cse-results-searchbox-form', context);
      }
    }
  };

  /**
   * Show google CSE watermark.
   */
  Drupal.googleCSE.googleCSEWatermark = function(id, context) {
    var f = $(id, context)[0];
    if (f && (f.query || f['edit-search-block-form--2'] || f['edit-keys'])) {
      var q = f.query ? f.query : (f['edit-search-block-form--2'] ? f['edit-search-block-form--2'] : f['edit-keys']);
      var n = navigator;
      var l = location;
      if (n.platform == 'Win32') {
        q.style.cssText = 'border: 1px solid #7e9db9; padding: 2px;';
      }
      var b = function () {
        if (q.value == '') {
          q.style.background = '#FFFFFF url(https://www.google.com/cse/intl/' + Drupal.settings.googleCSE.language + '/images/google_custom_search_watermark.gif) left no-repeat';
        }
      };
      var f = function () {
        q.style.background = '#ffffff';
      };
      q.onfocus = f;
      q.onblur = b;
      b();
    }
  };
})(jQuery);
;
(function ($) {
  $(document).ready(function(){
    var sectionClick = false;
    $(".section-navigation-toggle").click(function () {
      $("#section-navigation").fadeToggle();
      if ($(this).attr('aria-expanded') == 'false') {
        $(this).attr('aria-expanded', 'true');
        $('.section-navigation-toggle .fa').toggleClass('fa-chevron-down');
        $('.section-navigation-toggle .fa').toggleClass('fa-reorder');
      }
      else {
        $(this).attr('aria-expanded', 'false');
        $('.section-navigation-toggle .fa').toggleClass('fa-reorder');
        $('.section-navigation-toggle .fa').toggleClass('fa-chevron-down');
      }
      return false;
    });
  });
})(jQuery);
;
(function( $ ){
  $(document).ready(function(){
    var sections = $('.section-page-sections .block-section').length;

    var section_nav;
    // Add section navigation.
    $('.section-page-navigation-active .section-page-sections').prepend('<div class="section-page-nav"><ul></ul</div>');

    // Add animation class.
    // $('.section-page-sections .block-section:not(:first) .block-section-content').addClass('animated');

    // Build section navigation.
    $('.section-page-sections .block-section').each(function(i){
      var item = i +1;
      var target = $(this).attr('id');
      var link = '<li><a href="#' + target + '" id="section-nav-id-' + target +'"><i class="fa fa-circle"></i><span class="element-invisible">' + item + '</span></li>';
      $('.section-page-navigation-active .section-page-nav ul').append(link);

      // Add anchors for each section
      $('<a name="' + i + '" name="' + i + '" id="section-anchor-' + target +'">').insertBefore(this);

      // Add a tabindex so we can focus user to sections
      $(this).attr('tabindex','-1');
      // Add waypoints for highlighting what section is currently in view.
      $(this).waypoint(function(direction) {
         // Highlight element when related content
         // is 100px from the bottom...
         // remove if below
         var id = $(this).attr('id');
         //sectionPageActive(id);
         $(this).toggleClass('active', direction === 'down');
         var id = $(this).attr('id');
         sectionPageActive(id);
         // $('.block-section-content', this).addClass('fadeIn');
       }, {
         offset: 80 //
       })
       .waypoint(function(direction) {
         var id = $(this).attr('id');
         // Highlight element when bottom of related content
         // is 100px from the top - remove if less
         // TODO - make function for this
         $(this).toggleClass('active', direction === 'up');
         var id = $(this).attr('id');
         sectionPageActive(id);
       }, {
         offset: function() {  return -$(this).height() + 80; }
       });
       // $('.section-page-sections .block-section-content:first').addClass('fadeIn');
    });
    $('.section-page-navigation-active .section-page-sections .block-section:not(:last)').each(function(i){
      // Next.
      var next = '<div class="section-next-wrapper"><div class="section-next"><i class="fa fa-angle-down"></i></div></div>';
      $(this).append(next);
    });
    $('.section-next').click(function(event){
      event.preventDefault();

      var nextSection = $(this).parents('.contextual-links-region').next();
      var target = $('.block-section:first', nextSection).attr('id');
      // Scroll to section.
      $('html, body').animate({
        scrollTop: $('#' + target).offset().top
      }, 1000, function() {
        $(target).focus();
      });

    });

    // Sticky navigation
    $('.layout-wide .section-page-navigation-wrapper').waypoint({
      handler: function(e, d) {
        $('.section-page-section-navigation').toggleClass('sticky').css('top', $('#sticky-menu').outerHeight());
      },
      offset: function() {
        var sticky = $('#sticky-menu');
        return ($('#sticky-menu').outerHeight());
      }
    });

    $('.layout-boxed .section-page-navigation-wrapper').waypoint({
      handler: function(e, d) {
        $('.section-page-navigation-wrapper').toggleClass('sticky').css('top', $('#sticky-menu').outerHeight());;
      },
      offset: function() {
        var sticky = $('#sticky-menu');
        return ($('#sticky-menu').outerHeight());
      }
    });

    // Add click events to section navigation.
    $('.section-page-nav a, .section-page-section-navigation ul  a').click(function(event){
      event.preventDefault();
      var target = $(this).attr('href');
      // Scroll to section.
      $('html, body').animate({
        scrollTop: $(target).offset().top
      }, 2000, function() {
        $(target).focus();
      });
    });


    $('#section-page-section-navigation-expand').click(function(event){
      event.preventDefault();
      $('.section-page-section-navigation ul').slideToggle();
      $('i.fa', this).toggleClass('fa-reorder').toggleClass('fa-times');
      if ($(this).attr('aria-expanded') == 'true') {
        $(this).attr('aria-expanded', 'false');
      } else {
        $(this).attr('aria-expanded', 'true');
      }
    });

    // Set active section for section navigation

    function sectionPageActive(id) {
      $('.section-page-nav i.fa').removeClass('fa-circle-o').addClass('fa-circle');
      $('i.fa', '#section-nav-id-' + id).removeClass('fa-circle').addClass('fa-circle-o');

      $('.section-page-section-navigation a').removeClass('active-section');
      $('a#top-section-nav-' + id).addClass('active-section');

      // Update url to add which section is being viewed.
      var section = $('#section-anchor-' + id).attr('name');
      var url = [location.protocol, '//', location.host, location.pathname].join('')

      // Removing push state because of tracking pixel issues.
      //history.pushState('', document.title, url + '#' + section);
    }

  });
})( jQuery );
;
